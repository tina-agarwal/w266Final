1:
m="tamoxifen" 16:0 16:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="nitroglycerin." 21:4 21:4
do="one" 21:2 21:2
mo="sublingual" 21:3 21:3
f="nm"
du="nm"
r="shortness of breath" 20:8 20:10
ln="narrative"
3:
m="lasix" 24:2 24:2
do="nm"
mo="iv" 24:1 24:1
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="nitroglycerin" 24:5 24:5
do="nm"
mo="iv" 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nitroglycerin" 26:8 26:8
do="nm"
mo="iv" 26:7 26:7
f="nm"
du="nm"
r="her blood pressure" 26:1 26:3
ln="narrative"
6:
m="tamoxifen" 50:5 50:5
do="nm"
mo="nm"
f="nm"
du="five years" 50:2 50:3
r="nm"
ln="narrative"
7:
m="lopressor" 61:2 61:2
do="25 mg" 61:3 61:4
mo="p.o." 61:5 61:5
f="b.i.d." 61:6 61:6
du="three weeks" 61:8 62:0
r="nm"
ln="list"
8:
m="axid" 62:3 62:3
do="150 mg" 62:4 62:5
mo="p.o." 62:6 62:6
f="b.i.d." 62:7 62:7
du="nm"
r="nm"
ln="list"
9:
m="enteric coated aspirin" 62:9 63:1
do="325 mg" 63:2 63:3
mo="p.o." 63:4 63:4
f="q.day" 63:5 63:5
du="nm"
r="nm"
ln="list"
10:
m="isordil" 63:7 63:7
do="30 mg" 63:8 63:9
mo="p.o." 63:10 63:10
f="q.i.d." 63:11 63:11
du="nm"
r="nm"
ln="list"
11:
m="hydralazine" 64:0 64:0
do="50 mg" 64:1 64:2
mo="p.o." 64:3 64:3
f="q.i.d." 64:4 64:4
du="nm"
r="nm"
ln="list"
12:
m="lasix" 64:6 64:6
do="40 mg" 64:7 64:8
mo="p.o." 64:9 64:9
f="q.day" 64:10 64:10
du="nm"
r="nm"
ln="list"
13:
m="timoptic 0.25%" 64:12 65:0
do="one gtt" 65:1 65:2
mo="ou" 65:3 65:3
f="b.i.d." 65:4 65:4
du="nm"
r="nm"
ln="list"
14:
m="serax" 65:6 65:6
do="30 mg" 65:7 65:8
mo="p.o." 65:9 65:9
f="q.h.s. p.r.n." 65:10 65:11
du="nm"
r="insomnia" 65:12 65:12
ln="list"
15:
m="heparin" 66:2 66:2
do="1 , 300 units" 66:4 66:7
mo="iv" 66:1 66:1
f="per hour." 66:8 66:9
du="nm"
r="nm"
ln="list"
16:
m="ticlid" 112:4 112:4
do="nm"
mo="nm"
f="nm"
du="for two weeks." 112:5 112:7
r="nm"
ln="narrative"
17:
m="hydralazine" 114:2 114:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="systolic blood pressure" 113:8 114:0
ln="narrative"
18:
m="lasix" 114:4 114:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="systolic blood pressure" 113:8 114:0
ln="narrative"
19:
m="lopressor." 114:7 114:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="systolic blood pressure" 113:8 114:0
ln="narrative"
20:
m="axid" 125:2 125:2
do="renal dosing" 125:6 125:7
mo="nm"
f="q.day" 125:9 125:9
du="nm"
r="nm"
ln="narrative"
21:
m="niferex" 136:0 136:0
do="150 mg" 136:1 136:2
mo="p.o." 136:3 136:3
f="b.i.d." 136:4 136:4
du="nm"
r="an iron deficiency anemia" 135:5 135:8
ln="narrative"
22:
m="epogen" 138:3 138:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="her anemia" 137:9 137:10
ln="narrative"
23:
m="enteric coated aspirin" 143:2 143:4
do="325 mg" 143:5 143:6
mo="p.o." 143:7 143:7
f="q.day" 143:8 143:8
du="nm"
r="nm"
ln="list"
24:
m="hydralazine" 144:6 144:6
do="50 mg" 144:7 144:8
mo="p.o." 145:0 145:0
f="q.i.d." 145:1 145:1
du="nm"
r="nm"
ln="list"
25:
m="lasix" 144:0 144:0
do="40 mg" 144:1 144:2
mo="p.o." 144:3 144:3
f="q.day" 144:4 144:4
du="nm"
r="nm"
ln="list"
26:
m="isordil" 145:3 145:3
do="30 mg" 145:4 145:5
mo="p.o." 145:6 145:6
f="t.i.d." 145:7 145:7
du="nm"
r="nm"
ln="list"
27:
m="lopressor" 145:9 145:9
do="25 mg" 145:10 145:11
mo="p.o." 145:12 145:12
f="b.i.d." 146:0 146:0
du="nm"
r="nm"
ln="list"
28:
m="nitroglycerin 1/150" 146:2 146:3
do="one tablet" 146:4 146:5
mo="sublingual" 146:6 146:6
f="q. 5 minutes times three p.r.n." 146:7 147:2
du="nm"
r="chest pain" 147:3 147:4
ln="list"
29:
m="timoptic 0.25%" 147:6 147:7
do="one drop" 147:8 147:9
mo="ou" 147:10 147:10
f="b.i.d." 147:11 147:11
du="nm"
r="nm"
ln="list"
30:
m="axid" 148:0 148:0
do="150 mg" 148:1 148:2
mo="p.o." 148:3 148:3
f="q.day" 148:4 148:4
du="nm"
r="nm"
ln="list"
31:
m="ticlid" 148:7 148:7
do="250 mg" 148:8 148:9
mo="p.o." 148:10 148:10
f="b.i.d." 148:11 148:11
du="for two weeks." 148:12 149:0
r="nm"
ln="list"
32:
m="niferex tablet" 149:3 149:4
do="150 mg" 149:5 149:6
mo="p.o." 149:7 149:7
f="b.i.d." 149:8 149:8
du="nm"
r="nm"
ln="list"
33:
m="ticlid" 152:2 152:2
do="nm"
mo="nm"
f="nm"
du="four weeks" 151:6 151:7
r="nm"
ln="narrative"
