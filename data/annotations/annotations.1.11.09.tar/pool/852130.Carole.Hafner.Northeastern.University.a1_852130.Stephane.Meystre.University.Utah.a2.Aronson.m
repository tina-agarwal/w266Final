1:
m="carvedilol" 19:6 19:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="right coronary artery infarct." 18:5 18:8
ln="narrative"
2:
m="heparin" 21:11 21:11
do="nm"
mo="drip" 21:12 21:12
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="aspirin" 38:4 38:4
do="81" 38:5 38:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 38:7 38:7
do="20" 38:8 38:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="gemfibrozil" 39:8 39:8
do="600" 39:9 39:9
mo="nm"
f="b.i.d." 40:0 40:0
du="nm"
r="nm"
ln="list"
6:
m="plavix" 39:0 39:0
do="75" 39:1 39:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="verapamil" 39:3 39:3
do="240" 39:4 39:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="glipizide" 40:10 40:10
do="10" 40:11 40:11
mo="nm"
f="daily" 40:12 40:12
du="nm"
r="nm"
ln="list"
9:
m="nystatin" 40:2 40:2
do="500" 40:3 40:3
mo="nm"
f="b.i.d." 40:4 40:4
du="nm"
r="nm"
ln="list"
10:
m="paxil" 40:6 40:6
do="20" 40:7 40:7
mo="nm"
f="daily" 40:8 40:8
du="nm"
r="nm"
ln="list"
11:
m="carvedilol" 41:9 41:9
do="6.25" 42:0 42:0
mo="nm"
f="daily" 42:1 42:1
du="nm"
r="nm"
ln="list"
12:
m="coumadin" 41:0 41:0
do="4" 41:1 41:1
mo="nm"
f="nm"
du="prior to admission to outside hospital" 41:2 41:7
r="nm"
ln="list"
13:
m="heparin" 42:3 42:3
do="nm"
mo="drip" 42:4 42:4
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="spironolactone." 42:6 42:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="ace inhibitor" 75:10 76:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="aspirin" 75:4 75:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="beta-blocker" 75:8 75:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="plavix" 75:6 75:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="niaspan" 77:7 77:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="statin" 77:3 77:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="spironolactone." 85:2 85:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe mr." 84:7 84:8
ln="narrative"
22:
m="verapamil" 89:3 89:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="bicarbonate" 98:0 98:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="mucomyst." 98:2 98:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="heparin-bridged coumadin" 111:2 111:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="hypoglycemics" 120:0 120:0
do="nm"
mo="oral" 119:10 119:10
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="regular insulin" 121:3 121:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes" 119:8 119:8
ln="narrative"
28:
m="hypoglycemics" 122:0 122:0
do="nm"
mo="oral" 121:10 121:10
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="ativan." 125:9 125:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="anxiety" 125:4 125:4
ln="narrative"
30:
m="paxil" 125:7 125:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="anxiety" 125:4 125:4
ln="narrative"
31:
m="nicotine patch" 128:5 128:6
do="nm"
mo="nm"
f="nm"
du="during his hospital stay" 128:7 128:10
r="smoking." 127:8 127:8
ln="narrative"
32:
m="nicotine patch" 130:3 130:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="aspirin" 145:1 145:1
do="325" 145:2 145:2
mo="p.o." 145:3 145:3
f="daily." 145:4 145:4
du="nm"
r="nm"
ln="list"
34:
m="lisinopril" 146:1 146:1
do="4 mg" 146:2 146:3
mo="p.o." 146:4 146:4
f="daily." 146:5 146:5
du="nm"
r="nm"
ln="list"
35:
m="nicotine patch" 147:1 147:2
do="14 mg" 147:3 147:4
mo="topical" 147:7 147:7
f="per day" 147:5 147:6
du="nm"
r="nm"
ln="list"
36:
m="spironolactone" 148:1 148:1
do="25 mg" 148:2 148:3
mo="p.o." 148:4 148:4
f="daily." 148:5 148:5
du="nm"
r="nm"
ln="list"
37:
m="paxil" 149:1 149:1
do="25 mg" 149:2 149:3
mo="p.o." 149:4 149:4
f="daily." 149:5 149:5
du="nm"
r="nm"
ln="list"
38:
m="atorvastatin" 150:1 150:1
do="80 mg" 150:2 150:3
mo="nm"
f="daily." 150:4 150:4
du="nm"
r="nm"
ln="list"
39:
m="niaspan" 151:1 151:1
do="0.5 gm" 151:2 151:3
mo="p.o." 151:4 151:4
f="twice daily." 151:5 151:6
du="nm"
r="nm"
ln="list"
40:
m="carvedilol" 152:1 152:1
do="12.5 mg" 152:2 152:3
mo="p.o." 152:4 152:4
f="twice daily." 152:5 152:6
du="nm"
r="nm"
ln="list"
41:
m="plavix" 153:1 153:1
do="75 mg" 153:2 153:3
mo="nm"
f="daily." 153:4 153:4
du="nm"
r="nm"
ln="list"
42:
m="gemfibrozil" 154:1 154:1
do="900 mg" 154:2 154:3
mo="p.o." 154:4 154:4
f="twice daily." 154:5 154:6
du="nm"
r="nm"
ln="list"
43:
m="coumadin" 155:1 155:1
do="5 mg" 155:2 155:3
mo="p.o." 155:4 155:4
f="at night." 155:5 155:6
du="nm"
r="nm"
ln="list"
