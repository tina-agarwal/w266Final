1:
m="ntg" 18:0 18:0
do="nm"
mo="sublingual" 17:10 17:10
f="twice daily" 18:3 18:4
du="nm"
r="exertional angina." 18:7 18:8
ln="narrative"
2:
m="ntg" 21:1 21:1
do="nm"
mo="sublingual" 21:0 21:0
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="heparin" 23:10 23:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="ntg" 23:8 23:8
do="nm"
mo="intravenous" 23:7 23:7
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="diltiazem." 24:0 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="cardizem" 34:6 34:6
do="120mg" 34:7 34:7
mo="p.o.b.i.d." 35:0 35:0
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="mevacor" 35:2 35:2
do="20mg" 35:3 35:3
mo="p.o.b.i.d" 35:4 35:4
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="pepcid" 35:6 35:6
do="40mg" 35:7 35:7
mo="p.o.q.d." 35:8 35:8
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="ventolin" 35:10 35:10
do="nm"
mo="nm"
f="prn" 36:5 36:5
du="nm"
r="nm"
ln="list"
10:
m="seldane" 36:1 36:1
do="nm"
mo="nm"
f="prn" 36:5 36:5
du="nm"
r="nm"
ln="list"
11:
m="penicillin" 50:9 50:9
do="nm"
mo="p.o." 50:8 50:8
f="nm"
du="a course" 50:5 50:6
r="a possible periodontal abscess" 49:7 49:10
ln="narrative"
12:
m="cefuroxime" 62:9 62:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="a low-grade fever" 61:1 61:3
ln="narrative"
13:
m="cefuroxime" 62:9 62:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="leukocytosis" 61:5 61:5
ln="narrative"
14:
m="empiric antibiotics." 65:4 65:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="oxygen" 71:4 71:4
do="nm"
mo="nm"
f="nm"
du="for some time" 71:5 71:7
r="nm"
ln="narrative"
16:
m="aspirin" 75:1 75:1
do="325mg" 75:2 75:2
mo="nm"
f="q.d." 75:3 75:3
du="nm"
r="nm"
ln="list"
17:
m="diltiazem" 75:5 75:5
do="120mg" 75:6 75:6
mo="p.o.t.i.d" 75:7 75:7
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="colace" 76:0 76:0
do="100mg" 76:1 76:1
mo="nm"
f="t.i.d." 76:2 76:2
du="nm"
r="nm"
ln="list"
19:
m="iron sulfate" 76:4 76:5
do="300mg" 76:6 76:6
mo="nm"
f="t.i.d." 76:7 76:7
du="nm"
r="nm"
ln="list"
20:
m="lasix" 76:9 76:9
do="80mg" 77:0 77:0
mo="p.o.b.i.d" 77:1 77:1
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="mevacor" 77:3 77:3
do="20mg" 77:4 77:4
mo="p.o.b.i.d" 77:5 77:5
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="mvi" 77:7 77:7
do="one" 77:8 77:8
mo="p.o.q.d." 77:9 77:9
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="kcl" 78:9 78:9
do="40mil/eq" 78:10 78:10
mo="p.o.b.i.d." 78:11 78:11
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="percocet" 78:0 78:0
do="one to two tabs." 78:1 78:4
mo="nm"
f="q. 4 prn" 78:5 78:7
du="nm"
r="nm"
ln="list"
25:
m="ciprofloxacin" 79:0 79:0
do="500mg" 79:1 79:1
mo="p.o.b.i.d" 79:2 79:2
f="nm"
du="x 10 days" 79:3 79:5
r="nm"
ln="list"
26:
m="clindamycin" 79:8 79:8
do="300mg" 80:0 80:0
mo="p.o.q.i.d." 80:1 80:1
f="nm"
du="x 10 days" 79:3 79:5
r="nm"
ln="list"
27:
m="antibiotics." 83:2 83:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
