1:
m="albuterol inhaler" 14:0 14:1
do="2 puff" 14:2 14:3
mo="inh" 14:4 14:4
f="qid prn" 14:5 15:0
du="nm"
r="shortness of breath" 15:1 15:3
ln="list"
2:
m="albuterol inhaler" 14:0 14:1
do="2 puff" 14:2 14:3
mo="inh" 14:4 14:4
f="qid prn" 14:5 15:0
du="nm"
r="wheezing" 15:5 15:5
ln="list"
3:
m="lantus ( insulin glargine )" 16:0 16:4
do="60 units" 16:5 16:6
mo="sc" 16:7 16:7
f="daily" 16:8 16:8
du="nm"
r="nm"
ln="list"
4:
m="roxicet oral solution ( oxycodone+apap liquid )" 18:0 18:6
do="5-10 milliliters" 19:0 19:1
mo="po" 19:2 19:2
f="q4h prn" 19:3 19:4
du="nm"
r="pain" 19:5 19:5
ln="list"
5:
m="zantac syrup ( ranitidine hcl syrup )" 20:0 20:6
do="150 mg" 20:7 20:8
mo="po" 20:9 20:9
f="bid" 20:10 20:10
du="nm"
r="nm"
ln="list"
6:
m="actigall ( ursodiol )" 21:0 21:3
do="300 mg" 21:4 21:5
mo="po" 21:6 21:6
f="bid" 21:7 21:7
du="nm"
r="nm"
ln="list"
7:
m="levaquin ( levofloxacin )" 24:0 24:3
do="500 mg" 24:4 24:5
mo="po" 24:6 24:6
f="daily" 24:7 24:7
du="nm"
r="nm"
ln="list"
8:
m="ciprofloxacin" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="levofloxacin" 27:2 27:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="prochlorperazine" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="levofloxacin" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lantus" 63:2 63:2
do="60" 63:3 63:3
mo="sc" 63:4 63:4
f="hs." 63:5 63:5
du="nm"
r="nm"
ln="narrative"
13:
m="levaquin." 67:4 67:4
do="nm"
mo="nm"
f="nm"
du="three day course" 67:0 67:2
r="nm"
ln="narrative"
14:
m="narcotic pain medication." 79:8 79:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="your home medications." 80:3 80:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
