1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 20:17 20:17
do="nm"
mo="po" 20:18 20:18
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 21:3 21:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 21:5 21:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="aspirin" 22:3 22:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="warfarin" 22:5 22:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="aspirin" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="warfarin" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="coumadin" 26:3 26:3
do="nm"
mo="po" 26:4 26:4
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="aspirin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="warfarin" 27:5 27:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="aspirin" 28:3 28:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="warfarin" 28:5 28:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="aspirin" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="atenolol" 31:0 31:0
do="37.5 mg" 31:1 31:2
mo="po" 31:3 31:3
f="daily" 31:4 31:4
du="nm"
r="nm"
ln="list"
17:
m="captopril" 32:0 32:0
do="12.5 mg" 32:1 32:2
mo="po" 32:3 32:3
f="bid" 32:4 32:4
du="nm"
r="nm"
ln="list"
18:
m="kcl immediate release" 37:3 37:5
do="nm"
mo="po" 37:6 37:6
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="captopril" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="potassium chloride" 39:5 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="captopril" 41:3 41:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="potassium chloride" 41:5 42:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="celexa ( citalopram )" 43:0 43:3
do="40 mg" 43:4 43:5
mo="po" 43:6 43:6
f="daily" 43:7 43:7
du="nm"
r="nm"
ln="list"
24:
m="plavix ( clopidogrel )" 44:0 44:3
do="75 mg" 44:4 44:5
mo="po" 44:6 44:6
f="daily" 44:7 44:7
du="nm"
r="nm"
ln="list"
25:
m="digoxin" 45:0 45:0
do="0.125 mg" 45:1 45:2
mo="po" 45:3 45:3
f="daily" 45:4 45:4
du="nm"
r="nm"
ln="list"
26:
m="eplerenone" 46:0 46:0
do="25 mg" 46:1 46:2
mo="po" 46:3 46:3
f="daily" 46:4 46:4
du="nm"
r="nm"
ln="list"
27:
m="kcl immediate release" 48:3 48:5
do="nm"
mo="po" 48:6 48:6
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="eplerenone" 50:2 50:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="potassium chloride" 50:4 50:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="folate ( folic acid )" 52:0 52:4
do="1 mg" 52:5 52:6
mo="po" 52:7 52:7
f="daily" 52:8 52:8
du="nm"
r="nm"
ln="list"
31:
m="lasix ( furosemide )" 53:0 53:3
do="60 mg" 53:4 53:5
mo="po" 53:6 53:6
f="bid" 53:7 53:7
du="nm"
r="nm"
ln="list"
32:
m="lasix" 55:17 55:17
do="nm"
mo="po" 55:18 55:18
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="neurontin ( gabapentin )" 58:0 58:3
do="100 mg" 58:4 58:5
mo="po" 58:6 58:6
f="tid" 58:7 58:7
du="nm"
r="nm"
ln="list"
34:
m="lorazepam" 59:0 59:0
do="0.5 mg" 59:1 59:2
mo="po" 59:3 59:3
f="daily prn" 59:4 59:5
du="nm"
r="anxiety" 59:6 59:6
ln="list"
35:
m="lovastatin" 60:0 60:0
do="40 mg" 60:1 60:2
mo="po" 60:3 60:3
f="daily" 60:4 60:4
du="number of doses required ( approximate ): 7" 79:0 79:7
r="nm"
ln="list"
36:
m="coumadin" 64:17 64:17
do="nm"
mo="po" 64:18 64:18
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="lovastatin" 65:3 65:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="warfarin" 65:5 65:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="coumadin" 68:3 68:3
do="nm"
mo="po" 68:4 68:4
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="lovastatin" 69:3 69:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="warfarin" 69:5 69:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="lovastatin" 72:3 72:3
do="nm"
mo="po" 72:4 72:4
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="niacin" 77:3 77:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="vit. b-3" 77:5 77:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
45:
m="lovastatin" 78:0 78:0
do="nm"
mo="nm"
f="nm"
du="number of doses required (approximate): 7" 79:0 79:7
r="nm"
ln="list"
46:
m="omeprazole" 80:0 80:0
do="20 mg" 80:1 80:2
mo="po" 80:3 80:3
f="daily" 80:4 80:4
du="nm"
r="nm"
ln="list"
47:
m="temazepam" 81:0 81:0
do="15-30 mg" 81:1 81:2
mo="po" 81:3 81:3
f="bedtime prn" 81:4 81:5
du="nm"
r="insomnia" 81:6 81:6
ln="list"
48:
m="multivitamin therapeutic ( therapeutic multivi... )" 82:0 82:5
do="1 tab" 83:0 83:1
mo="po" 83:2 83:2
f="daily" 83:3 83:3
du="nm"
r="nm"
ln="list"
49:
m="lovastatin" 84:17 84:17
do="nm"
mo="po" 84:18 84:18
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="niacin" 85:3 85:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="vit. b-3" 85:5 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="lovastatin" 86:0 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="cosopt ( timolol/dorzolamide )" 87:0 87:3
do="1 drop" 87:4 87:5
mo="ou" 87:6 87:6
f="bid" 87:7 87:7
du="nm"
r="nm"
ln="list"
54:
m="cosopt" 88:17 88:17
do="nm"
mo="ou" 88:18 88:18
f="nm"
du="nm"
r="nm"
ln="list"
55:
m="coumadin ( warfarin sodium )" 91:0 91:4
do="1 mg" 91:5 91:6
mo="po" 91:7 91:7
f="qpm" 91:8 91:8
du="nm"
r="nm"
ln="list"
56:
m="coumadin ( warfarin sodium )" 91:0 91:4
do="1mg" 93:3 93:3
mo="nm"
f="every day except for monday" 93:4 93:8
du="nm"
r="nm"
ln="list"
57:
m="aspirin" 98:17 98:17
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
58:
m="warfarin" 98:19 98:19
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
59:
m="aspirin" 99:3 99:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
60:
m="warfarin" 99:5 99:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
61:
m="aspirin" 100:3 100:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
62:
m="warfarin" 100:5 100:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
63:
m="lovastatin" 101:3 101:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
64:
m="warfarin" 101:5 101:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
65:
m="travatan" 103:0 103:0
do="1 drop" 103:1 103:2
mo="ou" 103:3 103:3
f="bedtime" 103:4 103:4
du="nm"
r="nm"
ln="narrative"
66:
m="lasix" 137:1 137:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="amiodarone" 147:0 147:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="asa/plavix" 190:0 190:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="bb" 190:2 190:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="lasix" 194:11 194:11
do="60" 195:1 195:1
mo="nm"
f="bid." 195:2 195:2
du="nm"
r="nm"
ln="narrative"
71:
m="acei" 195:6 195:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="dig/nitrate/bb" 195:4 195:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="lyte" 196:2 196:2
do="nm"
mo="nm"
f="prn." 196:4 196:4
du="nm"
r="nm"
ln="narrative"
74:
m="mucomyst" 198:14 198:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="ppi" 200:6 200:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="barrett's" 200:2 200:2
ln="narrative"
76:
m="celexa" 201:6 201:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="neuropathy" 201:2 201:2
ln="narrative"
77:
m="neurontin" 201:4 201:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="neuropathy" 201:2 201:2
ln="narrative"
78:
m="eye drops" 202:5 202:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
79:
m="coumadin" 204:3 204:3
do="2mg" 204:11 204:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="imdur." 206:6 206:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="coumadin" 209:3 209:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="lasix" 211:2 211:2
do="60" 211:3 211:3
mo="nm"
f="twice a day." 211:4 211:6
du="nm"
r="nm"
ln="narrative"
