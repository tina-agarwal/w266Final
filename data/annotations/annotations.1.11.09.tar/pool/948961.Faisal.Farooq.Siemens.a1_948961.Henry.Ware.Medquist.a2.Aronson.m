1:
m="acetaminophen" 16:1 16:1
do="1000 mg" 16:2 16:3
mo="po" 16:4 16:4
f="q6h" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="levothyroxine sodium" 17:1 17:2
do="75 mcg" 17:3 17:4
mo="po " 17:5 17:5
f="qd " 17:6 17:6
du="nm"
r="nm"
ln="list"
3:
m="quinapril" 18:1 18:1
do="20 mg" 18:2 18:3
mo="po" 18:4 18:4
f="qam" 18:5 18:5
du="nm"
r="nm"
ln="list"
4:
m="ranitidine hcl" 19:1 19:2
do="150 mg" 19:3 19:4
mo="po" 19:5 19:5
f="qd" 19:6 19:6
du="nm"
r="nm"
ln="list"
5:
m="multivitamins" 20:1 20:1
do="1 capsule" 20:2 20:3
mo="po" 20:4 20:4
f="qd" 20:5 20:5
du="nm"
r="nm"
ln="list"
6:
m="tylenol ( acetaminophen )" 22:0 22:3
do="650 mg" 22:4 22:5
mo="po" 22:6 22:6
f="q4h prn" 22:7 22:8
du="nm"
r="headache" 22:9 22:9
ln="list"
7:
m="vitamin c ( ascorbic acid )" 23:0 23:5
do="500 mg" 23:6 23:7
mo="po" 23:8 23:8
f="bid" 23:9 23:9
du="nm"
r="nm"
ln="list"
8:
m="dulcolax ( bisacodyl )" 24:0 24:3
do="5-10 mg" 24:4 24:5
mo="po" 24:6 24:6
f="daily prn" 24:7 24:8
du="nm"
r="constipation" 24:9 24:9
ln="list"
9:
m="keflex ( cephalexin )" 25:0 25:3
do="500 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qid" 25:7 25:7
du="nm"
r="nm"
ln="list"
10:
m="colace ( docusate sodium )" 26:0 26:4
do="100 mg" 26:5 26:6
mo="po" 26:7 26:7
f="bid" 26:8 26:8
du="nm"
r="nm"
ln="list"
11:
m="pepcid ( famotidine )" 27:0 27:3
do="20 mg" 27:4 27:5
mo="po" 27:6 27:6
f="bid" 27:7 27:7
du="nm"
r="nm"
ln="list"
12:
m="dilaudid ( hydromorphone hcl )" 28:0 28:4
do="2-4 mg" 28:5 28:6
mo="po" 28:7 28:7
f="q3h prn" 28:8 28:9
du="nm"
r="pain" 28:10 28:10
ln="list"
13:
m="dilaudid" 30:3 30:3
do="2-4 mg" 30:5 30:6
mo="po" 30:4 30:4
f="q3h" 30:7 30:7
du="nm"
r="nm"
ln="list"
14:
m="dilaudid" 35:3 35:3
do="nm"
mo="po" 35:4 35:4
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="insulin regular human" 38:0 38:2
do="sliding scale" 39:0 39:1
mo="( subcutaneously ) sc" 39:2 39:5
f="ac+hs" 39:6 39:6
du="nm"
r="nm"
ln="list"
16:
m="insulin" 42:5 42:5
do="0 units" 43:7 43:8
mo="subcutaneously" 43:9 43:9
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="insulin" 42:5 42:5
do="1 units" 44:7 44:8
mo="subcutaneously" 44:9 44:9
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="insulin" 42:5 42:5
do="3 units" 45:7 45:8
mo="subcutaneously" 45:9 45:9
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="insulin" 42:5 42:5
do="5 units" 46:7 46:8
mo="subcutaneously" 46:9 46:9
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="insulin" 42:5 42:5
do="7 units" 47:7 47:8
mo="subcutaneously" 47:9 47:9
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="insulin" 42:5 42:5
do="8 units" 48:7 48:8
mo="subcutaneously" 48:9 48:9
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="regular insulin" 50:3 50:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="regular insulin" 51:6 51:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="synthroid ( levothyroxine sodium )" 52:0 52:4
do="75 mcg" 52:5 52:6
mo="po" 52:7 52:7
f="daily" 52:8 52:8
du="nm"
r="nm"
ln="list"
25:
m="maalox-tablets quick dissolve/chewable" 53:0 53:2
do="1-2 tab" 53:3 53:4
mo="po" 53:5 53:5
f="q6h prn" 53:6 54:0
du="nm"
r="upset stomach" 54:1 54:2
ln="narrative"
26:
m="milk of magnesia ( magnesium hydroxide )" 55:0 55:6
do="30 milliliters" 56:0 56:1
mo="po" 56:2 56:2
f="daily prn" 56:3 56:4
du="nm"
r="constipation" 56:5 56:5
ln="list"
27:
m="reglan ( metoclopramide hcl )" 57:0 57:4
do="10 mg" 57:5 57:6
mo="iv" 57:7 57:7
f="q6h prn" 57:8 57:9
du="nm"
r="nausea" 57:10 57:10
ln="list"
28:
m="zofran ( post-op n/v ) ( ondansetron hcl ( post-... )" 58:0 58:10
do="1 mg" 59:0 59:1
mo="iv" 59:2 59:2
f="q6h...prn" 59:3 59:3,59:7 59:7
du="x 2 doses" 59:4 59:6
r="nausea" 59:8 59:8
ln="list"
29:
m="quinapril" 60:0 60:0
do="20 mg" 60:1 60:2
mo="po" 60:3 60:3
f="daily" 60:4 60:4
du="nm"
r="nm"
ln="list"
30:
m="kcl iv" 63:3 63:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="potassium chloride" 64:6 65:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="quinapril hcl" 64:3 64:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="potassium chloride" 66:6 67:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="quinapril hcl" 66:3 66:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="simethicone" 69:0 69:0
do="80 mg" 69:1 69:2
mo="po" 69:3 69:3
f="qid prn" 69:4 69:5
du="nm"
r="upset stomach" 69:6 69:7
ln="narrative"
36:
m="multivitamin therapeutic ( therapeutic multivi... )" 70:0 70:5
do="1 tab" 71:0 71:1
mo="po" 71:2 71:2
f="daily" 71:3 71:3
du="nm"
r="nm"
ln="list"
37:
m="tigan ( trimethobenzamide hcl )" 72:0 72:4
do="200 mg" 72:5 72:6
mo="pr" 72:7 72:7
f="q6h prn" 72:8 72:9
du="nm"
r="nausea" 72:10 72:10
ln="list"
38:
m="tigan ( trimethobenzamide hcl )" 73:0 73:4
do="300 mg" 73:5 73:6
mo="po" 73:7 73:7
f="q6h prn" 73:8 73:9
du="number of doses required ( approximate ): 10" 74:0 74:7
r="nausea" 73:10 73:10
ln="list"
39:
m="pain medications" 105:6 105:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="stool softener" 106:2 106:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation." 106:6 106:6
ln="list"
41:
m="antibiotics" 113:3 113:3
do="nm"
mo="nm"
f="nm"
du="as long as you have a drain in place." 113:4 113:12
r="nm"
ln="narrative"
