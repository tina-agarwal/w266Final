1:
m="capsaicin 0.025 %" 14:0 14:2
do="nm"
mo="tp" 14:3 14:3
f="bid" 14:4 14:4
du="nm"
r="nm"
ln="list"
2:
m="lasix ( furosemide )" 15:0 15:3
do="40 mg" 15:4 15:5
mo="po" 15:6 15:6
f="qd" 15:7 15:7
du="nm"
r="nm"
ln="list"
3:
m="micronase ( glyburide )" 16:0 16:3
do="2.5 mg" 16:4 16:5
mo="po" 16:6 16:6
f="qd" 16:7 16:7
du="nm"
r="nm"
ln="list"
4:
m="l-thyroxine ( levothyroxine sodium )" 17:0 17:4
do="50 mcg" 17:5 17:6
mo="po" 17:7 17:7
f="qd" 17:8 17:8
du="nm"
r="nm"
ln="list"
5:
m="digoxin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="levothyroxine sodium" 20:5 21:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="pyridium ( phenazopyridine hcl )" 22:0 22:4
do="100 mg" 22:5 22:6
mo="po" 22:7 22:7
f="tid prn" 22:8 23:0
du="nm"
r="pain" 23:2 23:2
ln="list"
8:
m="probenecid" 24:0 24:0
do="1 , 500 mg" 24:1 24:4
mo="po" 24:5 24:5
f="bid" 24:6 24:6
du="nm"
r="nm"
ln="list"
9:
m="cozaar ( losartan )" 25:0 25:3
do="75 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qd" 25:7 25:7
du="Number of Doses Required ( approximate ): 5" 26:0 26:7
r="nm"
ln="list"
10:
m="flomax ( tamsulosin )" 27:0 27:3
do="0.4 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qd" 27:7 27:7
du="nm"
r="nm"
ln="list"
11:
m="nexium ( esomeprazole )" 28:0 28:3
do="40 mg" 28:4 28:5
mo="po" 28:6 28:6
f="qd" 28:7 28:7
du="nm"
r="nm"
ln="list"
12:
m="bactrim ds ( trimethoprim/sulfamethoxazole dou... )" 29:0 29:5
do="1 tab" 30:0 30:1
mo="po" 30:2 30:2
f="q24h" 30:3 30:3
du="nm"
r="nm"
ln="list"
13:
m="coumadin" 52:4 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 51:8 51:8
ln="narrative"
14:
m="ffp" 53:6 53:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="inr" 53:4 53:4
ln="narrative"
15:
m="ffp" 54:5 54:5
do="nm"
mo="transfusion" 54:6 54:6
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="ffp" 54:8 54:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="bactrim" 61:12 61:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="coumadin." 62:3 62:3
do="low dose" 62:1 62:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="coumadin" 63:0 63:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="coumadin" 64:5 64:5
do="3 mg" 64:7 64:8
mo="nm"
f="nm"
du="tonight and tomorrow night" 64:10 64:13
r="nm"
ln="narrative"
21:
m="coumadin" 65:8 65:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="coumadine" 65:3 65:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="coumadin" 66:9 66:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="narcotics." 67:11 67:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
