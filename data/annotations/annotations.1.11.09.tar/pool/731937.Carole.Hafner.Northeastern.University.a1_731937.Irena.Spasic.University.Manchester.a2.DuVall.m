1:
m="levophed" 32:1 32:1
do="nm"
mo="infusion." 32:2 32:2
f="nm"
du="nm"
r="hemorrhagic rash" 31:3 31:4
ln="narrative"
2:
m="insulin" 51:8 51:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 51:5 51:6
ln="narrative"
3:
m="vancomycin" 52:4 52:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
4:
m="ceftazidime" 53:4 53:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
5:
m="flagyl" 53:2 53:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
6:
m="gentamicin" 53:6 53:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
7:
m="levofloxacin" 53:0 53:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
8:
m="nafcillin" 53:8 53:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="infective endocarditis:active" 52:0 52:1
ln="narrative"
9:
m="heparin low molecular weight" 60:2 60:5
do="nm"
mo="nm"
f="nm"
du="24 hours" 61:2 61:3
r="nm"
ln="list"
10:
m="enoxaparin" 61:5 61:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lovenox" 61:7 61:7
do="40 mg" 61:8 61:9
mo="subcu" 61:10 61:10
f="daily" 61:11 61:11
du="nm"
r="nm"
ln="list"
12:
m="norepinephrine" 62:0 62:0
do="3 mcg per kg per minute continuous" 62:1 62:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="simvastatin" 62:9 62:9
do="40 mg" 62:10 63:0
mo="p.o." 63:1 63:1
f="daily" 63:2 63:2
du="nm"
r="nm"
ln="list"
14:
m="ceftazidime" 63:10 63:10
do="2000 mg" 63:11 63:12
mo="iv" 63:13 63:13
f="q8h" 64:0 64:0
du="nm"
r="nm"
ln="list"
15:
m="nexium" 63:4 63:4
do="40 mg" 63:5 63:6
mo="p.o." 63:7 63:7
f="daily" 63:8 63:8
du="nm"
r="nm"
ln="list"
16:
m="gentamicin" 64:2 64:2
do="560 mg" 64:3 64:4
mo="iv" 64:5 64:5
f="q.24h." 64:6 64:6
du="nm"
r="nm"
ln="list"
17:
m="penicillin g" 64:8 64:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium" 64:11 64:11
do="3 million units" 64:12 65:1
mo="iv" 65:2 65:2
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="inotrops" 106:5 106:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="vasodilated" 106:0 106:0
ln="narrative"
20:
m="methylene blue." 106:7 106:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="vasodilated" 106:0 106:0
ln="narrative"
21:
m="pressors" 106:3 106:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="vasodilated" 106:0 106:0
ln="narrative"
22:
m="onoptrops" 107:4 107:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="antibiotics" 108:0 108:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="packed red blood cells" 109:6 109:9
do="one unit" 109:3 109:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="fentanyl" 110:9 110:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="versed/semarch." 111:1 111:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="antibiotics" 112:5 112:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="inotrops" 112:0 112:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="fentanyl" 115:1 115:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="2nd washout+/- closure" 115:5 115:7
ln="narrative"
30:
m="versed" 115:3 115:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="2nd washout+/- closure" 115:5 115:7
ln="narrative"
31:
m="epi" 116:7 116:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="vaso" 116:9 116:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="gentamicin." 119:3 119:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="vancomycin" 119:1 119:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="pressor" 120:3 120:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="epinephrine" 121:8 121:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="sedation" 121:5 120:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="vasopressin" 122:4 122:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="vasopressin." 127:5 127:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="pressors" 128:10 128:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="lopressor" 129:2 129:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="lopressor" 130:9 130:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertensive" 130:6 130:6
ln="narrative"
43:
m="hydralazine." 131:2 131:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="tng" 131:0 131:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="nicardipine" 132:4 132:4
do="nm"
mo="drip" 132:5 132:5
f="nm"
du="nm"
r="hypertension" 132:7 132:7
ln="narrative"
46:
m="nicardipine" 133:4 133:4
do="nm"
mo="drip" 133:5 133:5
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="vancomycin." 136:11 136:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="mrsa" 136:5 136:5
ln="narrative"
48:
m="lopressor" 138:2 138:2
do="50" 138:6 138:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="aspirin" 147:4 147:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lopressor" 147:6 147:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="cardiac meds" 150:0 150:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="lopressor" 150:3 150:3
do="37.5" 150:4 150:4
mo="p.o." 150:5 150:5
f="q.6h." 150:6 150:6
du="nm"
r="nm"
ln="list"
53:
m="insulin" 160:5 160:5
do="10 units" 160:6 160:7
mo="subcutaneously" 160:8 160:8
f="10 p.m." 161:1 161:2
du="nm"
r="diabetes." 160:2 160:2
ln="narrative"
54:
m="lantus" 161:4 161:4
do="22 units" 161:5 161:6
mo="sc" 161:7 161:7
f="q.p.m." 161:8 161:8
du="nm"
r="diabetes." 160:2 160:2
ln="narrative"
55:
m="aspirin." 162:3 162:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 162:2 162:2
ln="narrative"
56:
m="antibiotics" 164:0 164:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="Septicemia" 163:2 163:2
ln="narrative"
57:
m="penicillin g" 164:7 164:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="Septicemia" 163:2 163:2
ln="narrative"
58:
m="vancomycin" 164:2 164:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="Septicemia" 163:2 163:2
ln="narrative"
59:
m="potassium" 165:0 165:0
do="3 million units" 165:1 165:3
mo="iv." 165:4 165:4
f="nm"
du="nm"
r="Septicemia" 163:2 163:2
ln="narrative"
60:
m="antibiotics" 166:1 166:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="skin lesion infection." 165:5 165:7
ln="narrative"
61:
m="ceftriaxone" 166:3 166:3
do="2000 mg" 166:4 166:5
mo="iv" 166:6 166:6
f="daily" 166:7 166:7
du="nm"
r="skin lesion infection." 165:5 165:7
ln="narrative"
62:
m="penicillin g" 166:9 166:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="skin lesion infection" 165:5 165:7
ln="narrative"
63:
m="potassium" 167:0 167:0
do="4 million units" 167:1 167:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="antibiotics" 168:0 168:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="staph aureus septicemia" 168:6 168:8
ln="narrative"
65:
m="vancomycin" 168:2 168:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="staph aureus septicemia" 168:6 168:8
ln="narrative"
66:
m="ceftriaxone" 169:7 169:7
do="2000 mg" 169:8 169:9
mo="iv" 169:10 169:10
f="daily" 169:11 169:11
du="nm"
r="staph aureus septicemia" 170:10 171:0
ln="narrative"
67:
m="penicillin g" 169:0 169:1
do="3 million units" 169:2 169:4
mo="iv" 169:5 169:5
f="nm"
du="nm"
r="staph aureus septicemia" 170:10 171:0
ln="narrative"
68:
m="penicillin g" 170:0 170:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="staph aureus septicemia" 170:10 171:0
ln="narrative"
69:
m="potassium" 170:3 170:3
do="4 million units" 170:4 170:6
mo="nm"
f="nm"
du="nm"
r="staph aureus septicemia" 170:10 171:0
ln="narrative"
70:
m="lopressor" 175:0 175:0
do="titrate" 174:7 174:7
mo="nm"
f="nm"
du="nm"
r="blood pressure" 174:4 174:5
ln="narrative"
71:
m="oxygen" 176:7 176:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="lasix" 184:9 184:9
do="20 mg" 184:10 185:0
mo="p.o." 185:1 185:1
f="t.i.d." 185:2 185:2
du="nm"
r="nm"
ln="list"
73:
m="lopressor" 184:3 184:3
do="37.5 mg" 184:4 184:5
mo="p.o." 184:6 184:6
f="q.6h." 184:7 184:7
du="nm"
r="nm"
ln="list"
74:
m="acetylsalicylic acid" 185:4 185:5
do="325 mg" 185:6 185:7
mo="p.o." 185:8 185:8
f="nm"
du="nm"
r="nm"
ln="list"
75:
m="naturale tears" 185:10 185:11
do="one drop" 186:0 186:1
mo="o.u." 186:2 186:2
f="nm"
du="nm"
r="nm"
ln="list"
76:
m="colace" 186:4 186:4
do="100 mg" 186:5 186:6
mo="p.o." 186:7 186:7
f="t.i.d." 186:8 186:8
du="nm"
r="nm"
ln="list"
77:
m="insulin regular humulin" 186:10 186:12
do="4 units" 187:0 187:1
mo="subcu" 187:2 187:2
f="nm"
du="nm"
r="nm"
ln="list"
78:
m="lactinex granules" 187:4 187:5
do="2 tabs" 187:6 187:7
mo="p.o." 187:8 187:8
f="nm"
du="nm"
r="nm"
ln="list"
79:
m="magnesium sulfate" 187:10 187:11
do="sliding scale" 188:0 188:1
mo="intravenously" 188:2 188:2
f="nm"
du="nm"
r="nm"
ln="list"
80:
m="penicillin g" 188:4 188:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
81:
m="potassium" 188:7 188:7
do="4 million units" 188:8 189:0
mo="iv" 189:1 189:1
f="nm"
du="nm"
r="nm"
ln="list"
82:
m="lantus" 189:14 189:14
do="22 units" 190:0 190:1
mo="subcu" 190:2 190:2
f="q.p.m." 190:3 190:3
du="nm"
r="nm"
ln="list"
83:
m="nexium" 189:8 189:8
do="20 mg" 189:9 189:10
mo="p.o." 189:11 189:11
f="daily" 189:12 189:12
du="nm"
r="nm"
ln="list"
84:
m="vancomycin" 189:3 189:3
do="1000 mg" 189:4 189:5
mo="iv" 189:6 189:6
f="nm"
du="nm"
r="nm"
ln="list"
85:
m="novolog" 190:5 190:5
do="sliding scale" 190:6 190:7
mo="sc." 190:8 190:8
f="nm"
du="nm"
r="nm"
ln="list"
