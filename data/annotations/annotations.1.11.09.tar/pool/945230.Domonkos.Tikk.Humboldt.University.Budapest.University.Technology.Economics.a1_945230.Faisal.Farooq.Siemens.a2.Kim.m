1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="warfarin sodium" 21:3 21:4
do="nm"
mo="po" 21:5 21:5
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 22:3 22:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 22:5 22:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="allopurinol" 24:0 24:0
do="100 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qd" 24:4 24:4
du="nm"
r="nm"
ln="list"
6:
m="allopurinol" 25:20 25:20
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 25:18 25:18
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 27:0 27:0
do="0.125 mg" 27:1 27:2
mo="po" 27:3 27:3
f="qd" 27:4 27:4
du="nm"
r="nm"
ln="list"
9:
m="levoxyl" 28:19 28:19
do="nm"
mo="po" 28:20 28:20
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="digoxin" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="levothyroxine sodium" 29:5 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="levoxyl ( levothyroxine sodium )" 31:0 31:4
do="75 mcg" 31:5 31:6
mo="po" 31:7 31:7
f="qd" 31:8 31:8
du="nm"
r="nm"
ln="list"
13:
m="warfarin sodium" 33:3 33:4
do="nm"
mo="po" 33:5 33:5
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="levothyroxine sodium" 34:2 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 34:5 34:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="digoxin" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="levothyroxine sodium" 38:5 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="toprol xl ( metoprolol ( sust. rel. ) )" 40:0 40:8
do="50 mg" 40:9 40:10
mo="po" 40:11 40:11
f="qd" 40:12 40:12
du="number of doses required ( approximate ): 8" 43:0 43:7
r="nm"
ln="list"
19:
m="neurontin ( gabapentin )" 44:0 44:3
do="200 mg" 44:4 44:5
mo="po" 44:6 44:6
f="qd" 44:7 44:7
du="nm"
r="nm"
ln="list"
20:
m="cozaar ( losartan )" 45:0 45:3
do="100 mg" 45:4 45:5
mo="po" 45:6 45:6
f="qd" 45:7 45:7
du="number of doses required ( approximate ): 9" 46:0 46:7
r="nm"
ln="list"
21:
m="celexa ( citalopram )" 47:0 47:3
do="20 mg" 47:4 47:5
mo="po" 47:6 47:6
f="qd" 47:7 47:7
du="nm"
r="nm"
ln="list"
22:
m="lantus ( insulin glargine )" 48:0 48:4
do="50 units" 48:5 48:6
mo="sc" 48:7 48:7
f="qhs" 48:8 48:8
du="nm"
r="nm"
ln="list"
23:
m="warfarin sodium" 49:0 49:1
do="3 mg" 49:2 49:3
mo="po" 49:4 49:4
f="qpm" 49:5 49:5
du="nm"
r="nm"
ln="list"
24:
m="simvastatin" 54:3 54:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="warfarin" 54:5 54:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="levothyroxine sodium" 55:2 55:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="warfarin" 55:5 55:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="aspirin" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="warfarin" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="allopurinol" 57:2 57:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 57:4 57:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="levofloxacin" 58:3 58:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="warfarin" 58:5 58:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levofloxacin" 59:3 59:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="warfarin" 59:5 59:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="lipitor ( atorvastatin )" 61:0 61:3
do="10 mg" 61:4 61:5
mo="po" 61:6 61:6
f="qd" 61:7 61:7
du="nm"
r="nm"
ln="list"
37:
m="prilosec ( omeprazole )" 62:0 62:3
do="20 mg" 62:4 62:5
mo="po" 62:6 62:6
f="qd" 62:7 62:7
du="nm"
r="nm"
ln="list"
38:
m="torsemide" 63:0 63:0
do="100 mg" 63:1 63:2
mo="po" 63:3 63:3
f="qam" 63:4 63:4
du="nm"
r="nm"
ln="list"
39:
m="torsemide" 64:0 64:0
do="50 mg" 64:1 64:2
mo="po" 64:3 64:3
f="qpm" 64:4 64:4
du="nm"
r="nm"
ln="list"
40:
m="adriamycin" 82:0 82:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="lasix" 110:3 110:3
do="nm"
mo="intravenous" 110:2 110:2
f="nm"
du="until her respiratory status imroved" 110:4 111:0
r="nm"
ln="narrative"
42:
m="angiotension receptor blocker" 114:9 115:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="beta blocker" 114:6 114:7
do="home doses" 114:3 114:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="statin." 115:3 115:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="torsemide" 117:2 117:2
do="100 mg" 117:3 117:4
mo="po" 117:5 117:5
f="q am" 117:6 117:7
du="nm"
r="nm"
ln="narrative"
46:
m="torsemide" 117:2 117:2
do="50 mg" 117:9 117:10
mo="po" 117:11 117:11
f="q pm" 117:12 117:13
du="nm"
r="nm"
ln="narrative"
47:
m="beta blocker" 127:10 127:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="asa" 135:7 135:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="beta blocker" 135:9 135:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="arb." 136:2 136:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="coumadin" 137:1 137:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt" 136:11 136:11
ln="narrative"
52:
m="coumadin" 138:9 138:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="her ep procedure." 139:3 139:5
ln="narrative"
53:
m="levofloxacin" 138:5 138:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="coumadin" 140:5 140:5
do="regular dose" 140:2 140:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="levofloxacin." 142:6 142:6
do="nm"
mo="nm"
f="nm"
du="for three days" 142:2 142:4
r="nm"
ln="narrative"
56:
m="levo." 143:10 143:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="levoxyl" 149:0 149:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's hypothyroid." 149:2 149:4
ln="narrative"
58:
m="lantus" 150:1 150:1
do="30 u" 150:8 150:9
mo="sc" 150:10 150:10
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="lantus" 150:1 150:1
do="50 u" 150:4 150:5
mo="sc" 150:6 150:6
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="regular insulin" 151:7 152:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="lasix" 160:4 160:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="torsemide" 160:6 160:6
do="100 mg" 160:7 160:8
mo="nm"
f="every morning" 160:9 160:10
du="nm"
r="nm"
ln="narrative"
63:
m="torsemide" 160:6 160:6
do="100 mg" 161:0 161:1
mo="po" 161:2 161:2
f="everynight." 161:3 161:3
du="nm"
r="nm"
ln="narrative"
