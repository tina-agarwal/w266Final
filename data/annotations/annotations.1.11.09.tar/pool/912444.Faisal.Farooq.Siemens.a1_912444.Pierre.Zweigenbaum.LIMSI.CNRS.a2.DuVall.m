1:
m="azmacort" 34:2 34:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="cardizem" 34:8 34:8
do="300" 34:9 34:9
mo="nm"
f="q.day" 35:0 35:0
du="nm"
r="nm"
ln="list"
3:
m="proventil" 34:4 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="tagamet" 34:6 34:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="insulin nph" 35:2 35:3
do="40 units" 35:4 35:5
mo="nm"
f="q.am" 35:6 35:6
du="nm"
r="nm"
ln="list"
6:
m="insulin nph" 35:2 35:3
do="55 units" 35:8 36:0
mo="nm"
f="q.pm." 36:1 36:1
du="nm"
r="nm"
ln="list"
7:
m="aspirin" 36:3 36:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 36:12 36:12
do="20 mg" 36:13 36:14
mo="p.o." 37:0 37:0
f="q.day." 37:1 37:1
du="nm"
r="nm"
ln="list"
9:
m="maxide" 36:7 36:7
do="1" 36:8 36:8
mo="nm"
f="per day" 36:9 36:10
du="nm"
r="nm"
ln="list"
10:
m="motrin" 36:5 36:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="cisapride" 63:5 63:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her chest pressure" 64:5 64:7
ln="narrative"
12:
m="prilosec" 63:3 63:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="her chest pressure" 64:5 64:7
ln="narrative"
13:
m="prilosec" 77:9 77:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="cisapride" 78:1 78:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="isordil" 78:11 78:11
do="10mg" 78:12 78:12
mo="po" 78:13 78:13
f="tid." 78:14 78:14
du="nm"
r="nm"
ln="narrative"
16:
m="enteric coated aspirin" 79:8 80:1
do="325 mg" 80:2 80:3
mo="p.o." 80:4 80:4
f="q.day" 80:5 80:5
du="nm"
r="nm"
ln="list"
17:
m="proventil" 79:2 79:2
do="2 puffs" 79:3 79:4
mo="inhaler" 79:5 79:5
f="q.i.d." 79:6 79:6
du="nm"
r="nm"
ln="list"
18:
m="nph" 80:7 80:7
do="40 units" 80:8 81:0
mo="nm"
f="q.am" 81:1 81:1
du="nm"
r="nm"
ln="list"
19:
m="nph" 80:7 80:7
do="55 units" 81:3 81:4
mo="subcu" 81:5 81:5
f="q.pm." 81:6 81:6
du="nm"
r="nm"
ln="list"
20:
m="lisinopril" 81:8 81:8
do="20 mg" 81:9 81:10
mo="p.o." 81:11 81:11
f="q.day" 81:12 81:12
du="nm"
r="nm"
ln="list"
21:
m="maxide" 82:0 82:0
do="1 tablet" 82:1 82:2
mo="p.o." 82:3 82:3
f="q.day " 82:4 82:4
du="nm"
r="nm"
ln="list"
22:
m="nitroglycerin 1/150" 82:6 82:7
do="1 tablet" 82:8 82:9
mo="sublingual" 82:10 82:10
f="q.5 minutes times three p.r.n." 83:0 83:4
du="nm"
r="chest pain" 83:5 83:6
ln="list"
23:
m="prilosec" 83:8 83:8
do="20 mg" 83:9 83:10
mo="p.o." 83:11 83:11
f="q.day " 84:0 84:0
du="nm"
r="nm"
ln="list"
24:
m="azmacort" 84:2 84:2
do="4 puffs" 84:3 84:4
mo="inhaler" 84:5 84:5
f="b.i.d." 84:6 84:6
du="nm"
r="nm"
ln="list"
25:
m="cardizem cd" 84:8 84:9
do="300 mg" 84:10 84:11
mo="p.o." 84:12 84:12
f="q.day " 85:0 85:0
du="nm"
r="nm"
ln="list"
26:
m="cisapride" 85:2 85:2
do="10 mg" 85:3 85:4
mo="p.o." 85:5 85:5
f="q.i.d." 85:6 85:6
du="nm"
r="nm"
ln="list"
27:
m="isordil" 85:9 85:9
do="10 mg" 85:10 85:11
mo="po" 85:12 85:12
f="tid" 85:13 85:13
du="nm"
r="nm"
ln="list"
