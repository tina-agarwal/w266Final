1:
m="calcium carbonate" 26:3 26:4
do="1250 mg" 26:5 26:6
mo="nm"
f="t.i.d." 26:7 26:7
du="nm"
r="nm"
ln="list"
2:
m="cartia xt" 27:0 27:1
do="300 mg" 27:2 27:3
mo="nm"
f="daily" 27:4 27:4
du="nm"
r="nm"
ln="list"
3:
m="cellcept" 27:6 27:6
do="1500 mg" 27:7 27:8
mo="nm"
f="b.i.d." 27:9 27:9
du="nm"
r="nm"
ln="list"
4:
m="colchicine" 27:11 27:11
do="0.6 mg" 27:12 28:0
mo="nm"
f="daily p.r.n." 28:1 28:2
du="nm"
r="nm"
ln="list"
5:
m="folate" 28:9 28:9
do="1 mg" 28:10 28:11
mo="nm"
f="daily" 28:12 28:12
du="nm"
r="nm"
ln="list"
6:
m="k-dur" 28:14 28:14
do="20 mg" 29:0 29:1
mo="nm"
f="daily" 29:2 29:2
du="nm"
r="nm"
ln="list"
7:
m="neoral" 28:4 28:4
do="150 mg" 28:5 28:6
mo="nm"
f="b.i.d." 28:7 28:7
du="nm"
r="nm"
ln="list"
8:
m="magnesium oxide" 29:4 29:5
do="400 mg" 29:6 29:7
mo="nm"
f="b.i.d." 29:8 29:8
du="nm"
r="nm"
ln="list"
9:
m="methotrexate" 29:10 29:10
do="2.5 mg" 29:11 29:12
mo="nm"
f="daily" 30:0 30:0
du="nm"
r="nm"
ln="list"
10:
m="pravastatin" 30:2 30:2
do="20 mg" 30:3 30:4
mo="nm"
f="daily" 30:5 30:5
du="nm"
r="nm"
ln="list"
11:
m="prednisone" 30:7 30:7
do="7 mg" 30:8 30:9
mo="nm"
f="daily" 30:10 30:10
du="nm"
r="nm"
ln="list"
12:
m="rocaltrol" 30:12 30:12
do="0.25 mg" 31:0 31:1
mo="nm"
f="daily" 31:2 31:2
du="nm"
r="nm"
ln="list"
13:
m="synthroid" 31:4 31:4
do="150 mcg" 31:5 31:6
mo="nm"
f="daily" 31:7 31:7
du="nm"
r="nm"
ln="list"
14:
m="torsemide" 31:9 31:9
do="40 mg" 31:10 31:11
mo="nm"
f="daily" 31:12 31:12
du="nm"
r="nm"
ln="list"
15:
m="cyclosporin" 32:7 32:7
do="150 mg" 32:8 32:9
mo="nm"
f="b.i.d." 32:10 32:10
du="nm"
r="nm"
ln="list"
16:
m="vitamin c" 32:0 32:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="vitamin e" 32:3 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="lantus" 48:3 48:3
do="nm"
mo="nm"
f="q. a.c." 48:6 48:7
du="nm"
r="new-onset diabetes" 46:5 46:6
ln="narrative"
19:
m="novolog" 48:5 48:5
do="nm"
mo="nm"
f="q. a.c." 48:6 48:7
du="nm"
r="new-onset diabetes" 46:5 46:6
ln="narrative"
20:
m="novolog" 49:0 49:0
do="sliding scale." 49:1 49:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="insulin" 53:4 53:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="colchicine." 59:7 59:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="mild acute gout flare" 58:5 58:8
ln="narrative"
23:
m="rocaltrol" 65:8 65:8
do="0.25 mcg" 65:9 66:0
mo="nm"
f="daily" 66:1 66:1
du="nm"
r="nm"
ln="list"
24:
m="vitamin c" 65:2 65:3
do="500 mg" 65:4 65:5
mo="nm"
f="b.i.d." 65:6 65:6
du="nm"
r="nm"
ln="list"
25:
m="calcium carbonate" 66:3 66:4
do="500 mg" 66:5 66:6
mo="nm"
f="t.i.d." 66:7 66:7
du="nm"
r="nm"
ln="list"
26:
m="colchicine" 66:9 66:9
do="0.3 mg" 66:10 66:11
mo="p.o." 67:0 67:0
f="b.i.d." 67:1 67:1
du="nm"
r="nm"
ln="list"
27:
m="cyclosporin" 67:3 67:3
do="150 mg" 67:4 67:5
mo="nm"
f="b.i.d." 67:6 67:6
du="nm"
r="nm"
ln="list"
28:
m="folic acid" 67:8 67:9
do="1 mg" 67:10 67:11
mo="nm"
f="daily" 67:12 67:12
du="nm"
r="nm"
ln="list"
29:
m="magnesium oxide" 68:5 68:6
do="420 mg" 68:7 68:8
mo="nm"
f="b.i.d." 68:9 68:9
du="nm"
r="nm"
ln="list"
30:
m="synthroid" 68:0 68:0
do="150 mcg" 68:1 68:2
mo="nm"
f="daily" 68:3 68:3
du="nm"
r="nm"
ln="list"
31:
m="pravachol" 69:11 69:11
do="20 mg" 69:12 70:0
mo="nm"
f="at night" 70:1 70:2
du="nm"
r="nm"
ln="list"
32:
m="prednisone" 69:0 69:0
do="7.5 mg" 69:1 69:2
mo="nm"
f="q.a.m." 69:3 69:3
du="nm"
r="nm"
ln="list"
33:
m="vitamin e" 69:5 69:6
do="400 units" 69:7 69:8
mo="nm"
f="daily" 69:9 69:9
du="nm"
r="nm"
ln="list"
34:
m="cartia xt" 70:4 70:5
do="300 mg" 70:11 70:12
mo="nm"
f="daily" 71:0 71:0
du="nm"
r="nm"
ln="list"
35:
m="diltiazem extended release" 70:8 70:10
do="300 mg" 70:11 70:12
mo="nm"
f="daily" 71:0 71:0
du="nm"
r="nm"
ln="list"
36:
m="cellcept" 71:2 71:2
do="1500 mg" 71:3 71:4
mo="nm"
f="b.i.d." 71:5 71:5
du="nm"
r="nm"
ln="list"
37:
m="lantus insulin ( glargine )" 71:7 71:11
do="40 units" 71:12 72:0
mo="subcutaneous" 72:1 72:1
f="q.a.m." 72:2 72:2
du="nm"
r="nm"
ln="list"
38:
m="novolog" 72:4 72:4
do="12 units" 72:5 72:6
mo="nm"
f="before breakfast" 72:7 72:8
du="nm"
r="nm"
ln="list"
39:
m="novolog" 73:0 73:0
do="12 units" 73:1 73:2
mo="nm"
f="before lunch" 73:3 73:4
du="nm"
r="nm"
ln="list"
40:
m="novolog" 73:6 73:6
do="14 units" 73:7 73:8
mo="nm"
f="before dinner" 73:9 73:10
du="nm"
r="nm"
ln="list"
41:
m="novolog" 74:1 74:1
do="10 units" 77:8 77:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="novolog" 74:1 74:1
do="12 units" 78:2 78:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="novolog" 74:1 74:1
do="4 units" 75:7 75:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="novolog" 74:1 74:1
do="6 units" 76:4 76:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
45:
m="novolog" 74:1 74:1
do="8 units" 76:13 77:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="novolog" 74:1 74:1
do="sliding scale" 74:2 74:3
mo="nm"
f="q. a.c." 74:4 74:5
du="nm"
r="nm"
ln="list"
