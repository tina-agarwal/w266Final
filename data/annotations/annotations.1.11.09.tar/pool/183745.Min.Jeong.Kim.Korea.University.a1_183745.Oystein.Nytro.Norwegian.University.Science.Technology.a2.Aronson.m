1:
m="rocaltrol ( calcitriol )" 16:0 16:3
do="0.5 mcg" 16:4 16:5
mo="po" 16:6 16:6
f="bid" 16:7 16:7
du="nm"
r="nm"
ln="list"
2:
m="calcium carbonate ( 500 mg elemental ca++ )" 17:0 17:7
do="1 , 000 mg" 18:0 18:3
mo="po" 18:4 18:4
f="q6h" 18:5 18:5
du="nm"
r="nm"
ln="list"
3:
m="hydrochlorothiazide" 21:0 21:0
do="25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="daily" 21:4 21:4
du="nm"
r="nm"
ln="list"
4:
m="synthroid ( levothyroxine sodium )" 23:0 23:4
do="200 mcg" 23:5 23:6
mo="po" 23:7 23:7
f="bid" 23:8 23:8
du="nm"
r="nm"
ln="list"
5:
m="oxycodone" 25:0 25:0
do="5-10 mg" 25:1 25:2
mo="po " 25:3 25:3
f="q4h prn" 25:4 25:5
du="nm"
r="pain" 25:6 25:6
ln="list"
6:
m="atenolol" 26:0 26:0
do="100 mg" 26:1 26:2
mo="po" 26:3 26:3
f="daily" 26:4 26:4
du="nm"
r="nm"
ln="list"
7:
m="atenolol" 62:1 62:1
do="100" 62:2 62:2
mo="nm"
f="qd" 62:3 62:3
du="nm"
r="nm"
ln="list"
8:
m="hctz" 62:5 62:5
do="25" 62:6 62:6
mo="nm"
f="qd" 62:7 62:7
du="nm"
r="nm"
ln="list"
9:
m="levoxyl" 62:9 62:9
do="200" 62:10 62:10
mo="nm"
f="bid" 62:11 62:11
du="nm"
r="nm"
ln="list"
10:
m="rocaltrol" 62:13 62:13
do="0.5" 62:14 62:14
mo="nm"
f="bid" 62:15 62:15
du="nm"
r="nm"
ln="list"
11:
m="calcium" 63:0 63:0
do="500 mg" 63:1 63:2
mo="nm"
f="6 times per day" 63:4 63:7
du="nm"
r="nm"
ln="list"
12:
m="erythromycin" 64:1 64:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="oral medications" 67:9 67:10
do="nm"
mo="oral" 67:9 67:9
f="nm"
du="nm"
r="pain" 67:4 67:4
ln="narrative"
14:
m="hydralazine" 69:3 69:3
do="nm"
mo="iv" 68:8 68:8
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="labetalol" 69:1 69:1
do="nm"
mo="iv" 68:8 68:8
f="nm"
du="nm"
r="hypertensive" 68:3 68:3
ln="narrative"
16:
m="oral medications" 70:4 70:5
do="nm"
mo="oral" 70:4 70:4
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="pain medications" 77:12 78:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
