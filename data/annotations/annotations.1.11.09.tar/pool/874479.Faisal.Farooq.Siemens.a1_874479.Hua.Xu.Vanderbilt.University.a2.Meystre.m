1:
m="prednisone" 14:9 14:9
do="60 milligrams" 14:10 15:0
mo="orally" 15:1 15:1
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="solu-medrol" 14:6 14:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="steroids" 14:4 14:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="ampicillin" 15:8 15:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="beta agonist" 15:3 15:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="nebulizer" 15:6 15:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="theophylline" 16:3 16:3
do="nm"
mo="oral" 16:2 16:2
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="theo-dur" 20:5 20:5
do="200 milligrams" 20:6 20:7
mo="by mouth" 20:8 21:0
f="3 times a day" 21:1 21:4
du="nm"
r="nm"
ln="narrative"
9:
m="prednisone" 21:6 21:6
do="60 milligrams" 21:7 21:8
mo="by mouth" 21:9 21:10
f="each day" 21:11 21:12
du="nm"
r="nm"
ln="list"
10:
m="albuterol nebulizer" 22:0 22:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="ampicillin" 22:3 22:3
do="500 milligrams" 22:4 22:5
mo="by mouth" 22:6 22:7
f="3 times a day" 22:8 23:0
du="nm"
r="nm"
ln="list"
12:
m="bronkosol." 23:2 23:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="theophylline" 30:4 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="keflex" 42:8 42:8
do="500 milligrams" 43:0 43:1
mo="by mouth" 43:2 43:3
f="4 times a day" 43:4 43:7
du="nm"
r="nm"
ln="list"
15:
m="prednisone" 43:9 43:9
do="50 milligrams" 43:10 43:11
mo="by mouth" 43:12 44:0
f="each day." 44:1 44:2
du="nm"
r="nm"
ln="narrative"
