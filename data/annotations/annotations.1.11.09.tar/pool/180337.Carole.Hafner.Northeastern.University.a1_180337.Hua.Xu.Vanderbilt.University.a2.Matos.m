1:
m="tylenol ( acetaminophen )" 19:0 19:3
do="650-1 , 000 mg" 19:4 19:7
mo="po" 19:8 19:8
f="q4-6h prn" 19:9 20:0
du="nm"
r="headache" 20:1 20:1
ln="list"
2:
m="tylenol liquid ( acetaminophen elixer )" 21:0 21:5
do="300 mg" 22:2 22:3
mo="po" 22:4 22:4
f="q4-6h prn" 22:5 22:6
du="nm"
r="headache" 22:7 22:7
ln="list"
3:
m="tylenol #3 ( acetaminophen w/codeine 30mg)" 23:0 23:6
do="1-2 tab" 23:7 23:8
mo="po" 23:9 23:9
f="q4h prn" 23:10 24:0
du="nm"
r="pain" 24:1 24:1
ln="list"
4:
m="tylenol" 24:5 24:5
do="4gram/day" 24:7 24:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lac-hydrin 12% ( ammonium lactate 12% )" 25:0 25:6
do="nm"
mo="topical tp" 25:7 25:8
f="bid" 25:9 25:9
du="nm"
r="nm"
ln="list"
6:
m="cepacol" 27:0 27:0
do="1 lozenge" 27:1 27:2
mo="po" 27:3 27:3
f="q4h prn" 27:4 27:5
du="nm"
r="sore throat" 27:6 27:7
ln="list"
7:
m="flagyl ( metronidazole )" 28:0 28:3
do="500 mg" 28:4 28:5
mo="po" 28:6 28:6
f="bid" 28:7 28:7
du="x 5 days" 28:8 28:10
r="nm"
ln="list"
8:
m="metamucil sugar free ( psyllium ( metamucil ) su... )" 31:0 31:9
do="1 packet" 32:0 32:1
mo="po" 32:2 32:2
f="qd prn" 32:3 32:4
du="nm"
r="constipation" 32:5 32:5
ln="list"
9:
m="dicloxacillin" 33:0 33:0
do="500 mg" 33:1 33:2
mo="po" 33:3 33:3
f="qid" 33:4 33:4
du="x 12 days" 33:5 33:7
r="nm"
ln="list"
10:
m="lisinopril" 37:0 37:0
do="20 mg" 37:1 37:2
mo="po" 37:3 37:3
f="qd" 37:4 37:4
du="nm"
r="nm"
ln="list"
11:
m="claritin" 66:3 66:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="steroids" 66:1 66:1
do="nm"
mo="inh" 66:0 66:0
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="iron" 75:8 75:8
do="nm"
mo="iv." 75:9 75:9
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="flagyl" 76:1 76:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="bv" 76:3 76:3
ln="narrative"
15:
m="bp medication" 80:4 80:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="diclox" 82:4 82:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="cellulitis." 82:6 82:6
ln="narrative"
17:
m="pneumovax" 82:12 82:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
