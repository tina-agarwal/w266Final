1:
m="plaquenil" 10:4 10:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="prednisone" 10:2 10:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="aspirin" 12:9 12:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="arthralgias" 12:1 12:1
ln="narrative"
4:
m="steroids." 13:2 13:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="arthralgias" 12:1 12:1
ln="narrative"
5:
m="plaquenil" 19:7 19:7
do="200" 20:0 20:0
mo="nm"
f="bid" 20:1 20:1
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 20:4 20:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="naprosyn." 20:6 20:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="prednisone" 21:8 21:8
do="30" 21:9 21:9
mo="nm"
f="q am." 21:10 21:11
du="nm"
r="a lupus flare" 21:1 21:3
ln="narrative"
9:
m="steroids" 22:6 22:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="prednisone" 24:2 24:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="substernal chest pain" 23:5 23:7
ln="narrative"
11:
m="prednisone" 24:9 24:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="motrin" 30:13 30:13
do="800" 31:0 31:0
mo="nm"
f="bid" 31:1 31:1
du="nm"
r="nm"
ln="narrative"
13:
m="plaquenil" 30:2 30:2
do="200" 30:3 30:3
mo="nm"
f="bid" 30:4 30:4
du="nm"
r="nm"
ln="narrative"
14:
m="plaquenil" 30:2 30:2
do="200" 30:3 30:3
mo="nm"
f="tid" 30:10 30:10
du="nm"
r="nm"
ln="narrative"
15:
m="prednisone" 35:0 35:0
do="30" 35:1 35:1
mo="nm"
f="q day" 35:2 35:3
du="nm"
r="nm"
ln="narrative"
16:
m="tylenol with codeine" 35:5 35:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="steroids." 38:5 38:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="arthralgias secondary" 38:0 38:1
ln="narrative"
18:
m="plaquenil" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="prednisone" 39:5 39:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="prednisone" 40:8 40:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="plaquenil" 41:0 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="dilantin" 48:2 48:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="seizure disorder" 47:7 48:0
ln="narrative"
23:
m="l-thyroxine" 48:7 48:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypothyroidism" 48:4 48:4
ln="narrative"
24:
m="naprosyn." 51:0 51:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="dilantin" 52:14 52:14
do="400" 53:0 53:0
mo="nm"
f="q am" 53:1 53:2
du="nm"
r="nm"
ln="list"
26:
m="dilantin" 52:14 52:14
do="400" 53:0 53:0
mo="nm"
f="q day" 53:6 53:7
du="nm"
r="nm"
ln="list"
27:
m="motrin" 52:5 52:5
do="80" 52:6 52:6
mo="nm"
f="tid" 52:7 52:7
du="nm"
r="nm"
ln="list"
28:
m="plaquenil" 52:1 52:1
do="200" 52:2 52:2
mo="nm"
f="bid" 52:3 52:3
du="nm"
r="nm"
ln="list"
29:
m="prednisone" 52:9 52:9
do="10" 52:10 52:10
mo="nm"
f="q am" 52:11 52:12
du="nm"
r="nm"
ln="list"
30:
m="folate" 53:9 53:9
do="1 mg" 53:10 53:11
mo="po" 53:12 53:12
f="q day" 53:13 53:14
du="nm"
r="nm"
ln="list"
31:
m="iron sulfate" 53:16 53:17
do="225" 54:0 54:0
mo="nm"
f="tid" 54:1 54:1
du="nm"
r="nm"
ln="list"
32:
m="l-thyroxine" 53:4 53:4
do="0.2" 53:5 53:5
mo="nm"
f="q day" 53:6 53:7
du="nm"
r="nm"
ln="list"
33:
m="diprosone ointment" 54:3 54:4
do="nm"
mo="nm"
f="bid." 54:5 54:5
du="nm"
r="nm"
ln="list"
34:
m="plaquenil" 95:5 95:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="prednisone" 95:3 95:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="plaquenil" 99:9 99:9
do="200" 100:0 100:0
mo="nm"
f="bid" 100:1 100:1
du="nm"
r="nm"
ln="narrative"
37:
m="prednisone" 100:4 100:4
do="30" 100:5 100:5
mo="nm"
f="q day" 100:6 100:7
du="nm"
r="nm"
ln="narrative"
38:
m="folate" 108:2 108:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="plaquenil" 115:3 115:3
do="200" 115:4 115:4
mo="nm"
f="bid" 115:5 115:5
du="nm"
r="nm"
ln="list"
40:
m="prednisone" 115:7 115:7
do="20" 115:8 115:8
mo="nm"
f="q day" 115:9 115:10
du="nm"
r="nm"
ln="list"
41:
m="carafate" 116:14 116:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="dilantin" 116:0 116:0
do="400" 116:1 116:1
mo="nm"
f="q day" 116:2 116:3
du="nm"
r="nm"
ln="list"
43:
m="l-thyroxine" 116:5 116:5
do="0.2" 116:6 116:6
mo="nm"
f="q am" 116:7 116:8
du="nm"
r="nm"
ln="list"
44:
m="motrin" 116:10 116:10
do="800" 116:11 116:11
mo="nm"
f="tid" 116:12 116:12
du="nm"
r="nm"
ln="list"
45:
m="folate." 117:2 117:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
