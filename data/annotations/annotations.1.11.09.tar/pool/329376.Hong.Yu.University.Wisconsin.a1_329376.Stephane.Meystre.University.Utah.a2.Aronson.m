1:
m="ecasa ( aspirin enteric coated )" 16:0 16:5
do="325 mg" 16:6 16:7
mo="po" 16:8 16:8
f="qd" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 19:3 19:3
do="nm"
mo="po" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="captopril" 22:0 22:0
do="12.5 mg" 22:1 22:2
mo="po" 22:3 22:3
f="tid" 22:4 22:4
du="nm"
r="nm"
ln="list"
6:
m="aldactone" 28:3 28:3
do="nm"
mo="po" 28:4 28:4
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="captopril" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="spironolactone" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 32:3 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="captopril" 33:0 33:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="digoxin" 34:0 34:0
do="0.125 mg" 34:1 34:2
mo="po" 34:3 34:3
f="qod" 34:4 34:4
du="nm"
r="nm"
ln="list"
12:
m="lasix ( furosemide )" 35:0 35:3
do="80 mg" 35:4 35:5
mo="po" 35:6 35:6
f="bid" 35:7 35:7
du="nm"
r="nm"
ln="list"
13:
m="niferex-150" 36:0 36:0
do="150 mg" 36:1 36:2
mo="po" 36:3 36:3
f="bid" 36:4 36:4
du="nm"
r="nm"
ln="list"
14:
m="nitroglycerin 1/150 ( 0.4 mg )" 37:0 37:5
do="1 tab" 37:6 37:7
mo="sl" 37:8 37:8
f="q5min x 3 prn" 37:9 38:0
du="nm"
r="chest pain" 38:1 38:2
ln="list"
15:
m="aldactone ( spironolactone )" 39:0 39:3
do="25 mg" 39:4 39:5
mo="po" 39:6 39:6
f="qd" 39:7 39:7
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 43:2 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="spironolactone" 43:5 43:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="captopril" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="spironolactone" 44:5 44:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="coumadin ( warfarin sodium )" 46:0 46:4
do="6 mg" 46:5 46:6
mo="po" 46:7 46:7
f="qd" 46:8 46:8
du="nm"
r="nm"
ln="list"
21:
m="aspirin" 51:3 51:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="warfarin" 51:5 51:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="carvedilol" 53:0 53:0
do="3.125 mg" 53:1 53:2
mo="po" 53:3 53:3
f="bid" 53:4 53:4
du="5" 56:7 56:7
r="nm"
ln="list"
24:
m="celexa ( citalopram )" 57:0 57:3
do="20 mg" 57:4 57:5
mo="po" 57:6 57:6
f="qd" 57:7 57:7
du="nm"
r="nm"
ln="list"
25:
m="nitro." 84:7 84:7
do="nm"
mo="sl" 84:6 84:6
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="nitro." 85:7 85:7
do="nm"
mo="sl" 85:6 85:6
f="nm"
du="nm"
r="pain" 84:8 84:8
ln="narrative"
27:
m="asa." 87:13 87:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="isordil" 87:9 87:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="captopril." 88:3 88:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="carvedilol" 88:1 88:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="nitrates." 91:4 91:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="aldactone" 92:5 92:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="digoxin." 92:7 92:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="lasix" 92:3 92:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="coumadin" 95:8 95:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="tia" 95:5 95:5
ln="narrative"
36:
m="coumadin" 97:2 97:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
