1:
m="beclovent" 42:4 42:4
do="4 puffs" 42:5 42:6
mo="nm"
f="b.i.d." 42:7 42:7
du="nm"
r="nm"
ln="list"
2:
m="enalapril" 43:1 43:1
do="4 mg" 43:2 43:3
mo="nm"
f="q.d." 43:4 43:4
du="nm"
r="nm"
ln="list"
3:
m="diltiazem" 44:1 44:1
do="360 mg" 44:2 44:3
mo="nm"
f="q.d." 44:4 44:4
du="nm"
r="nm"
ln="list"
4:
m="lasix" 45:1 45:1
do="40 mg" 45:2 45:3
mo="nm"
f="b.i.d." 45:4 45:4
du="nm"
r="nm"
ln="list"
5:
m="hydralazine" 60:1 60:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="enalapril" 87:1 87:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="diltiazem" 88:8 88:8
do="180 mg" 88:9 89:0
mo="nm"
f="q.d." 89:1 89:1
du="nm"
r="nm"
ln="narrative"
8:
m="hydralazine" 89:9 89:9
do="10 mg" 89:10 89:11
mo="nm"
f="t.i.d." 89:12 89:12
du="nm"
r="nm"
ln="narrative"
9:
m="lasix" 89:3 89:3
do="80 mg" 89:4 89:5
mo="nm"
f="b.i.d." 89:6 89:6
du="nm"
r="nm"
ln="narrative"
10:
m="diltiazem" 103:3 103:3
do="180 mg" 103:4 103:5
mo="po" 103:6 103:6
f="q.d" 103:7 103:7
du="nm"
r="nm"
ln="list"
11:
m="enalapril" 104:1 104:1
do="10 mg" 104:2 104:3
mo="po" 104:4 104:4
f="q.d" 104:5 104:5
du="nm"
r="nm"
ln="list"
12:
m="lasix" 105:1 105:1
do="80 mg" 105:2 105:3
mo="po" 105:4 105:4
f="b.i.d." 105:5 105:5
du="nm"
r="nm"
ln="list"
13:
m="aspirin" 106:2 106:2
do="one" 106:1 106:1
mo="nm"
f="per day." 106:3 106:4
du="nm"
r="nm"
ln="list"
