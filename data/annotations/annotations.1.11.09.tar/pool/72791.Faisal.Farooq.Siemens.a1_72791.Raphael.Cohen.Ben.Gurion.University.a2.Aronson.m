1:
m="levophed." 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="mean arterial pressures" 48:5 48:7
ln="narrative"
2:
m="levofloxacin" 50:0 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="gram-positive cocci bacteremia" 50:5 51:0
ln="narrative"
3:
m="levofloxacin" 50:0 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="uti." 51:2 51:2
ln="narrative"
4:
m="vancomycin" 50:2 50:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="gram-positive cocci bacteremia" 50:5 51:0
ln="narrative"
5:
m="vancomycin" 50:2 50:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="uti" 51:2 51:2
ln="narrative"
6:
m="antibiotics" 55:0 55:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="penicillin" 55:4 55:4
do="3 million units" 55:5 55:7
mo="iv" 55:8 55:8
f="q.4h." 55:9 55:9
du="nm"
r="nm"
ln="narrative"
8:
m="gentamicin" 56:1 56:1
do="50 mg" 56:2 56:3
mo="iv" 56:4 56:4
f="q.8h." 56:5 56:5
du="nm"
r="nm"
ln="narrative"
9:
m="penicillin" 60:0 60:0
do="3 million units" 60:1 60:3
mo="iv" 60:4 60:4
f="q.4h." 60:5 60:5
du="six-week course...until 0/12" 59:7 59:8,60:6 60:7
r="nm"
ln="narrative"
10:
m="gentamicin" 61:2 61:2
do="50 mg" 61:3 61:4
mo="iv" 61:5 61:5
f="q.8h." 61:6 61:6
du="two-week course...until 2/25" 60:9 61:0,61:7 61:8
r="nm"
ln="narrative"
11:
m="aspirin" 65:0 65:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="ischemia" 64:2 64:2
ln="narrative"
12:
m="lipitor" 65:1 65:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="an initial transaminitis" 65:6 66:0
ln="narrative"
13:
m="lipitor" 68:4 68:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="levophed" 70:7 70:7
do="nm"
mo="nm"
f="nm"
du="until 11/0" 70:8 70:9
r="hypotension" 70:4 70:4
ln="narrative"
15:
m="packed red blood cells." 72:7 72:10
do="one unit" 72:4 72:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="ace-i" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="lasix" 74:1 74:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ace" 76:10 76:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="ace" 78:6 78:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="better afterload reduction" 79:2 79:4
ln="narrative"
20:
m="ace" 81:11 81:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="a very severe mitral regurgitation" 80:5 81:0
ln="narrative"
21:
m="her medication" 82:0 82:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="lopressor" 85:6 85:6
do="12.5 mg" 85:7 85:8
mo="nm"
f="t.i.d." 86:0 86:0
du="nm"
r="nonsustained ventricular tachycardia" 84:8 85:1
ln="narrative"
23:
m="lopressor" 85:6 85:6
do="25 mg" 86:9 86:10
mo="nm"
f="b.i.d." 86:11 86:11
du="nm"
r="nonsustained ventricular tachycardia" 84:8 85:1
ln="narrative"
24:
m="lipitor" 92:12 92:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="nexium" 99:4 99:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis." 99:6 99:6
ln="narrative"
26:
m="insulin" 109:0 109:0
do="sliding scale" 109:1 109:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lovenox" 110:7 110:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 110:1 110:1
ln="narrative"
28:
m="protonix." 110:9 110:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 110:1 110:1
ln="narrative"
29:
m="aspirin" 111:2 111:2
do="81 mg" 111:3 111:4
mo="nm"
f="daily " 111:5 111:5
du="nm"
r="nm"
ln="list"
30:
m="iron sulfate" 111:7 111:8
do="325 mg" 111:9 111:10
mo="nm"
f="daily " 112:0 112:0
du="nm"
r="nm"
ln="list"
31:
m="gentamicin sulfate" 112:2 112:3
do="50 mg" 112:4 112:5
mo="iv" 112:6 112:6
f="q.8h." 112:7 112:7
du="until 2/25 for a two-week course" 112:8 113:1
r="nm"
ln="list"
32:
m="penicillin g potassium" 113:3 113:5
do="3 million units" 113:6 113:8
mo="iv" 113:9 113:9
f="q.4h." 113:10 113:10
du="until 0/12 for a six-week course" 114:0 114:5
r="nm"
ln="list"
33:
m="lopressor" 114:7 114:7
do="25 mg" 114:8 114:9
mo="nm"
f="b.i.d." 114:10 114:10
du="nm"
r="nm"
ln="list"
34:
m="caltrate plus d2 tablets" 115:0 115:3
do="nm"
mo="p.o." 115:4 115:4
f="daily" 115:5 115:5
du="nm"
r="nm"
ln="list"
35:
m="lipitor" 115:7 115:7
do="10 mg" 115:8 115:9
mo="nm"
f="daily" 115:10 115:10
du="nm"
r="nm"
ln="list"
36:
m="protonix" 116:0 116:0
do="40 mg" 116:1 116:2
mo="nm"
f="daily" 116:3 116:3
du="nm"
r="nm"
ln="list"
37:
m="lasix" 119:5 119:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="lisinopril" 119:2 119:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="lasix" 121:5 121:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="potassium chloride." 121:11 122:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="antibiotic" 124:14 124:14
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="antibiotic" 133:0 133:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="ace" 134:5 134:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="better afterload reduction" 134:7 134:9
ln="narrative"
44:
m="lasix" 136:3 136:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="better afterload reduction" 134:7 134:9
ln="narrative"
45:
m="antibiotics" 137:10 137:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
