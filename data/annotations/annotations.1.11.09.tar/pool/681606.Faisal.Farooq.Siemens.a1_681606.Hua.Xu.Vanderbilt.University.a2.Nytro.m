1:
m="albuterol inhaler" 16:0 16:1
do="2 puff" 16:2 16:3
mo="inh" 16:4 16:4
f="qid" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="albuterol nebulizer" 17:0 17:1
do="2.5 mg" 17:2 17:3
mo="neb" 17:4 17:4
f="q4h...prn" 17:5 17:5,18:5 18:5
du="nm"
r="shortness of breath" 18:6 18:8
ln="list"
3:
m="albuterol nebulizer" 17:0 17:1
do="2.5 mg" 17:2 17:3
mo="neb" 17:4 17:4
f="q4h...prn" 17:5 17:5,18:5 18:5
du="nm"
r="wheezing" 18:10 18:10
ln="list"
4:
m="advair diskus 500/50 ( fluticasone propionate/... )" 19:0 19:6
do="1 puff" 20:0 20:1
mo="inh" 20:2 20:2
f="bid" 20:3 20:3
du="nm"
r="nm"
ln="list"
5:
m="combivent ( ipratropium and albuterol sulfate )" 21:0 21:6
do="2 puff" 22:0 22:1
mo="inh" 22:2 22:2
f="tid" 22:3 22:3
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 23:0 23:0
do="20 mg" 23:1 23:2
mo="po" 23:3 23:3
f="daily" 23:4 23:4
du="nm"
r="nm"
ln="list"
7:
m="kcl immediate release" 26:3 26:5
do="nm"
mo="po" 26:6 26:6
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 28:3 28:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 28:5 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 30:3 30:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride" 30:5 31:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="singulair ( montelukast )" 32:0 32:3
do="10 mg" 32:4 32:5
mo="po" 32:6 32:6
f="daily" 32:7 32:7
du="nm"
r="nm"
ln="list"
13:
m="prednisone taper" 33:0 33:1
do="10 mg" 38:1 38:2
mo="nm"
f="q 24 h" 38:3 38:5
du="x 2 dose( s )" 38:6 38:10
r="nm"
ln="list"
14:
m="prednisone taper" 33:0 33:1
do="20 mg" 37:1 37:2
mo="nm"
f="q 24 h" 37:3 37:5
du="x 3 dose( s )" 37:6 37:10
r="nm"
ln="list"
15:
m="prednisone taper" 33:0 33:1
do="30 mg" 36:1 36:2
mo="nm"
f="q 24 h" 36:3 36:5
du="x 3 dose( s )" 36:6 36:10
r="nm"
ln="list"
16:
m="prednisone taper" 33:0 33:1
do="30 mg" 36:1 36:2
mo="nm"
f="q 24 h x 3" 36:3 36:7
du="x 3 dose( s )" 36:6 36:10
r="nm"
ln="list"
17:
m="prednisone taper" 33:0 33:1
do="40 mg" 35:1 35:2
mo="nm"
f="q 24 h" 35:3 35:5
du="x 3 dose( s )" 35:6 35:10
r="nm"
ln="list"
18:
m="prednisone taper" 33:0 33:1
do="50 mg" 34:1 34:2
mo="po" 33:2 33:2
f="q 24 h" 34:3 34:5
du="x 3 dose( s )" 34:6 34:10
r="nm"
ln="list"
19:
m="prednisone taper" 33:0 33:1
do="60 mg" 33:4 33:5
mo="po" 33:2 33:2
f="q 24 h" 33:6 33:8
du="x 2 dose( s )" 33:9 33:13
r="nm"
ln="list"
20:
m="prednisone taper" 33:0 33:1
do="60 mg" 33:4 33:5
mo="po" 33:2 33:2
f="q 24 h x 2 dose( s )" 33:6 33:13
du="nm"
r="nm"
ln="list"
21:
m="nebs" 63:0 63:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="pred" 63:6 63:6
do="40mg" 63:10 63:10
mo="nm"
f="qd." 63:11 63:11
du="nm"
r="nm"
ln="narrative"
23:
m="steroids" 63:2 63:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="z-pack" 64:8 64:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="prednisone" 73:0 73:0
do="60mg" 73:1 73:1
mo="nebs." 73:4 73:4
f="x1" 73:2 73:2
du="nm"
r="nm"
ln="narrative"
26:
m="steroids" 76:0 76:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="asthma" 75:1 75:1
ln="narrative"
27:
m="steroids" 76:12 76:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="steroid injections" 78:12 79:0
do="nm"
mo="epidural" 78:11 78:11
f="nm"
du="nm"
r="low back pain" 78:5 78:7
ln="narrative"
29:
m="advair" 81:8 81:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="albuterol" 81:10 81:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="combivent" 81:12 81:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="prednisone" 81:1 81:1
do="30mg" 81:2 81:2
mo="nm"
f="qd" 81:3 81:3
du="nm"
r="nm"
ln="list"
33:
m="lisinopril" 82:2 82:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="singulair" 82:0 82:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="albuterol" 105:7 105:7
do="nm"
mo="nm"
f="q2h prn" 105:8 105:9
du="nm"
r="nm"
ln="narrative"
36:
m="duonebs" 105:4 105:4
do="nm"
mo="nm"
f="q4h " 105:5 105:5
du="nm"
r="nm"
ln="narrative"
37:
m="advair" 106:1 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="prednisone" 106:8 106:8
do="60" 106:9 106:9
mo="nm"
f="daily" 106:10 106:10
du="for 4 days" 106:11 106:13
r="nm"
ln="narrative"
39:
m="singulair." 106:3 106:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="steroids." 108:4 108:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="nicotine patch." 111:0 111:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="smoking cessation" 110:1 110:2
ln="narrative"
42:
m="lisinopril" 112:4 112:4
do="20mg" 112:8 112:8
mo="nm"
f="daily" 112:9 112:9
du="nm"
r="hypertension." 113:0 113:0
ln="narrative"
43:
m="lisinopril" 112:4 112:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension." 113:0 113:0
ln="narrative"
44:
m="lovenox" 115:2 115:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="home medications." 117:8 117:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="lisinopril" 117:11 117:11
do="20mg" 118:1 118:1
mo="nm"
f="daily." 118:2 118:2
du="nm"
r="nm"
ln="narrative"
47:
m="lisinopril" 117:11 117:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="prednisone" 119:3 119:3
do="10mg" 121:7 121:7
mo="nm"
f="daily" 121:8 121:8
du="x2 days" 121:9 121:10
r="nm"
ln="narrative"
49:
m="prednisone" 119:3 119:3
do="20mg" 121:0 121:0
mo="nm"
f="daily" 121:1 121:1
du="x3 days" 121:2 121:3
r="nm"
ln="narrative"
50:
m="prednisone" 119:3 119:3
do="30mg" 120:11 120:11
mo="nm"
f="daily" 120:12 120:12
du="x 3days" 120:13 120:14
r="nm"
ln="narrative"
51:
m="prednisone" 119:3 119:3
do="40mg" 120:5 120:5
mo="nm"
f="daily" 120:6 120:6
du="x3 days" 120:7 120:8
r="nm"
ln="narrative"
52:
m="prednisone" 119:3 119:3
do="50mg" 119:15 119:15
mo="nm"
f="daily" 120:0 120:0
du="x 3days" 120:1 120:2
r="nm"
ln="narrative"
53:
m="prednisone" 119:3 119:3
do="60mg" 119:4 119:4
mo="nm"
f="daily" 119:5 119:5
du="for 2 days" 119:6 119:8
r="nm"
ln="narrative"
54:
m="prednisone" 123:7 123:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="prednisone" 129:2 129:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
