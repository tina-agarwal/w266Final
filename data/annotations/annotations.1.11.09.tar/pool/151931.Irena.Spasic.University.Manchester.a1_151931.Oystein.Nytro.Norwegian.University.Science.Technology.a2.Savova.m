1:
m="streptokinase" 11:0 11:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarction" 10:6 10:7
ln="narrative"
2:
m="coumadin" 46:5 46:5
do="2.5 mg" 46:6 46:7
mo="p.o." 46:8 46:8
f="four times a week" 46:9 47:0
du="nm"
r="nm"
ln="list"
3:
m="coumadin" 46:5 46:5
do="5 mg" 47:2 47:3
mo="p.o." 47:4 47:4
f="three times a week" 47:5 47:8
du="nm"
r="nm"
ln="list"
4:
m="digoxin" 48:2 48:2
do="0.125 mg" 48:3 48:4
mo="p.o." 48:5 48:5
f="q. day" 48:6 48:7
du="nm"
r="nm"
ln="list"
5:
m="enalapril" 48:10 48:10
do="10 mg" 48:11 48:12
mo="p.o." 48:13 48:13
f="b.i.d." 48:14 48:14
du="nm"
r="nm"
ln="list"
6:
m="micronase" 49:2 49:2
do="2.5 mg" 49:3 49:4
mo="p.o." 49:5 49:5
f="q. day" 49:6 49:7
du="nm"
r="nm"
ln="list"
7:
m="multivitamins" 49:10 49:10
do="one tablet" 49:11 49:12
mo="p.o." 50:0 50:0
f="q. day" 50:1 50:2
du="nm"
r="nm"
ln="list"
8:
m="lasix" 50:5 50:5
do="40 mg" 50:6 50:7
mo="p.o." 50:8 50:8
f="b.i.d." 50:9 50:9
du="nm"
r="nm"
ln="list"
9:
m="xanax" 50:12 50:12
do="0.5 mg" 50:13 50:14
mo="p.o." 50:15 50:15
f="q.i.d. p.r.n." 51:0 51:1
du="nm"
r="nm"
ln="list"
10:
m="lasix" 89:3 89:3
do="nm"
mo="intravenous" 89:2 89:2
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="enalapril" 90:0 90:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="lasix" 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="enalapril" 91:5 91:5
do="12.5 mg" 91:2 91:3
mo="nm"
f="b.i.d." 91:6 91:6
du="nm"
r="nm"
ln="narrative"
14:
m="lasix" 91:11 91:11
do="40 mg" 91:8 91:9
mo="p.o." 91:12 91:12
f="b.i.d." 92:0 92:0
du="nm"
r="nm"
ln="narrative"
15:
m="coumadin" 92:7 92:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="heparin" 93:0 93:0
do="nm"
mo="nm"
f="nm"
du="during this hospitalization" 93:1 93:3
r="nm"
ln="narrative"
17:
m="tylenol" 116:5 116:5
do="650 mg" 116:6 116:7
mo="p.o." 116:8 116:8
f="q.4h. p.r.n." 116:9 116:10
du="nm"
r="headache" 117:0 117:0
ln="list"
18:
m="xanax" 117:3 117:3
do="0.5 mg" 117:4 117:5
mo="p.o." 117:6 117:6
f="q.i.d." 117:7 117:7
du="nm"
r="nm"
ln="list"
19:
m="digoxin" 118:2 118:2
do="0.125 mg" 118:3 118:4
mo="p.o." 118:5 118:5
f="q. day" 118:6 118:7
du="nm"
r="nm"
ln="list"
20:
m="enalapril" 118:10 118:10
do="12.5 mg" 118:11 118:12
mo="p.o." 118:13 118:13
f="b.i.d." 119:0 119:0
du="nm"
r="nm"
ln="list"
21:
m="lasix" 119:3 119:3
do="40 mg" 119:4 119:5
mo="p.o." 119:6 119:6
f="b.i.d." 119:7 119:7
du="nm"
r="nm"
ln="list"
22:
m="micronase" 119:10 119:10
do="1.25 mg" 119:11 119:12
mo="p.o." 119:13 119:13
f="q. day" 119:14 120:0
du="nm"
r="nm"
ln="list"
23:
m="coumadin" 120:11 120:11
do="2.5 mg" 120:12 121:0
mo="p.o." 121:1 121:1
f="q. day on even days" 121:2 121:6
du="nm"
r="nm"
ln="list"
24:
m="coumadin" 120:11 120:11
do="5 mg" 121:8 121:9
mo="p.o." 121:1 121:1
f="q. day on odd days" 121:11 121:15
du="nm"
r="nm"
ln="list"
25:
m="multivitamins" 120:3 120:3
do="one tablet" 120:4 120:5
mo="p.o." 120:6 120:6
f="q. day" 120:7 120:8
du="nm"
r="nm"
ln="list"
