1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="500 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q6h prn" 16:7 16:8
du="nm"
r="headache" 16:11 16:11
ln="list"
2:
m="tylenol (acetaminophen)" 16:0 16:3
do="500 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q6h prn" 16:7 16:8
du="nm"
r="headache" 16:11 16:11
ln="list"
3:
m="tylenol (acetaminophen)" 16:0 16:3
do="500 mg" 16:4 16:5
mo="po" 16:6 16:6
f="q6h prn" 16:7 16:8
du="nm"
r="pain" 16:9 16:9
ln="list"
4:
m="atenolol" 17:0 17:0
do="100 mg" 17:1 17:2
mo="po" 17:3 17:3
f="qd" 17:4 17:4
du="nm"
r="nm"
ln="list"
5:
m="calcium citrate" 18:0 18:1
do="950 mg" 18:2 18:3
mo="po " 18:4 18:4
f="bid" 18:5 18:5
du="nm"
r="nm"
ln="list"
6:
m="colace ( docusate sodium )" 19:0 19:4
do="100 mg" 19:5 19:6
mo="po" 19:7 19:7
f="bid" 19:8 19:8
du="nm"
r="nm"
ln="list"
7:
m="gemfibrozil" 20:0 20:0
do="600 mg" 20:1 20:2
mo="po" 20:3 20:3
f="bid" 20:4 20:4
du="nm"
r="nm"
ln="list"
8:
m="hydrochlorothiazide" 21:0 21:0
do="25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
9:
m="nph insulin human ( insulin nph human )" 22:0 22:7
do="15 units" 23:0 23:1
mo="sc" 23:2 23:2
f="at 10 p.m. ( bedtime )" 23:3 23:8
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 24:0 24:0
do="40 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qd" 24:4 24:4
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride immed. rel." 27:3 27:6
do="nm"
mo="po" 27:7 27:7
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="potassium chloride" 29:5 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="potassium chloride" 33:3 33:4
do="nm"
mo="iv" 33:5 33:5
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 34:3 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 34:5 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="niferex-150" 36:0 36:0
do="150 mg" 36:1 36:2
mo="po " 36:3 36:3
f="bid " 36:4 36:4
du="nm"
r="nm"
ln="narrative"
18:
m="levofloxacin" 39:3 39:3
do="nm"
mo="po" 39:4 39:4
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="polysaccharide iron complex" 40:3 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="levofloxacin" 41:2 41:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="levofloxacin" 45:3 45:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="polysaccharide iron complex" 46:0 46:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="simethicone" 47:0 47:0
do="80 mg" 47:1 47:2
mo="po" 47:3 47:3
f="qid prn" 47:4 47:5
du="nm"
r="upset stomach" 47:6 47:7
ln="list"
24:
m="vitamin e ( tocopherol-dl-alpha )" 48:0 48:4
do="1 , 200 units" 48:5 48:8
mo="po" 48:9 48:9
f="qd" 48:10 48:10
du="nm"
r="nm"
ln="list"
25:
m="vitamin b complex" 50:0 50:2
do="1 tab" 50:3 50:4
mo="po" 50:5 50:5
f="qd" 50:6 50:6
du="nm"
r="nm"
ln="list"
26:
m="triamcinolone acetonide 0.5% (triamcinolone a...)" 51:0 51:6
do="nm"
mo="topical tp" 52:0 52:1
f="qid" 52:2 52:2
du="nm"
r="nm"
ln="list"
27:
m="triamcinoloneacetonide 0.5% ( triamcinolone a... )" 51:0 51:6
do="nm"
mo="topical tp" 52:0 52:1
f="qid" 52:2 52:2
du="nm"
r="nm"
ln="list"
28:
m="levofloxacin" 55:0 55:0
do="500 mg" 55:1 55:2
mo="po" 55:3 55:3
f="qd" 55:4 55:4
du="nm"
r="nm"
ln="list"
29:
m="iron supplements" 57:2 57:3
do="nm"
mo="nm"
f="nm"
du="until november" 57:4 57:5
r="nm"
ln="list"
30:
m="iron products" 59:1 59:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="ciprofloxacin" 60:4 60:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="levofloxacin" 60:2 60:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="polysaccharide iron complex" 65:3 66:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levofloxacin" 66:2 66:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="miconazole nitrate 2% powder" 68:0 68:3
do="nm"
mo="topical tp" 68:4 68:5
f="bid" 68:6 68:6
du="nm"
r="nm"
ln="list"
36:
m="maalox-tablets quick dissolve/chewable" 69:0 69:2
do="1-2 tab" 69:3 69:4
mo="po" 69:5 69:5
f="q6h prn" 69:6 70:0
du="nm"
r="upset stomach" 70:1 70:2
ln="list"
37:
m="metformin xr ( metformin extended release )" 71:0 71:6
do="2 , 000 mg" 71:7 71:10
mo="po" 71:11 71:11
f="qd" 71:12 71:12
du="nm"
r="nm"
ln="list"
38:
m="insulin regular human" 72:0 72:2
do="10 units" 80:7 80:8
mo="subcutaneously" 80:9 80:9
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="insulin regular human" 72:0 72:2
do="2 units" 75:7 75:8
mo="subcutaneously" 75:9 75:9
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="insulin regular human" 72:0 72:2
do="3 units" 76:7 76:8
mo="subcutaneously" 76:9 76:9
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="insulin regular human" 72:0 72:2
do="4 units" 77:7 77:8
mo="subcutaneously" 77:9 77:9
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="insulin regular human" 72:0 72:2
do="6 units" 78:7 78:8
mo="subcutaneously" 78:9 78:9
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="insulin regular human" 72:0 72:2
do="8 units" 79:7 79:8
mo="subcutaneously" 79:9 79:9
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="insulin regular human" 72:0 72:2
do="sliding scale" 73:0 73:1
mo="( subcutaneously ) sc" 73:2 73:5
f="ac" 73:6 73:6
du="nm"
r="nm"
ln="list"
45:
m="protonix ( pantoprazole )" 82:0 82:3
do="40 mg" 82:4 82:5
mo="po" 82:6 82:6
f="bid" 82:7 82:7
du="nm"
r="nm"
ln="narrative"
46:
m="lasix" 113:8 113:8
do="nm"
mo="i.v." 113:7 113:7
f="nm"
du="nm"
r="presumed chf" 114:0 114:1
ln="narrative"
47:
m="nexium" 115:9 115:9
do="40 mg" 115:10 115:11
mo="po" 116:0 116:0
f="bid" 116:1 116:1
du="nm"
r="nm"
ln="list"
48:
m="hctz" 116:3 116:3
do="25 mg" 116:4 116:5
mo="po" 116:6 116:6
f="qd" 116:7 116:7
du="nm"
r="nm"
ln="list"
49:
m="lisinopril" 116:9 116:9
do="40 mg" 116:10 116:11
mo="po" 116:12 116:12
f="qd" 117:0 117:0
du="nm"
r="nm"
ln="list"
50:
m="metformin xr" 117:8 117:9
do="2000 mg" 117:10 117:11
mo="po" 117:12 117:12
f="qd" 117:13 117:13
du="nm"
r="nm"
ln="list"
51:
m="tiazac" 117:2 117:2
do="240 mg" 117:3 117:4
mo="po" 117:5 117:5
f="qd" 117:6 117:6
du="nm"
r="nm"
ln="list"
52:
m="diltiazem" 130:4 130:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="metoprolol" 130:9 130:9
do="uptitrated." 131:0 131:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="vanco" 134:3 134:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="vanco/levo/falgyl" 134:0 134:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="vanco/levo/flagyl" 134:0 134:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="levo/flagyl" 135:2 135:2
do="nm"
mo="p.o." 135:5 135:5
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="gemfibrozil" 137:12 137:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="asa/nsaids" 138:10 138:10
do="nm"
mo="nm"
f="nm"
du="for 6 - 8 wks" 138:12 139:3
r="nm"
ln="narrative"
60:
m="asa/nsaids" 138:10 138:10
do="nm"
mo="nm"
f="nm"
du="for 6- 8 wks" 138:12 139:3
r="nm"
ln="narrative"
61:
m="metformin" 139:6 139:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="nph" 139:12 139:12
do="15 units" 139:10 139:11
mo="nm"
f="at bedtime" 139:14 139:15
du="nm"
r="nm"
ln="narrative"
63:
m="ace inhibitor." 141:5 141:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="wellbutrin effexor" 142:4 142:5
do="nm"
mo="nm"
f="nm"
du="7d" 142:6 142:6
r="nm"
ln="narrative"
65:
m="levofloxacin" 153:6 153:6
do="nm"
mo="nm"
f="nm"
du="14-day course...until 4/18/04" 153:3 153:4,153:8 153:9
r="nm"
ln="narrative"
