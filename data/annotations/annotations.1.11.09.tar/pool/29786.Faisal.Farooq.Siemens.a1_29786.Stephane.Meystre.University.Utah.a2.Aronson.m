1:
m="clonazepam" 19:0 19:0
do="0.5 mg" 19:1 19:2
mo="po " 19:3 19:3
f="qd " 19:4 19:4
du="nm"
r="nm"
ln="list"
2:
m="diflucan" 22:3 22:3
do="nm"
mo="po" 22:4 22:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="clonazepam" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="fluconazole" 23:5 23:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="diflucan ( fluconazole )" 25:0 25:3
do="100 mg" 25:4 25:5
mo="po " 25:6 25:6
f="qd" 25:7 25:7
du="x 12 doses" 25:8 25:10
r="nm"
ln="list"
6:
m="clonazepam" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="fluconazole" 31:5 31:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="clonazepam" 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="fluconazole" 32:5 32:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 34:0 34:0
do="5 mg" 34:1 34:2
mo="po" 34:3 34:3
f="qd" 34:4 34:4
du="nm"
r="nm"
ln="list"
11:
m="kcl immediate release" 37:3 37:5
do="nm"
mo="po" 37:6 37:6
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="potassium chloride" 38:5 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="kcl" 42:3 42:3
do="nm"
mo="iv" 42:4 42:4
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 43:3 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="potassium chloride" 43:5 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="mom ( magnesium hydroxide )" 45:0 45:4
do="30 milliliters" 45:5 45:6
mo="po" 45:7 45:7
f="qd" 45:8 45:8
du="nm"
r="constipation" 46:6 46:6
ln="narrative"
18:
m="maalox-tablets quick dissolve/chewable" 47:0 47:2
do="1-2 tab" 47:3 47:4
mo="po" 47:5 47:5
f="q6h prn" 47:6 48:0
du="nm"
r="upset stomach" 48:1 48:2
ln="narrative"
19:
m="protonix ( pantoprazole )" 49:0 49:3
do="40 mg" 49:4 49:5
mo="po" 49:6 49:6
f="qd" 49:7 49:7
du="nm"
r="nm"
ln="narrative"
20:
m="lipitor ( atorvastatin )" 50:0 50:3
do="20 mg" 50:4 50:5
mo="po" 50:6 50:6
f="qhs" 50:7 50:7
du="nm"
r="nm"
ln="list"
21:
m="atenolol" 51:0 51:0
do="25 mg" 51:1 51:2
mo="po" 51:3 51:3
f="qd" 51:4 51:4
du="nm"
r="nm"
ln="narrative"
22:
m="ecasa ( aspirin enteric coated )" 52:0 52:5
do="81 mg" 52:6 52:7
mo="po" 52:8 52:8
f="qd" 52:9 52:9
du="nm"
r="nm"
ln="list"
23:
m="remeron ( mirtazapine )" 53:0 53:3
do="15 mg" 53:4 53:5
mo="po " 53:6 53:6
f="qhs " 53:7 53:7
du="nm"
r="nm"
ln="narrative"
24:
m="celexa ( citalopram )" 54:0 54:3
do="20 mg" 54:4 54:5
mo="po" 54:6 54:6
f="qd" 54:7 54:7
du="nm"
r="nm"
ln="list"
25:
m="metformin" 55:0 55:0
do="500 mg" 55:1 55:2
mo="po" 55:3 55:3
f="bid" 55:4 55:4
du="nm"
r="nm"
ln="list"
26:
m="morphine" 82:6 82:6
do="4 mg" 82:7 83:0
mo="nm"
f="nm"
du="nm"
r="pain" 80:2 80:2
ln="narrative"
27:
m="nitroglycerin." 82:2 82:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 80:2 80:2
ln="narrative"
28:
m="lidocaine susp." 83:9 83:10
do="nm"
mo="po" 83:8 83:8
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="maalox" 83:6 83:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="celexa" 100:4 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="mdd-continue" 100:1 100:1
ln="narrative"
31:
m="clonazepam" 100:6 100:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="mdd-continue" 100:1 100:1
ln="narrative"
32:
m="remeron" 100:2 100:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="mdd-continue" 100:1 100:1
ln="narrative"
33:
m="diflucan." 101:7 101:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="esophagitis" 101:1 101:1
ln="narrative"
34:
m="fluconazole" 102:10 102:10
do="nm"
mo="nm"
f="nm"
du="two week course" 102:6 102:8
r="nm"
ln="narrative"
