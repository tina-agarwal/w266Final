1:
m="procardia xl" 28:5 28:6
do="90 mg" 28:7 29:0
mo="nm"
f="q.d" 29:1 29:1
du="nm"
r="nm"
ln="list"
2:
m="toprol xl" 28:0 28:1
do="200 mg" 28:2 28:3
mo="nm"
f="q.d." 28:4 28:4
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 29:8 29:8
do="325 mg" 29:9 29:10
mo="nm"
f="q.d." 29:11 29:11
du="nm"
r="nm"
ln="list"
4:
m="lipitor" 29:3 29:3
do="20 mg" 29:4 29:5
mo="nm"
f="q.d." 29:6 29:6
du="nm"
r="nm"
ln="list"
5:
m="zantac" 29:13 29:13
do="150 mg" 29:14 29:15
mo="nm"
f="b.i.d." 30:0 30:0
du="nm"
r="nm"
ln="list"
6:
m="nph humulin insulin" 30:2 30:4
do="18 units" 30:10 30:11
mo="subcutaneously" 31:1 31:1
f="each evening" 30:12 31:0
du="nm"
r="nm"
ln="list"
7:
m="nph humulin insulin" 30:2 30:4
do="32 units" 30:5 30:6
mo="subcutaneously" 31:1 31:1
f="each morning" 30:7 30:8
du="nm"
r="nm"
ln="list"
8:
m="minipress" 31:8 31:8
do="1 mg" 31:9 31:10
mo="nm"
f="b.i.d." 31:11 31:11
du="nm"
r="nm"
ln="list"
9:
m="valium" 31:3 31:3
do="5 mg" 31:4 31:5
mo="nm"
f="q.d" 31:6 31:6
du="nm"
r="nm"
ln="list"
10:
m="corvert" 50:6 50:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="rapid atrial flutter" 49:7 49:9
ln="narrative"
11:
m="diltiazem" 51:6 51:6
do="nm"
mo="nm"
f="nm"
du="for 24 hours" 51:7 51:9
r="rapid atrial flutter" 49:7 49:9
ln="narrative"
12:
m="lopressor" 51:4 51:4
do="nm"
mo="nm"
f="nm"
du="for 24 hours." 51:7 51:9
r="rapid atrial flutter" 49:7 49:9
ln="narrative"
13:
m="antibiotics" 54:0 54:0
do="nm"
mo="by mouth." 54:1 54:2
f="nm"
du="nm"
r="erythema" 53:5 53:5
ln="narrative"
14:
m="axid" 56:1 56:1
do="150 mg" 56:2 56:3
mo="nm"
f="b.i.d" 56:4 56:4
du="nm"
r="nm"
ln="list"
15:
m="lipitor" 56:6 56:6
do="20 mg" 56:7 57:0
mo="nm"
f="once a day" 57:1 57:3
du="nm"
r="nm"
ln="list"
16:
m="nph humulin insulin" 57:5 57:7
do="18 units" 57:13 57:14
mo="nm"
f="every evening;" 58:0 58:1
du="nm"
r="nm"
ln="list"
17:
m="nph humulin insulin" 57:5 57:7
do="32 units" 57:8 57:9
mo="nm"
f="every morning" 57:10 57:11
du="nm"
r="nm"
ln="list"
18:
m="diltiazem" 58:2 58:2
do="60 mg" 58:3 58:4
mo="nm"
f="t.i.d." 58:5 58:5
du="nm"
r="nm"
ln="list"
19:
m="lopressor" 58:7 58:7
do="150 mg" 58:8 58:9
mo="nm"
f="b.i.d." 58:10 58:10
du="nm"
r="nm"
ln="list"
20:
m="enteric coated aspirin" 59:0 59:2
do="125 mg" 59:3 59:4
mo="nm"
f="once a day" 59:5 59:7
du="nm"
r="nm"
ln="list"
21:
m="valium" 59:9 59:9
do="5 mg" 59:10 59:11
mo="nm"
f="once a day" 59:12 59:14
du="nm"
r="nm"
ln="list"
22:
m="keflex" 60:0 60:0
do="500 mg" 60:1 60:2
mo="nm"
f="four times a day" 60:3 60:6
du="for 7 days" 60:7 60:9
r="nm"
ln="list"
23:
m="percocet" 60:11 60:11
do="1 to 2 tablets" 60:12 60:15
mo="nm"
f="every four hours as needed" 61:0 61:4
du="nm"
r="pain." 61:6 61:6
ln="list"
