1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 20:0 20:0
do="50 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
3:
m="enalapril maleate" 21:0 21:1
do="20 mg" 21:2 21:3
mo="po" 21:4 21:4
f="bid" 21:5 21:5
du="nm"
r="nm"
ln="list"
4:
m="kcl immediate release" 24:3 24:5
do="nm"
mo="po" 24:6 24:6
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="enalapril maleate" 25:3 25:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="potassium chloride" 26:0 26:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="kcl immediate release" 29:3 29:5
do="nm"
mo="po" 29:6 29:6
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="enalapril maleate" 30:3 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 31:0 31:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="nifedipine ( extended release ) ( nifedipine ( sl... )" 32:0 32:9
do="60 mg" 33:0 33:1
mo="po" 33:2 33:2
f="qd" 33:3 33:3
du="nm"
r="nm"
ln="list"
11:
m="lipitor ( atorvastatin )" 36:0 36:3
do="20 mg" 36:4 36:5
mo="po" 36:6 36:6
f="qhs" 36:7 36:7
du="nm"
r="nm"
ln="list"
12:
m="zantac ( ranitidine hcl )" 37:0 37:4
do="150 mg" 37:5 37:6
mo="po" 37:7 37:7
f="bid" 37:8 37:8
du="nm"
r="nm"
ln="list"
13:
m="metformin" 38:0 38:0
do="500 mg" 38:1 38:2
mo="po" 38:3 38:3
f="bid" 38:4 38:4
du="nm"
r="nm"
ln="list"
14:
m="imodium ( loperamide hcl )" 39:0 39:4
do="2-4 mg" 39:5 39:6
mo="po" 39:7 39:7
f="q6h prn" 39:8 39:9
du="nm"
r="diarrhea" 39:10 39:10
ln="list"
15:
m="protonix ( pantoprazole )" 40:0 40:3
do="40 mg" 40:4 40:5
mo="po" 40:6 40:6
f="qd" 40:7 40:7
du="nm"
r="nm"
ln="list"
16:
m="cipro/flagyl." 61:2 61:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="protonix" 66:7 66:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="asa" 68:1 68:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="atenolol" 68:3 68:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="enalapril" 68:7 68:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="lipitor" 68:5 68:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="nifedipine xl" 68:9 68:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="zantac" 68:12 68:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="metformin" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="immodium" 85:3 85:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="diarrhea" 85:5 85:5
ln="narrative"
26:
m="protonix" 87:6 87:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="heartburn" 87:8 87:8
ln="narrative"
27:
m="abx" 89:4 89:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="cipro/flagyl." 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="asa/bb/statin/acei/ccb." 91:7 91:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="riss." 92:1 92:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="phosphate" 99:0 99:0
do="nm"
mo="nm"
f="night before the colonoscopy." 100:0 100:3
du="nm"
r="nm"
ln="narrative"
