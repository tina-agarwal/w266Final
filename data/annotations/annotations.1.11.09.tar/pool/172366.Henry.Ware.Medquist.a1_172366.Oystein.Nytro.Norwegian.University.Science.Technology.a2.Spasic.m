1:
m="etomidate" 22:4 22:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="succinylcholine" 22:6 22:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="fentanyl." 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="sedated" 22:9 22:9
ln="narrative"
4:
m="vancomycin" 23:7 23:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="versed" 23:1 23:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="sedated" 22:9 22:9
ln="narrative"
6:
m="lactated ringer's" 24:8 24:9
do="2200 ml" 24:5 24:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="levofloxacin" 24:1 24:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="ffp" 25:8 25:8
do="one unit" 25:5 25:6
mo="nm"
f="nm"
du="nm"
r="an attempt to reverse anticoagulation" 24:11 25:3
ln="narrative"
9:
m="epinephrine" 26:9 26:9
do="nm"
mo="injection" 27:0 27:0
f="nm"
du="nm"
r="hypotension" 26:4 26:4
ln="narrative"
10:
m="ffp" 28:0 28:0
do="another unit" 27:7 27:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="coumadin" 39:6 39:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 39:8 39:8
ln="narrative"
12:
m="amiodarone" 61:1 61:1
do="200 mg" 61:2 61:3
mo="by mouth" 61:4 61:5
f="daily" 61:6 61:6
du="nm"
r="nm"
ln="list"
13:
m="calcium" 62:1 62:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="colace" 63:1 63:1
do="100 mg" 63:2 63:3
mo="by mouth" 63:4 63:5
f="t.i.d." 63:6 63:6
du="nm"
r="nm"
ln="list"
15:
m="coumadin" 64:1 64:1
do="alternating doses of 4mg and 3 mg." 64:2 64:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="diltiazem cd" 65:1 65:2
do="360 mg" 65:3 65:4
mo="p.o." 65:5 65:5
f="daily." 65:6 65:6
du="nm"
r="nm"
ln="list"
17:
m="aspirin" 66:1 66:1
do="81 mg" 66:2 66:3
mo="p.o." 66:4 66:4
f="daily" 66:5 66:5
du="nm"
r="nm"
ln="list"
18:
m="folate" 67:1 67:1
do="1 mg" 67:2 67:3
mo="p.o." 67:4 67:4
f="daily" 67:5 67:5
du="nm"
r="nm"
ln="list"
19:
m="lisinopril" 68:1 68:1
do="10 mg" 68:2 68:3
mo="p.o." 68:4 68:4
f="daily." 68:5 68:5
du="nm"
r="nm"
ln="list"
20:
m="metamucil" 69:1 69:1
do="nm"
mo="nm"
f="p.r.n." 69:2 69:2
du="nm"
r="nm"
ln="list"
21:
m="clopidogrel" 70:1 70:1
do="75 mg" 70:2 70:3
mo="p.o." 70:4 70:4
f="daily" 70:5 70:5
du="nm"
r="nm"
ln="list"
22:
m="potassium" 71:1 71:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="protonix" 72:1 72:1
do="40 mg" 72:2 72:3
mo="p.o." 72:4 72:4
f="daily" 72:5 72:5
du="nm"
r="nm"
ln="list"
24:
m="simvastatin" 73:1 73:1
do="80 mg" 73:2 73:3
mo="p.o." 73:4 73:4
f="daily" 73:5 73:5
du="nm"
r="nm"
ln="list"
25:
m="synthroid" 74:1 74:1
do="25 mcg" 74:2 74:3
mo="p.o." 74:4 74:4
f="daily" 74:5 74:5
du="nm"
r="nm"
ln="list"
26:
m="thiamine" 75:1 75:1
do="100 mg" 75:2 75:3
mo="p.o." 75:4 75:4
f="daily." 75:5 75:5
du="nm"
r="nm"
ln="list"
27:
m="metoprolol sr" 76:1 76:2
do="100 mg" 76:3 76:4
mo="p.o." 76:5 76:5
f="b.i.d." 76:6 76:6
du="nm"
r="nm"
ln="list"
28:
m="zyprexa" 77:1 77:1
do="2.5 mg" 77:2 77:3
mo="nm"
f="at bedtime p.r.n." 77:4 77:6
du="nm"
r="nm"
ln="list"
29:
m="heparin" 102:2 102:2
do="nm"
mo="drip" 102:3 102:3
f="nm"
du="nm"
r="the patient's chronic AF" 102:9 103:2
ln="narrative"
30:
m="ffp" 103:7 103:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="aspirin" 105:4 105:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's cardiac stents." 106:0 106:3
ln="narrative"
32:
m="plavix" 105:6 105:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's cardiac stents." 106:0 106:3
ln="narrative"
33:
m="lasix" 106:6 106:6
do="nm"
mo="bolus" 106:5 106:5
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="beta-blockade" 110:5 110:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension" 110:2 110:2
ln="narrative"
35:
m="calcium channel blockers" 110:7 111:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension" 110:2 110:2
ln="narrative"
36:
m="ace inhibitors" 111:4 111:5
do="nm"
mo="iv" 111:3 111:3
f="nm"
du="nm"
r="hypertension" 110:2 110:2
ln="narrative"
37:
m="furosemide" 112:10 112:10
do="nm"
mo="drip" 113:0 113:0
f="nm"
du="nm"
r="an elevated INR" 114:1 114:3
ln="narrative"
38:
m="furosemide" 112:10 112:10
do="nm"
mo="drip" 113:0 113:0
f="nm"
du="nm"
r="bleeding" 113:8 113:8
ln="narrative"
39:
m="nitroglycerin" 112:6 112:6
do="nm"
mo="drip" 112:7 112:7
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="ginger blood product" 113:2 113:4
do="nm"
mo="drip" 113:0 113:0
f="nm"
du="nm"
r="an elevated INR" 114:1 114:3
ln="narrative"
41:
m="ginger blood product" 113:2 113:4
do="nm"
mo="drip" 113:0 113:0
f="nm"
du="nm"
r="bleeding" 113:8 113:8
ln="narrative"
42:
m="lasix" 120:4 120:4
do="nm"
mo="drip" 120:5 120:5
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="lasix" 121:5 121:5
do="nm"
mo="drip" 121:6 121:6
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="cardiac medications" 123:3 123:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="nitroglycerin" 125:8 125:8
do="nm"
mo="drip" 125:9 125:9
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="nitro paste." 126:6 126:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="red blood cell" 127:11 128:1
do="nm"
mo="transfusion" 128:2 128:2
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="nitroglycerin" 128:6 128:6
do="nm"
mo="drip" 128:7 128:7
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="morphine" 134:8 134:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="dilaudid" 135:5 135:5
do="nm"
mo="nm"
f="p.r.n." 135:6 135:6
du="nm"
r="nm"
ln="narrative"
51:
m="dilaudid" 136:6 136:6
do="nm"
mo="nm"
f="p.r.n." 136:7 136:7
du="nm"
r="nm"
ln="narrative"
52:
m="zyprexa" 136:10 136:10
do="2.5" 137:0 137:0
mo="nm"
f="at bedtime p.r.n." 137:1 137:3
du="nm"
r="nm"
ln="narrative"
53:
m="haldol" 137:7 137:7
do="nm"
mo="nm"
f="p.r.n. as needed" 137:10 138:1
du="nm"
r="nm"
ln="narrative"
54:
m="nitroglycerin" 144:3 144:3
do="nm"
mo="drip" 144:4 144:4
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="nitro paste" 144:6 144:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="diltiazem cd" 145:1 145:2
do="360" 145:3 145:3
mo="p.o." 145:4 145:4
f="daily" 145:5 145:5
du="nm"
r="nm"
ln="narrative"
57:
m="lopressor sr" 145:7 145:8
do="100 mg" 145:9 145:10
mo="p.o." 145:11 145:11
f="b.i.d." 145:12 145:12
du="nm"
r="nm"
ln="narrative"
58:
m="amiodarone" 146:6 146:6
do="200 mg" 146:7 146:8
mo="p.o." 146:9 146:9
f="daily" 146:10 146:10
du="nm"
r="nm"
ln="narrative"
59:
m="lisinopril" 146:0 146:0
do="10 mg" 146:1 146:2
mo="p.o." 146:3 146:3
f="daily" 146:4 146:4
du="nm"
r="nm"
ln="narrative"
60:
m="aspirin" 148:1 148:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="cardiac stents." 148:7 148:8
ln="narrative"
61:
m="plavix" 148:3 148:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="cardiac stents." 148:7 148:8
ln="narrative"
62:
m="lasix" 154:1 154:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="nexium" 158:1 158:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="lasix" 160:5 160:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="lasix" 162:1 162:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="potassium" 162:10 162:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
67:
m="packed red blood cells" 166:11 167:1
do="one unit" 166:8 166:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="lasix" 167:3 167:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="potassium" 167:5 167:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="coumadin" 168:8 168:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="heparin" 168:4 168:4
do="nm"
mo="subcutaneous" 168:3 168:3
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="vancomycin" 171:1 171:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="mrsa-infected mesh" 171:3 171:4
ln="narrative"
73:
m="vancomycin." 173:0 173:0
do="nm"
mo="nm"
f="nm"
du="long-term" 172:7 172:7
r="nm"
ln="narrative"
74:
m="synthroid" 175:1 175:1
do="home dose" 175:3 175:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
75:
m="riss." 176:1 176:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
