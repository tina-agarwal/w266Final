1:
m="persantine" 28:0 28:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="persantine" 39:4 39:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nitroglycerin." 48:0 48:0
do="one" 47:10 47:10
mo="sublingual" 47:11 47:11
f="nm"
du="nm"
r="chest heaviness" 46:7 46:8
ln="narrative"
4:
m="insulin 70/30" 49:12 50:0
do="28 units" 50:1 50:2
mo="nm"
f="q a.m." 50:3 50:4
du="nm"
r="nm"
ln="list"
5:
m="insulin 70/30" 49:12 50:0
do="5 units" 50:6 50:7
mo="nm"
f="q p.m." 50:8 50:9
du="nm"
r="nm"
ln="list"
6:
m="lasix" 49:5 49:5
do="40 mg." 49:6 49:7
mo="nm"
f="per day." 49:8 49:9
du="nm"
r="nm"
ln="list"
7:
m="enteric coated aspirin" 51:10 51:12
do="325 mg" 51:13 51:14
mo="nm"
f="q day." 52:0 52:1
du="nm"
r="nm"
ln="list"
8:
m="verapamil sr" 51:2 51:3
do="120 mg" 51:4 51:5
mo="po" 51:6 51:6
f="b.i.d." 51:7 51:7
du="nm"
r="nm"
ln="list"
9:
m="kcl" 52:4 52:4
do="10 meq" 52:5 52:6
mo="po" 52:7 52:7
f="q day." 52:8 52:9
du="nm"
r="nm"
ln="list"
10:
m="premarin" 52:12 52:12
do="0.625 mg" 52:13 52:14
mo="po" 52:15 52:15
f="q day." 52:16 52:17
du="nm"
r="nm"
ln="list"
11:
m="atenolol" 53:8 53:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="zestril" 53:2 53:2
do="20 mg" 53:3 53:4
mo="nm"
f="b.i.d." 53:5 53:5
du="nm"
r="nm"
ln="list"
13:
m="tofranil" 54:0 54:0
do="75 mg" 54:1 54:2
mo="po" 54:3 54:3
f="q hs." 54:4 54:5
du="nm"
r="nm"
ln="list"
14:
m="albuterol nebulizer" 92:0 92:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="cefuroxime" 95:5 95:5
do="nm"
mo="intravenous" 95:4 95:4
f="nm"
du="nm"
r="cough" 96:3 96:3
ln="narrative"
16:
m="cefuroxime" 95:5 95:5
do="nm"
mo="intravenous" 95:4 95:4
f="nm"
du="nm"
r="shortness of breath" 96:5 96:7
ln="narrative"
17:
m="antibiotics." 100:7 100:7
do="nm"
mo="intravenous" 100:3 100:3
f="nm"
du="nm"
r="pen-sensitive e-coli" 99:6 99:7
ln="narrative"
18:
m="antibiotics." 100:7 100:7
do="nm"
mo="po" 100:6 100:6
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="albuterol inhaler" 113:5 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="enteric coated aspirin" 117:5 117:7
do="325 mg" 117:8 117:9
mo="po" 117:10 117:10
f="q day." 118:0 118:1
du="nm"
r="nm"
ln="list"
21:
m="cefuroxime" 118:4 118:4
do="500 mg" 118:5 118:6
mo="po" 118:7 118:7
f="b.i.d." 118:8 118:8
du="nm"
r="nm"
ln="list"
22:
m="lasix" 119:10 119:10
do="40 mg" 119:11 119:12
mo="po" 119:13 119:13
f="q day." 119:14 119:15
du="nm"
r="nm"
ln="list"
23:
m="premarin" 119:2 119:2
do="0.625 mg" 119:3 119:4
mo="po" 119:5 119:5
f="q day." 119:6 119:7
du="nm"
r="nm"
ln="list"
24:
m="tofranil" 120:0 120:0
do="75 mg" 120:1 120:2
mo="po" 120:3 120:3
f="q hs." 120:4 120:5
du="nm"
r="nm"
ln="list"
25:
m="verapamil sr" 120:15 121:0
do="120 mg" 121:1 121:2
mo="po" 121:3 121:3
f="b.i.d." 121:4 121:4
du="nm"
r="nm"
ln="list"
26:
m="zestril" 120:8 120:8
do="20 mg" 120:9 120:10
mo="po" 120:11 120:11
f="b.i.d." 120:12 120:12
du="nm"
r="nm"
ln="list"
27:
m="insulin 70/30" 121:7 121:8
do="28 units" 121:9 121:10
mo="nm"
f="q a.m." 121:11 121:12
du="nm"
r="nm"
ln="list"
28:
m="insulin 70/30" 121:7 121:8
do="5 units" 121:14 121:15
mo="subcue." 122:2 122:2
f="q p.m." 122:0 122:1
du="nm"
r="nm"
ln="list"
29:
m="potassium slow release" 122:5 122:7
do="10 meq" 122:8 122:9
mo="po" 122:10 122:10
f="q day." 122:11 122:12
du="nm"
r="nm"
ln="list"
30:
m="albuterol inhaler" 123:0 123:1
do="two puffs" 123:2 123:3
mo="inhaled" 123:4 123:4
f="q.i.d." 123:5 123:5
du="nm"
r="nm"
ln="list"
31:
m="albuterol inhaler" 127:4 127:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="antibiotics" 128:5 128:5
do="nm"
mo="nm"
f="nm"
du="ten day course" 128:1 128:3
r="presumed bronchitis" 128:7 128:8
ln="narrative"
