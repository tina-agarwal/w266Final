1:
m="aspirin enteric coated" 19:0 19:2
do="81 mg" 19:3 19:4
mo="po" 19:5 19:5
f="daily" 19:6 19:6
du="nm"
r="nm"
ln="list"
2:
m="lipitor ( atorvastatin )" 21:0 21:3
do="10 mg" 21:4 21:5
mo="po" 21:6 21:6
f="daily" 21:7 21:7
du="nm"
r="nm"
ln="list"
3:
m="colestipol hydrochloride" 23:0 23:1
do="10 gm" 23:2 23:3
mo="po" 23:4 23:4
f="daily" 23:5 23:5
du="5" 26:7 26:7
r="nm"
ln="list"
4:
m="insulin glargine" 27:0 27:1
do="14 units" 27:2 27:3
mo="sc" 27:4 27:4
f="daily" 27:5 27:5
du="nm"
r="nm"
ln="list"
5:
m="humalog insulin ( insulin lispro )" 28:0 28:5
do="sliding scale" 29:0 29:1
mo="subcutaneous ) sc" 29:3 29:5
f="ac" 29:6 29:6
du="nm"
r="nm"
ln="list"
6:
m="humalog insulin ( insulin lispro )" 28:0 28:5
do="sliding scale" 29:0 29:1
mo="subcutaneous ) sc" 29:3 29:5
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="imdur er ( isosorbide mononitrate ( sr ) )" 43:0 43:8
do="60 mg" 43:9 43:10
mo="po" 43:11 43:11
f="daily" 43:12 43:12
du="nm"
r="nm"
ln="list"
8:
m="klor-con ( kcl slow release )" 49:0 49:5
do="20 meq" 49:6 49:7
mo="po" 49:8 49:8
f="daily " 49:9 49:9
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 50:3 50:4
do="20 meq" 51:1 51:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="toprol xl ( metoprolol succinate extended release )" 52:0 52:7
do="50 mg" 53:0 53:1
mo="po" 53:2 53:2
f="bedtime" 53:3 53:3
du="nm"
r="nm"
ln="list"
11:
m="flomax ( tamsulosin )" 58:0 58:3
do="0.4 mg" 58:4 58:5
mo="po" 58:6 58:6
f="daily" 58:7 58:7
du="nm"
r="nm"
ln="list"
12:
m="torsemide" 60:0 60:0
do="150 mg" 60:1 60:2
mo="po" 60:3 60:3
f="daily" 60:4 60:4
du="nm"
r="nm"
ln="list"
13:
m="metolazone" 83:0 83:0
do="nm"
mo="nm"
f="as needed" 83:2 83:3
du="nm"
r="nm"
ln="narrative"
14:
m="metolazone" 85:3 85:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="aspirin" 104:0 104:0
do="81" 104:1 104:1
mo="nm"
f="qd" 104:2 104:2
du="nm"
r="nm"
ln="list"
16:
m="imdur er" 104:11 104:12
do="60" 104:13 104:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lipitor" 104:8 104:8
do="10" 104:9 104:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="torsemide" 104:4 104:4
do="150" 104:5 104:5
mo="nm"
f="qd" 104:6 104:6
du="nm"
r="nm"
ln="list"
19:
m="zemplar" 104:15 104:15
do="1mg" 104:16 104:16
mo="nm"
f="daily" 105:0 105:0
du="nm"
r="nm"
ln="list"
20:
m="colestipol" 105:13 105:13
do="1g" 105:14 105:14
mo="nm"
f="qd" 106:0 106:0
du="nm"
r="nm"
ln="list"
21:
m="flomax" 105:9 105:9
do="0.4" 105:10 105:10
mo="nm"
f="qd" 105:11 105:11
du="nm"
r="nm"
ln="list"
22:
m="klorcon slow release" 105:2 105:4
do="20 meq" 105:5 105:6
mo="nm"
f="daily" 105:7 105:7
du="nm"
r="nm"
ln="list"
23:
m="humalog" 106:11 106:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="lantus" 106:6 106:6
do="14 unit" 106:7 106:8
mo="sc" 106:9 106:9
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="metolazone" 106:14 106:14
do="5mg" 106:15 106:15
mo="nm"
f="as needed" 106:16 107:0
du="nm"
r="nm"
ln="list"
26:
m="toprol-xl" 106:2 106:2
do="50" 106:3 106:3
mo="nm"
f="qhs" 106:4 106:4
du="nm"
r="nm"
ln="list"
27:
m="zemplar" 145:13 145:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="home medications" 146:9 146:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="metolazone" 146:1 146:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="zemplar" 153:2 153:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="metolazone" 154:2 154:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="klor-con" 155:4 155:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="torsemide" 155:2 155:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="torsemide" 156:1 156:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="zemplar" 161:2 161:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="metolazone" 162:2 162:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="klor-con" 163:4 163:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="torsemide" 163:2 163:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="torsemide" 164:0 164:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
