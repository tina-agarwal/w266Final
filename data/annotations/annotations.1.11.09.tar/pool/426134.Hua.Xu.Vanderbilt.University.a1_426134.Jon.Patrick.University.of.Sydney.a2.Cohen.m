1:
m="ecasa ( aspirin enteric coated )" 19:0 19:5
do="325 mg" 19:6 19:7
mo="po" 19:8 19:8
f="qd" 19:9 19:9
du="nm"
r="nm"
ln="list"
2:
m="wellbutrin ( bupropion hcl )" 24:0 24:4
do="200 mg" 24:5 24:6
mo="po" 24:7 24:7
f="qd" 24:8 24:8
du="nm"
r="nm"
ln="list"
3:
m="colace ( docusate sodium )" 25:0 25:4
do="100 mg" 25:5 25:6
mo="po" 25:7 25:7
f="bid" 25:8 25:8
du="nm"
r="nm"
ln="list"
4:
m="feso4 ( ferrous sulfate )" 26:0 26:4
do="300 mg" 26:5 26:6
mo="po" 26:7 26:7
f="bid" 26:8 26:8
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin 1/150 ( 0.4 mg )" 27:0 27:5
do="1 tab" 27:6 27:7
mo="sl" 27:8 27:8
f="q5min x 3 prn" 27:9 28:0
du="nm"
r="chest pain" 28:1 28:2
ln="list"
6:
m="zocor ( simvastatin )" 29:0 29:3
do="40 mg" 29:4 29:5
mo="po" 29:6 29:6
f="qhs" 29:7 29:7
du="nm"
r="nm"
ln="list"
7:
m="zestril ( lisinopril )" 32:0 32:3
do="10 mg" 32:4 32:5
mo="po" 32:6 32:6
f="qd" 32:7 32:7
du="nm"
r="nm"
ln="list"
8:
m="potassium chloride" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 35:0 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride" 36:3 36:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 37:0 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="atenolol" 38:0 38:0
do="50 mg" 38:1 38:2
mo="po" 38:3 38:3
f="bid" 38:4 38:4
du="nm"
r="nm"
ln="list"
13:
m="prilosec ( omeprazole )" 40:0 40:3
do="20 mg" 40:4 40:5
mo="po" 40:6 40:6
f="qd" 40:7 40:7
du="nm"
r="nm"
ln="list"
14:
m="ace-i" 61:2 61:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="asa" 61:4 61:4
do="nm"
mo="nm"
f="nm"
du="until day of adm" 61:5 61:8
r="nm"
ln="narrative"
16:
m="atenolol" 61:0 61:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="ntg" 63:1 63:1
do="nm"
mo="sl" 63:2 63:2
f="x3" 63:3 63:3
du="nm"
r="shoulder pain" 62:2 62:3
ln="narrative"
18:
m="heparin" 65:2 65:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="unstable angina." 65:4 65:5
ln="narrative"
19:
m="tylenol" 66:8 66:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="l shoulder discomfort" 65:9 66:0
ln="narrative"
20:
m="zestril" 71:12 71:12
do="10 mg" 71:13 71:14
mo="by mouth" 71:15 71:16
f="once a day." 72:0 72:2
du="nm"
r="nm"
ln="narrative"
21:
m="medicines" 72:8 72:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="nitroglycerin" 76:0 76:0
do="nm"
mo="nm"
f="once every 5 minutes up to three times;" 76:1 76:8
du="nm"
r="chest pain" 75:5 75:6
ln="narrative"
23:
m="zestril" 82:12 82:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="zantac" 83:9 83:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
