1:
m="colace (docusate sodium)" 17:0 17:4
do="100 mg" 17:5 17:6
mo="po" 17:7 17:7
f="bid" 17:8 17:8
du="nm"
r="nm"
ln="list"
2:
m="lasix (furosemide)" 18:0 18:3
do="20 mg" 18:4 18:5
mo="po" 18:6 18:6
f="qd" 18:7 18:7
du="nm"
r="nm"
ln="list"
3:
m="hydralazine hcl" 19:0 19:1
do="10 mg" 19:2 19:3
mo="iv" 19:4 19:4
f="q6h prn" 19:5 19:6
du="nm"
r="nm"
ln="list"
4:
m="insulin regular human" 20:0 20:2
do="0 units" 22:9 22:10
mo="subcutaneously" 22:11 22:11
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="insulin regular human" 20:0 20:2
do="10 units" 28:7 28:8
mo="subcutaneously" 28:9 28:9
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="insulin regular human" 20:0 20:2
do="2 units" 23:7 23:8
mo="subcutaneously" 23:9 23:9
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="insulin regular human" 20:0 20:2
do="3 units" 24:7 24:8
mo="subcutaneously" 24:9 24:9
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="insulin regular human" 20:0 20:2
do="4 units" 25:7 25:8
mo="subcutaneously" 25:9 25:9
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="insulin regular human" 20:0 20:2
do="6 units" 26:7 26:8
mo="subcutaneously" 26:9 26:9
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="insulin regular human" 20:0 20:2
do="8 units" 27:7 27:8
mo="subcutaneously" 27:9 27:9
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="insulin regular human" 20:0 20:2
do="sliding scale" 21:0 21:1
mo="( subcutaneously ) sc" 21:2 21:5
f="qac" 21:6 21:6
du="nm"
r="nm"
ln="list"
12:
m="insulin regular human" 20:0 20:2
do="sliding scale" 21:0 21:1
mo="( subcutaneously ) sc" 21:2 21:5
f="qhs" 21:8 21:8
du="nm"
r="nm"
ln="list"
13:
m="insulin regular human" 20:0 20:2
do="sliding scale" 21:0 21:1
mo="subcutaneously...sc" 21:3 21:3,21:5 21:5
f="qhs" 21:8 21:8
du="nm"
r="nm"
ln="list"
14:
m="lisinopril" 30:0 30:0
do="20 mg" 30:1 30:2
mo="po" 30:3 30:3
f="qd" 30:4 30:4
du="nm"
r="nm"
ln="list"
15:
m="magnesium gluconate" 31:0 31:1
do="500 mg" 31:2 31:3
mo="po" 31:4 31:4
f="bid" 31:5 31:5
du="nm"
r="nm"
ln="list"
16:
m="milk of magnesia (magnesium hydroxide)" 32:0 32:6
do="30 milliliters" 33:0 33:1
mo="po" 33:2 33:2
f="qd prn" 33:3 33:4
du="nm"
r="constipation" 33:5 33:5
ln="list"
17:
m="metoprolol tartrate" 34:0 34:1
do="25 mg" 34:2 34:3
mo="po" 34:4 34:4
f="tid" 34:5 34:5
du="nm"
r="nm"
ln="list"
18:
m="xalatan (latanoprost)" 37:0 37:3
do="1 drop" 37:4 37:5
mo="ou" 37:6 37:6
f="qpm" 37:7 37:7
du="number of doses required (approximate): 10" 38:0 38:7
r="nm"
ln="list"
19:
m="flomax (tamsulosin)" 39:0 39:3
do="0.4 mg" 39:4 39:5
mo="po" 39:6 39:6
f="qd" 39:7 39:7
du="nm"
r="nm"
ln="list"
20:
m="nexium (esomeprazole)" 40:0 40:3
do="20 mg" 40:4 40:5
mo="po" 40:6 40:6
f="qd" 40:7 40:7
du="nm"
r="nm"
ln="list"
21:
m="coumadin" 61:14 61:14
do="nm"
mo="nm"
f="nm"
du="until 3/29" 61:15 61:16
r="nm"
ln="narrative"
22:
m="mannitol" 67:1 67:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="brimonidine 0.2 %" 78:0 78:1
do="nm"
mo="nm"
f="bid" 78:2 78:2
du="nm"
r="nm"
ln="list"
24:
m="lasix" 79:0 79:0
do="20" 79:1 79:1
mo="po" 79:2 79:2
f="qd" 79:3 79:3
du="nm"
r="nm"
ln="list"
25:
m="xalatan" 80:0 80:0
do="0.005" 80:1 80:1
mo="ou" 80:2 80:2
f="qhs" 80:3 80:3
du="nm"
r="nm"
ln="list"
26:
m="glipizide" 81:0 81:0
do="10mg" 81:1 81:1
mo="po" 81:2 81:2
f="qd" 81:3 81:3
du="nm"
r="nm"
ln="list"
27:
m="nexium" 82:0 82:0
do="20mg" 82:1 82:1
mo="po" 82:2 82:2
f="qd" 82:3 82:3
du="nm"
r="nm"
ln="list"
28:
m="flomax" 83:0 83:0
do="0.4" 83:1 83:1
mo="nm"
f="qd" 83:2 83:2
du="nm"
r="nm"
ln="list"
29:
m="zocor" 84:0 84:0
do="20mg" 84:1 84:1
mo="nm"
f="qd" 84:2 84:2
du="nm"
r="nm"
ln="list"
30:
m="metoprolol" 85:0 85:0
do="50mg" 85:1 85:1
mo="nm"
f="qd" 85:2 85:2
du="nm"
r="nm"
ln="list"
31:
m="metformin" 86:0 86:0
do="1000mg" 86:1 86:1
mo="nm"
f="bid" 86:2 86:2
du="nm"
r="nm"
ln="list"
32:
m="lisinopril" 87:0 87:0
do="10mg" 87:1 87:1
mo="nm"
f="qd" 87:2 87:2
du="nm"
r="nm"
ln="list"
33:
m="niferex" 88:0 88:0
do="150" 88:1 88:1
mo="nm"
f="bid" 88:2 88:2
du="nm"
r="nm"
ln="list"
34:
m="asa" 89:0 89:0
do="81" 89:1 89:1
mo="po" 89:2 89:2
f="qd" 89:3 89:3
du="nm"
r="nm"
ln="list"
35:
m="coumadin:" 90:0 90:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="coumadin" 207:14 207:14
do="nm"
mo="nm"
f="nm"
du="until 3/29" 207:15 207:16
r="nm"
ln="narrative"
37:
m="asa" 216:2 216:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="coumadin" 216:5 216:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="insulin" 218:13 218:13
do="sliding scale" 219:0 219:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="metformin" 218:2 218:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
