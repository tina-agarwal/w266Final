1:
m="nafcillin" 19:4 19:4
do="nm"
mo="intravenous" 19:3 19:3
f="nm"
du="x 4 weeks" 19:5 19:7
r="wound complications" 17:5 17:6
ln="narrative"
2:
m="vancomycin" 20:0 20:0
do="nm"
mo="nm"
f="nm"
du="x 4 weeks" 20:1 20:3
r="nm"
ln="narrative"
3:
m="dicloxacillin" 21:9 21:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="cellulitis." 22:4 22:4
ln="narrative"
4:
m="diuretic regimen" 23:7 23:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="fluid overload" 22:10 23:0
ln="narrative"
5:
m="spironolactone" 23:2 23:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="fluid overload" 22:10 23:0
ln="narrative"
6:
m="atenolol" 37:0 37:0
do="100 mg" 37:1 37:2
mo="nm"
f="q.d." 37:3 37:3
du="nm"
r="nm"
ln="list"
7:
m="spironolactone" 37:5 37:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="torsemide" 37:7 37:7
do="160 mg" 37:8 37:9
mo="nm"
f="b.i.d." 37:10 37:10
du="nm"
r="nm"
ln="list"
9:
m="hyzaar 50/12.5" 38:0 38:1
do="nm"
mo="nm"
f="q. day" 38:2 38:3
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 38:5 38:5
do="60 mg" 38:6 38:7
mo="nm"
f="q. day" 38:8 38:9
du="nm"
r="nm"
ln="list"
11:
m="neurontin" 38:11 38:11
do="1200 mg" 38:12 38:13
mo="nm"
f="t.i.d." 39:0 39:0
du="nm"
r="nm"
ln="list"
12:
m="coumadin" 39:11 39:11
do="8 mg" 39:12 39:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="norvasc" 39:2 39:2
do="10 mg" 39:3 39:4
mo="nm"
f="q.a.m." 39:5 39:5
du="nm"
r="nm"
ln="list"
14:
m="norvasc" 39:2 39:2
do="5 mg" 39:7 39:8
mo="nm"
f="q.p.m." 39:9 39:9
du="nm"
r="nm"
ln="list"
15:
m="aspirin" 40:0 40:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="humalog" 40:2 40:2
do="sliding scale" 40:3 40:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="percocet" 40:6 40:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="pletal" 40:8 40:8
do="100 mg" 40:9 40:10
mo="nm"
f="b.i.d." 40:11 40:11
du="nm"
r="nm"
ln="list"
19:
m="nitroglycerin" 41:4 41:4
do="nm"
mo="nm"
f="p.r.n." 41:5 41:5
du="nm"
r="nm"
ln="list"
20:
m="nph" 41:8 41:8
do="80" 41:9 41:9
mo="nm"
f="q.a.m. and q.p.m." 41:10 42:0
du="nm"
r="nm"
ln="list"
21:
m="procrit" 41:0 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="zantac" 41:2 41:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="vancomycin" 65:0 65:0
do="nm"
mo="iv" 65:1 65:1
f="nm"
du="nm"
r="his right medial thigh cellulitis" 65:5 65:9
ln="narrative"
24:
m="antibiotic" 68:1 68:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="anti-psuedomonal coverage for his diabetic foot ulcers." 69:2 70:1
ln="narrative"
25:
m="fluoroquinolone" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="anti-psuedomonal coverage for his diabetic foot ulcers." 69:2 70:1
ln="narrative"
26:
m="clindamycin" 77:3 77:3
do="nm"
mo="nm"
f="nm"
du="14-day course" 76:8 76:9
r="these foot ulcers" 77:5 77:7
ln="narrative"
27:
m="levofloxacin" 77:1 77:1
do="nm"
mo="nm"
f="nm"
du="a 14-day course" 76:7 76:9
r="these foot ulcers" 77:5 77:7
ln="narrative"
28:
m="metolazone" 81:8 81:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="torsemide" 81:2 81:2
do="nm"
mo="iv" 81:6 81:6
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="torsemide" 82:10 82:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="electrolytes" 85:7 85:7
do="nm"
mo="nm"
f="as needed" 85:10 86:0
du="nm"
r="nm"
ln="narrative"
32:
m="spironolactone" 90:0 90:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="pletal" 93:2 93:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="coumadin" 96:6 96:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="hydralazine" 101:4 101:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertensive" 100:5 100:5
ln="narrative"
36:
m="home medicines." 102:2 102:3
do="nm"
mo="p.o." 102:1 102:1
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="hydralazine" 104:2 104:2
do="nm"
mo="p.o." 104:3 104:3
f="nm"
du="nm"
r="his systolic blood pressure" 104:11 105:2
ln="narrative"
38:
m="nph" 107:8 107:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="humalog." 108:0 108:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="nph" 109:1 109:1
do="85 units" 110:5 110:6
mo="nm"
f="at night" 110:7 110:8
du="nm"
r="wound healing." 111:9 112:0
ln="narrative"
41:
m="nph" 109:1 109:1
do="90 units" 109:11 110:0
mo="nm"
f="in the morning" 110:1 110:3
du="nm"
r="nm"
ln="narrative"
