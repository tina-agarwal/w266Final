1:
m="milrinone" 28:9 28:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="worsening cardiac function" 28:2 28:4
ln="narrative"
2:
m="diuretics" 29:5 29:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="coumadin" 30:8 30:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 30:10 31:0
ln="narrative"
4:
m="antibiotics" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="sepsis." 31:8 31:8
ln="narrative"
5:
m="flagyl" 32:4 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="sepsis." 31:8 31:8
ln="narrative"
6:
m="levofloxacin" 32:2 32:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="sepsis." 31:8 31:8
ln="narrative"
7:
m="vancomycin" 32:7 32:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="sepsis." 31:8 31:8
ln="narrative"
8:
m="pressors" 50:9 50:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="antibiotics" 51:0 51:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="fentanyl" 52:0 52:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="versed" 52:2 52:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="sedation" 54:0 54:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="comfort" 54:2 54:2
ln="narrative"
