1:
m="amiodarone" 11:7 11:7
do="200 mg" 11:8 11:9
mo="p.o." 11:10 11:10
f="daily" 12:0 12:0
du="nm"
r="nm"
ln="list"
2:
m="enteric-coated aspirin" 11:0 11:1
do="325 mg" 11:2 11:3
mo="p.o." 11:4 11:4
f="daily" 11:5 11:5
du="nm"
r="nm"
ln="list"
3:
m="colace" 12:2 12:2
do="100 mg" 12:3 12:4
mo="p.o." 12:5 12:5
f="b.i.d." 12:6 12:6
du="nm"
r="nm"
ln="list"
4:
m="insulin nph" 12:8 12:9
do="3 units" 13:0 13:1
mo="subcutaneously" 13:3 13:3
f="q.p.m." 13:2 13:2
du="nm"
r="nm"
ln="list"
5:
m="insulin nph" 12:8 12:9
do="7 units" 12:10 12:11
mo="subcutaneously" 13:3 13:3
f="q.a.m." 12:12 12:12
du="nm"
r="nm"
ln="list"
6:
m="atrovent hfa inhaler" 13:5 13:7
do="2 puffs" 13:8 13:9
mo="inhaled" 14:0 14:0
f="q.i.d. p.r.n." 14:1 14:2
du="nm"
r="wheezing" 14:4 14:4
ln="list"
7:
m="magnesium gluconate" 14:6 14:7
do="sliding scale" 14:8 15:0
mo="p.o." 15:1 15:1
f="daily" 15:2 15:2
du="nm"
r="nm"
ln="list"
8:
m="oxycodone" 15:4 15:4
do="5-10 mg" 15:5 15:6
mo="p.o." 15:7 15:7
f="q. 4h. p.r.n." 15:8 15:10
du="nm"
r="pain" 15:11 15:11
ln="list"
9:
m="senna tablets" 16:0 16:1
do="one to two tablets" 16:2 16:5
mo="p.o." 16:6 16:6
f="b.i.d. p.r.n." 16:7 16:8
du="nm"
r="constipation" 16:9 16:9
ln="list"
10:
m="coumadin" 17:6 17:6
do="1 mg" 17:7 17:8
mo="p.o." 17:9 17:9
f="every other day" 17:10 18:0
du="nm"
r="nm"
ln="list"
11:
m="spironolactone" 17:0 17:0
do="25 mg" 17:1 17:2
mo="p.o." 17:3 17:3
f="daily" 17:4 17:4
du="nm"
r="nm"
ln="list"
12:
m="multivitamin therapeutic" 18:2 18:3
do="one tablet" 18:4 18:5
mo="p.o." 18:6 18:6
f="daily" 18:7 18:7
du="nm"
r="nm"
ln="list"
13:
m="zocor" 18:9 18:9
do="40 mg" 18:10 18:11
mo="p.o." 19:0 19:0
f="daily" 19:1 19:1
du="nm"
r="nm"
ln="list"
14:
m="oxycontin" 19:9 19:9
do="10 mg" 19:10 19:11
mo="p.o." 19:12 19:12
f="b.i.d." 20:0 20:0
du="nm"
r="nm"
ln="list"
15:
m="torsemide" 19:3 19:3
do="100 mg" 19:4 19:5
mo="p.o." 19:6 19:6
f="daily" 19:7 19:7
du="nm"
r="nm"
ln="list"
16:
m="cozaar" 20:2 20:2
do="25 mg" 20:3 20:4
mo="p.o." 20:5 20:5
f="daily" 20:6 20:6
du="nm"
r="nm"
ln="list"
17:
m="remeron" 20:8 20:8
do="7.5 mg" 20:9 20:10
mo="p.o." 20:11 20:11
f="q.h.s." 20:12 20:12
du="nm"
r="nm"
ln="list"
18:
m="aspartate insulin" 21:0 21:1
do="sliding scale." 21:2 21:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="dobutamine." 55:5 55:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotension" 55:0 55:0
ln="narrative"
20:
m="amiodarone" 84:0 84:0
do="200 mg" 84:1 84:2
mo="p.o." 84:3 84:3
f="daily" 84:4 84:4
du="nm"
r="nm"
ln="list"
21:
m="atrovent" 84:5 84:5
do="one to two puffs" 84:6 84:9
mo="inhaled" 84:10 84:10
f="q.i.d. p.r.n." 85:0 85:1
du="nm"
r="wheezing" 85:3 85:3
ln="list"
22:
m="celexa" 85:5 85:5
do="20 mg" 85:6 85:7
mo="p.o." 85:8 85:8
f="daily" 85:9 85:9
du="nm"
r="nm"
ln="list"
23:
m="coumadin" 85:11 85:11
do="2.5 mg" 85:12 86:0
mo="p.o." 86:1 86:1
f="daily" 86:2 86:2
du="nm"
r="nm"
ln="list"
24:
m="diovan" 86:4 86:4
do="80 mg" 86:5 86:6
mo="p.o." 86:7 86:7
f="daily" 86:8 86:8
du="nm"
r="nm"
ln="list"
25:
m="enteric-coated aspirin" 86:10 86:11
do="325 mg" 87:0 87:1
mo="p.o." 87:2 87:2
f="daily" 87:3 87:3
du="nm"
r="nm"
ln="list"
26:
m="lantus" 87:5 87:5
do="25 units" 87:6 87:7
mo="subcutaneous" 87:10 87:10
f="every day" 87:8 87:9
du="nm"
r="nm"
ln="list"
27:
m="lasix" 87:12 87:12
do="160 mg" 88:0 88:1
mo="p.o." 88:2 88:2
f="b.i.d." 88:3 88:3
du="nm"
r="nm"
ln="list"
28:
m="lipitor" 88:5 88:5
do="20 mg" 88:6 88:7
mo="p.o." 88:8 88:8
f="q.h.s." 88:9 88:9
du="nm"
r="nm"
ln="list"
29:
m="lopressor" 88:11 88:11
do="50 mg" 88:12 88:13
mo="p.o." 89:0 89:0
f="b.i.d." 89:1 89:1
du="nm"
r="nm"
ln="list"
30:
m="therapeutic multivitamin" 89:3 89:4
do="one tablet" 89:5 89:6
mo="p.o." 89:7 89:7
f="daily" 89:8 89:8
du="nm"
r="nm"
ln="list"
31:
m="solsite" 90:0 90:0
do="nm"
mo="topical." 90:1 90:1
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="ace inhibitor" 109:7 109:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="aspirin." 109:1 109:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="arb" 111:2 111:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="torsemide" 117:7 117:7
do="100 mg" 117:4 117:5
mo="iv" 117:6 117:6
f="b.i.d." 117:8 117:8
du="nm"
r="nm"
ln="narrative"
36:
m="hydrochlorothiazide" 118:5 118:5
do="25 mg" 118:2 118:3
mo="nm"
f="b.i.d." 118:6 118:6
du="nm"
r="nm"
ln="narrative"
37:
m="torsemide" 119:2 119:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="spironolactone" 121:2 121:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="torsemide" 127:4 127:4
do="100 mg" 127:8 127:9
mo="p.o." 127:10 127:10
f="daily" 127:11 127:11
du="nm"
r="diuresis" 127:0 127:0
ln="narrative"
40:
m="hydrochlorothiazide" 128:0 128:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="amiodarone" 133:7 133:7
do="nm"
mo="nm"
f="nm"
du="during this hospitalization" 133:8 134:1
r="atrial fibrillation" 132:8 133:0
ln="narrative"
42:
m="coumadin" 133:2 133:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 132:8 133:0
ln="narrative"
43:
m="ipratropium" 136:2 136:2
do="nm"
mo="inhaled" 136:1 136:1
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="coumadin" 147:6 147:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="coumadin" 148:9 148:9
do="nm"
mo="p.o." 149:3 149:3
f="every other day." 149:4 149:6
du="nm"
r="nm"
ln="narrative"
46:
m="coumadin" 150:2 150:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="aspartate" 153:5 153:5
do="sliding scale" 153:6 153:7
mo="nm"
f="nm"
du="for duration of hospitalization" 153:8 154:1
r="diabetes mellitus" 152:2 152:3
ln="narrative"
48:
m="nph" 153:0 153:0
do="nm"
mo="nm"
f="q.a.m." 153:1 153:1
du="nm"
r="diabetes mellitus" 152:2 152:3
ln="narrative"
49:
m="nph" 153:0 153:0
do="nm"
mo="nm"
f="q.p.m." 153:3 153:3
du="nm"
r="nm"
ln="narrative"
50:
m="celexa" 155:7 155:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="likely depressive mood" 156:0 156:2
ln="narrative"
51:
m="celexa." 161:11 161:11
do="7.5 mg" 161:4 161:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="remeron" 161:3 161:3
do="7.5 mg" 161:4 161:5
mo="p.o." 161:6 161:6
f="daily" 161:7 161:7
du="nm"
r="nm"
ln="narrative"
53:
m="this medications" 162:3 162:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="ciprofloxacin." 169:0 169:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="urinary tract infection" 168:0 168:2
ln="narrative"
55:
m="duoderm" 171:8 171:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="heparin" 177:7 177:7
do="nm"
mo="subcutaneous" 177:6 177:6
f="nm"
du="nm"
r="dvt...prophylaxis" 178:2 178:2,178:5 178:5
ln="narrative"
57:
m="heparin" 177:7 177:7
do="nm"
mo="subcutaneous" 177:6 177:6
f="nm"
du="nm"
r="gi prophylaxis" 178:4 178:5
ln="narrative"
58:
m="nexium" 178:0 178:0
do="nm"
mo="nm"
f="nm"
du="during this hospitalization" 178:6 178:8
r="gi prophylaxis" 178:4 178:5
ln="narrative"
59:
m="nexium" 178:0 178:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt...prophylaxis" 178:2 178:2,178:5 178:5
ln="narrative"
60:
m="remeron" 185:5 185:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="depressive disorder/adjustment disorder" 186:3 186:5
ln="narrative"
61:
m="beta-blocker." 187:6 187:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="beta-blocker" 188:1 188:1
do="a low-dose" 188:3 188:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="torsemide" 201:7 201:7
do="100 mg" 201:5 201:6
mo="p.o." 201:8 201:8
f="daily" 202:0 202:0
du="nm"
r="nm"
ln="narrative"
64:
m="spironolactone." 202:2 202:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
