1:
m="ativan" 19:1 19:1
do="3-4 mg" 19:3 19:4
mo="nm"
f="q.d." 19:5 19:5
du="two months" 18:6 18:7
r="anxiety" 19:7 19:7
ln="narrative"
2:
m="ativan" 20:0 20:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="this medication" 20:11 21:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="chloral hydrate" 39:3 39:4
do="nm"
mo="nm"
f="nm"
du="five days" 39:8 39:9
r="nm"
ln="narrative"
5:
m="compazine" 40:0 40:0
do="one dose" 40:2 40:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="insulin nph" 55:7 55:8
do="25 units" 55:9 55:10
mo="nm"
f="in the morning" 55:11 56:1
du="nm"
r="nm"
ln="list"
7:
m="regular" 56:3 56:3
do="10 units" 56:4 56:5
mo="nm"
f="in the morning" 56:6 57:0
du="nm"
r="nm"
ln="list"
8:
m="aspirin" 57:2 57:2
do="81 mg" 57:3 57:4
mo="nm"
f="q.d." 57:5 57:5
du="nm"
r="nm"
ln="list"
9:
m="compazine" 57:12 57:12
do="5 mg" 57:13 57:14
mo="nm"
f="q.6h. p.r.n." 58:0 58:1
du="nm"
r="anxiety" 58:2 58:2
ln="list"
10:
m="lopressor" 57:7 57:7
do="25 mg" 57:8 57:9
mo="nm"
f="b.i.d." 57:10 57:10
du="nm"
r="nm"
ln="list"
11:
m="chloral hydrate" 58:12 59:0
do="500 to 1000 mg" 59:1 59:4
mo="nm"
f="q.h.s." 59:5 59:5
du="for five days" 59:6 59:8
r="nm"
ln="list"
12:
m="ativan" 92:2 92:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="anxiety attack" 93:0 93:1
ln="narrative"
13:
m="phenothiazines" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="generalized anxiety disorder" 98:0 98:2
ln="narrative"
14:
m="trilafon" 100:6 100:6
do="2 to 4 mg" 100:7 100:10
mo="p.o." 100:11 100:11
f="p.r.n. q.6h." 100:12 101:0
du="nm"
r="anxiety" 101:2 101:2
ln="narrative"
15:
m="normal saline" 105:2 105:3
do="nm"
mo="boluses" 105:4 105:4
f="nm"
du="nm"
r="her orthostasis" 105:6 105:7
ln="narrative"
16:
m="lopressor" 106:1 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="ativan" 110:8 110:8
do="high doses" 111:5 111:6
mo="nm"
f="nm"
du="two months" 111:10 111:11
r="nm"
ln="narrative"
18:
m="keflex" 114:6 114:6
do="500 mg" 114:7 114:8
mo="p.o." 114:9 114:9
f="t.i.d." 114:10 114:10
du="nm"
r="E. coli" 113:10 113:11
ln="narrative"
19:
m="keflex" 114:6 114:6
do="500 mg" 114:7 114:8
mo="p.o." 114:9 114:9
f="t.i.d." 114:10 114:10
du="nm"
r="urinary tract infection symptoms" 112:3 112:6
ln="narrative"
20:
m="aspirin" 118:2 118:2
do="81 mg" 118:3 118:4
mo="p.o." 118:5 118:5
f="q.d." 118:6 118:6
du="nm"
r="nm"
ln="list"
21:
m="insulin nph" 118:8 118:9
do="25 units" 118:10 119:0
mo="subcutaneously" 119:1 119:1
f="q.a.m." 119:2 119:2
du="nm"
r="nm"
ln="list"
22:
m="insulin regular" 119:4 120:0
do="10 units" 120:1 120:2
mo="subcutaneously" 120:3 120:3
f="q.a.m." 120:4 120:4
du="nm"
r="nm"
ln="list"
23:
m="trilafon" 120:6 120:6
do="2 mg" 120:7 120:8
mo="p.o." 120:9 120:9
f="q.6h." 120:10 120:10
du="nm"
r="nm"
ln="list"
24:
m="keflex" 121:1 121:1
do="500 mg" 121:2 121:3
mo="p.o." 121:4 121:4
f="t.i.d." 121:5 121:5
du="nm"
r="nm"
ln="list"
