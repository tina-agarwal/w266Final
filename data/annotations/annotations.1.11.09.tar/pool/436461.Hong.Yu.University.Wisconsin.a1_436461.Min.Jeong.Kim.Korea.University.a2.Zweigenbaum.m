1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 21:0 21:0
do="12.5 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qam" 21:4 21:4
du="nm"
r="nm"
ln="list"
3:
m="lipitor ( atorvastatin )" 22:0 22:3
do="80 mg" 22:4 22:5
mo="po" 22:6 22:6
f="daily" 22:7 22:7
du="nm"
r="nm"
ln="list"
4:
m="cogentin ( benztropine mesylate )" 23:0 23:4
do="1 mg" 23:5 23:6
mo="po" 23:7 23:7
f="qam" 23:8 23:8
du="nm"
r="nm"
ln="list"
5:
m="thorazine" 26:3 26:3
do="nm"
mo="po" 26:4 26:4
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="benztropine mesylate" 27:3 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="chlorpromazine hcl" 28:0 28:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="benztropine mesylate" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="chlorpromazine hcl" 30:0 30:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="thorazine ( chlorpromazine hcl )" 31:0 31:4
do="400 mg" 31:5 31:6
mo="po" 31:7 31:7
f="qam" 31:8 31:8
du="nm"
r="nm"
ln="list"
11:
m="benztropine mesylate" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="chlorpromazine hcl" 35:0 35:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="benztropine mesylate" 36:3 36:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="chlorpromazine hcl" 37:0 37:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="ecasa" 38:0 38:0
do="325 mg" 38:1 38:2
mo="po" 38:3 38:3
f="daily" 38:4 38:4
du="nm"
r="nm"
ln="list"
16:
m="glipizide xl" 39:0 39:1
do="10 mg" 39:2 39:3
mo="po" 39:4 39:4
f="daily" 39:5 39:5
du="nm"
r="nm"
ln="list"
17:
m="synthroid ( levothyroxine sodium )" 40:0 40:4
do="100 mcg" 40:5 40:6
mo="po" 40:7 40:7
f="daily" 40:8 40:8
du="nm"
r="nm"
ln="list"
18:
m="lisinopril" 41:0 41:0
do="20 mg" 41:1 41:2
mo="po" 41:3 41:3
f="daily" 41:4 41:4
du="nm"
r="nm"
ln="list"
19:
m="metformin" 42:0 42:0
do="1 , 000 mg" 42:1 42:4
mo="po" 42:5 42:5
f="bid" 42:6 42:6
du="nm"
r="nm"
ln="list"
20:
m="trazodone" 43:0 43:0
do="50 mg" 43:1 43:2
mo="po" 43:3 43:3
f="bedtime prn" 43:4 43:5
du="nm"
r="insomnia" 43:6 43:6
ln="list"
21:
m="glipizide" 78:3 78:3
do="10" 78:4 78:4
mo="po" 78:5 78:5
f="qd" 78:6 78:6
du="nm"
r="nm"
ln="list"
22:
m="lisinipril" 78:12 78:12
do="20mg" 78:13 78:13
mo="nm"
f="qd" 79:0 79:0
du="nm"
r="nm"
ln="list"
23:
m="metformin" 78:0 78:0
do="1000" 78:1 78:1
mo="nm"
f="bid" 78:2 78:2
du="nm"
r="nm"
ln="list"
24:
m="synthroid" 78:8 78:8
do="0.1" 78:9 78:9
mo="nm"
f="qd" 78:10 78:10
du="nm"
r="nm"
ln="list"
25:
m="asa" 79:2 79:2
do="81" 79:3 79:3
mo="nm"
f="qd" 79:4 79:4
du="nm"
r="nm"
ln="list"
26:
m="atenolol" 79:6 79:6
do="12.5" 79:7 79:7
mo="nm"
f="qd" 79:8 79:8
du="nm"
r="nm"
ln="list"
27:
m="cardiac medications" 90:13 91:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="bp control" 91:2 91:3
ln="narrative"
28:
m="hypoglycemics" 96:4 96:4
do="nm"
mo="oral" 96:3 96:3
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="heparin" 99:1 99:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
