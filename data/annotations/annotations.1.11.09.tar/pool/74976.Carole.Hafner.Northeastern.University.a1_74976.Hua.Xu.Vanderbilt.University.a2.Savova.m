1:
m="glucotrol" 29:6 29:6
do="7.5 mg" 29:7 29:8
mo="p.o." 30:0 30:0
f="q-day" 30:1 30:1
du="nm"
r="nm"
ln="list"
2:
m="isoril" 30:9 30:9
do="10 mg" 30:10 30:11
mo="p.o." 30:12 30:12
f="t.i.d." 30:13 30:13
du="nm"
r="nm"
ln="list"
3:
m="mevacor" 30:3 30:3
do="10 mg" 30:4 30:5
mo="p.o." 30:6 30:6
f="q.d." 30:7 30:7
du="nm"
r="nm"
ln="list"
4:
m="nitroglycerin" 31:6 31:6
do="nm"
mo="sublingual" 31:7 31:7
f="p.r.n." 31:8 31:8
du="nm"
r="nm"
ln="list"
5:
m="propranolol" 31:0 31:0
do="20 mg" 31:1 31:2
mo="p.o." 31:3 31:3
f="t.i.d." 31:4 31:4
du="nm"
r="nm"
ln="list"
6:
m="heparin" 52:7 52:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="mylanta" 64:7 64:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="transient chest discomfort" 63:9 64:1
ln="narrative"
8:
m="tng." 65:0 65:0
do="nm"
mo="sublingual" 64:9 64:9
f="nm"
du="nm"
r="transient chest discomfort" 63:9 64:1
ln="narrative"
9:
m="glucotrol" 70:0 70:0
do="nm"
mo="subcu" 70:3 70:3
f="q.a.m." 70:4 70:4
du="nm"
r="her blood sugars" 71:10 72:0
ln="narrative"
10:
m="nph" 70:2 70:2
do="nm"
mo="subcu" 70:3 70:3
f="q.a.m." 70:4 70:4
du="nm"
r="her blood sugars" 71:10 72:0
ln="narrative"
11:
m="mevacor" 73:1 73:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypercholesterolemia" 73:3 73:3
ln="narrative"
12:
m="mevacor" 75:4 75:4
do="10 mg" 75:5 75:6
mo="p.o." 75:7 75:7
f="q-day" 75:8 75:8
du="nm"
r="nm"
ln="list"
13:
m="aspirin" 76:0 76:0
do="one" 76:1 76:1
mo="p.o." 76:2 76:2
f="q-day" 76:3 76:3
du="nm"
r="nm"
ln="list"
14:
m="glucotrol" 76:5 76:5
do="20 mg" 76:6 76:7
mo="p.o." 76:8 76:8
f="b.i.d." 76:9 76:9
du="nm"
r="nm"
ln="list"
15:
m="isordil" 77:0 77:0
do="40 mg" 77:1 77:2
mo="p.o." 77:3 77:3
f="t.i.d." 77:4 77:4
du="nm"
r="nm"
ln="list"
16:
m="lopressor" 77:6 77:6
do="200 mg" 77:7 77:8
mo="p.o." 77:9 77:9
f="b.i.d." 77:10 77:10
du="nm"
r="nm"
ln="list"
17:
m="nph" 77:12 77:12
do="26 units" 77:13 78:0
mo="subcutaneously" 78:1 78:1
f="each morning." 78:2 78:3
du="nm"
r="nm"
ln="list"
