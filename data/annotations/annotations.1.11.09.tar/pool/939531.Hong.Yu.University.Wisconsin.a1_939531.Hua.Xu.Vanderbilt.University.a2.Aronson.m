1:
m="hypoglycemics." 15:0 15:0
do="nm"
mo="oral" 14:6 14:6
f="nm"
du="nm"
r="diabetes" 13:2 13:2
ln="narrative"
2:
m="nitroglycerins" 26:5 26:5
do="four to five" 26:2 26:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="aspirin" 31:5 31:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="front-loaded tpa" 31:0 31:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="heparin" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="morphine sulfate" 31:7 31:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="nifedipine." 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="diltiazem" 46:2 46:2
do="60" 46:3 46:3
mo="nm"
f="t.i.d." 47:0 47:0
du="nm"
r="nm"
ln="list"
9:
m="glyburide" 47:2 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 47:4 47:4
do="20" 47:5 47:5
mo="po" 47:6 47:6
f="q.day." 47:7 47:7
du="nm"
r="nm"
ln="list"
11:
m="coumadin." 78:3 78:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylactic anticoagulation" 78:0 78:1
ln="narrative"
