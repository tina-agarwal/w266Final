1:
m="home o2" 17:8 17:9
do="2 liters" 17:10 17:11
mo="nm"
f="nm"
du="nm"
r="severe copd" 17:3 17:4
ln="narrative"
2:
m="chemotherapy regimens" 19:4 19:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nonsmall cell lung cancer" 18:6 18:9
ln="narrative"
3:
m="alimta" 20:0 20:0
do="nm"
mo="nm"
f="nm"
du="from 1/29/2005 to 09" 20:1 20:4
r="nm"
ln="narrative"
4:
m="avapro" 26:4 26:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="anemia" 101:5 101:5
ln="list"
5:
m="decadron" 26:8 26:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="lipitor" 26:6 26:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="alimta" 27:6 27:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="allopurinol" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="flonase" 27:8 27:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="humalog" 27:2 27:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="ranitidine" 27:0 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="vitamin d" 27:10 27:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="b12" 28:0 28:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="colace." 28:3 28:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="vancomycin" 65:9 65:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="aztreonam" 66:3 66:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="flagyl" 66:6 66:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="levaquin" 66:0 66:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="levaquin" 67:7 67:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="an enterococcal uti" 68:3 68:5
ln="narrative"
20:
m="levaquin" 67:7 67:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="possible nosocomial pneumonia." 68:7 69:0
ln="narrative"
21:
m="antibiotics" 72:3 72:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="a neutropenic enteritis" 71:0 71:2
ln="narrative"
22:
m="neupogen" 73:10 73:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="levaquin" 75:10 75:10
do="nm"
mo="nm"
f="nm"
du="14-day course" 75:7 75:8
r="uti." 76:0 76:0
ln="narrative"
24:
m="red blood transfusions" 88:4 88:6
do="multiple" 88:3 88:3
mo="nm"
f="nm"
du="nm"
r="her hematocrit" 89:2 89:3
ln="narrative"
25:
m="chemotherapy" 101:3 101:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="packed red blood cells" 103:6 103:9
do="three units" 103:3 103:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="chemo" 106:3 106:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="rbc transfusions" 106:9 107:0
do="multiple" 106:7 106:7
mo="nm"
f="nm"
du="nm"
r="hematocrit" 107:4 107:4
ln="narrative"
29:
m="platelet transfusions" 109:0 109:1
do="multiple" 108:8 108:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="chemo" 112:9 112:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="allopurinol" 114:4 114:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="thrombocytopenia" 115:3 115:3
ln="narrative"
32:
m="nystatin" 114:2 114:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="thrombocytopenia" 115:3 115:3
ln="narrative"
33:
m="alimta" 124:9 124:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="her neutropenia" 125:1 125:2
ln="narrative"
34:
m="steroids" 129:0 129:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="cortisol" 130:0 130:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="insulin" 131:2 131:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood sugars" 132:7 132:8
ln="narrative"
37:
m="lantus" 131:7 131:7
do="up titrated" 131:9 131:10
mo="nm"
f="nm"
du="nm"
r="blood sugars" 132:7 132:8
ln="narrative"
38:
m="insulin" 132:4 132:4
do="sliding scale" 132:2 132:3
mo="nm"
f="nm"
du="nm"
r="blood sugars" 132:7 132:8
ln="narrative"
39:
m="home regimen." 133:9 133:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="tpn" 134:2 134:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="her bowel rest" 134:9 134:11
ln="narrative"
41:
m="tpn" 137:4 137:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="oxygen." 141:3 141:3
do="3.5 liters" 141:0 141:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="tylenol" 157:2 157:2
do="650 to 1000 mg" 157:3 157:6
mo="p.o." 157:7 157:7
f="q. 6h p.r.n." 157:8 157:10
du="nm"
r="fever" 158:5 158:5
ln="list"
44:
m="tylenol" 157:2 157:2
do="650 to 1000 mg" 157:3 157:6
mo="p.o." 157:7 157:7
f="q. 6h p.r.n." 157:8 157:10
du="nm"
r="headache" 158:2 158:2
ln="list"
45:
m="tylenol" 157:2 157:2
do="650 to 1000 mg" 157:3 157:6
mo="p.o." 157:7 157:7
f="q. 6h p.r.n." 157:8 157:10
du="nm"
r="pain" 158:0 158:0
ln="list"
46:
m="peridex mouth wash" 158:11 158:13
do="10 ml" 159:0 159:1
mo="nm"
f="twice a day" 159:2 159:4
du="nm"
r="nm"
ln="list"
47:
m="nystatin mouth wash" 159:6 159:8
do="10 ml" 159:9 159:10
mo="swish and swallow" 159:11 159:13
f="4 x day as needed" 159:14 160:3
du="nm"
r="nm"
ln="list"
48:
m="oxycodone" 160:5 160:5
do="5 mg" 160:6 160:7
mo="p.o." 160:8 160:8
f="q. 6h p.r.n." 160:9 160:11
du="nm"
r="pain" 160:12 160:12
ln="list"
49:
m="simethicone" 161:0 161:0
do="80 mg" 161:1 161:2
mo="p.o." 161:3 161:3
f="q.i.d. p.r.n." 161:4 161:5
du="nm"
r="gaseousness" 161:6 161:6
ln="list"
50:
m="trazodone" 161:8 161:8
do="25 mg" 161:9 161:10
mo="p.o." 162:0 162:0
f="at bedtime" 162:1 162:2
du="nm"
r="nm"
ln="list"
51:
m="miconazole nitrate 2% powder" 162:4 162:7
do="nm"
mo="topical" 162:8 162:8
f="b.i.d." 162:9 162:9
du="nm"
r="nm"
ln="list"
52:
m="nexium" 163:10 163:10
do="20 mg" 164:0 164:1
mo="p.o." 164:2 164:2
f="daily" 164:3 164:3
du="nm"
r="nm"
ln="list"
53:
m="duoneb" 164:11 164:11
do="3/0.5 mg" 164:12 165:0
mo="nebs" 165:1 165:1
f="q. 3 h. p.r.n." 165:2 165:5
du="nm"
r="shortness of breath" 165:6 165:8
ln="list"
54:
m="lantus" 164:5 164:5
do="30 mg" 164:6 164:7
mo="subcutaneous" 164:8 164:8
f="daily" 164:9 164:9
du="nm"
r="nm"
ln="list"
55:
m="aspart" 165:10 165:10
do="4 units" 165:11 165:12
mo="subcutaneously" 166:2 166:2
f="before each meal" 165:13 166:1
du="nm"
r="nm"
ln="list"
56:
m="avapro" 166:10 166:10
do="150 mg" 166:11 166:12
mo="p.o." 167:0 167:0
f="daily" 167:1 167:1
du="nm"
r="nm"
ln="list"
57:
m="folate" 166:4 166:4
do="3 mg" 166:5 166:6
mo="p.o." 166:7 166:7
f="daily" 166:8 166:8
du="nm"
r="nm"
ln="list"
58:
m="combivent" 167:9 167:9
do="2 puffs" 167:10 167:11
mo="inhaled" 168:0 168:0
f="q.i.d." 168:1 168:1
du="nm"
r="nm"
ln="list"
59:
m="meclizine" 167:3 167:3
do="25 mg" 167:4 167:5
mo="p.o." 167:6 167:6
f="t.i.d." 167:7 167:7
du="nm"
r="nm"
ln="list"
60:
m="vitamin d 125" 168:3 168:5
do="0.25 mcg" 168:6 168:7
mo="p.o." 168:8 168:8
f="daily." 168:9 168:9
du="nm"
r="nm"
ln="list"
