1:
m="insulin" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="for several days" 25:4 25:6
r="nm"
ln="narrative"
2:
m="hydrochlorothiazide" 39:1 39:1
do="12.5 milligrams" 39:2 39:3
mo="nm"
f="once a day" 39:4 39:6
du="nm"
r="nm"
ln="list"
3:
m="norvasc" 40:0 40:0
do="5 milligrams" 40:1 40:2
mo="nm"
f="once a day" 40:3 40:5
du="nm"
r="nm"
ln="list"
4:
m="taxol" 40:7 40:7
do="28 milligrams" 40:8 40:9
mo="nm"
f="once a day" 41:0 41:2
du="nm"
r="nm"
ln="list"
5:
m="premarin" 41:4 41:4
do="0.625 milligrams" 41:5 41:6
mo="nm"
f="once a day" 41:7 41:9
du="nm"
r="nm"
ln="list"
6:
m="trazodone" 41:11 41:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="nph" 42:9 42:9
do="50 units" 42:6 42:7
mo="nm"
f="in the morning" 42:10 42:12
du="nm"
r="nm"
ln="list"
8:
m="regular" 42:4 42:4
do="12 units" 42:1 42:2
mo="nm"
f="in the morning" 42:10 42:12
du="nm"
r="nm"
ln="list"
9:
m="nph" 43:8 43:8
do="10 units" 43:5 43:6
mo="nm"
f="in the evening" 43:9 43:11
du="nm"
r="nm"
ln="list"
10:
m="regular" 43:3 43:3
do="14 units" 43:0 43:1
mo="nm"
f="in the evening" 43:9 43:11
du="nm"
r="nm"
ln="list"
11:
m="ansaid" 44:3 44:3
do="100 milligrams" 44:4 44:5
mo="p.o." 44:6 44:6
f="b.i.d. p.r.n." 44:7 44:8
du="nm"
r="joint pain" 44:9 45:0
ln="list"
12:
m="baby aspirin" 45:7 45:8
do="81 milligrams" 45:9 45:10
mo="nm"
f="once a day" 46:0 46:2
du="nm"
r="nm"
ln="list"
13:
m="aspirin" 99:11 99:11
do="325 milligrams" 100:0 100:1
mo="p.o." 100:2 100:2
f="q.d." 100:3 100:3
du="nm"
r="nm"
ln="narrative"
14:
m="heparin" 99:5 99:5
do="nm"
mo="subcu" 99:4 99:4
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="aspirin" 140:5 140:5
do="higher doses" 140:9 140:10
mo="nm"
f="nm"
du="nm"
r="her left shoulder pain" 141:1 141:4
ln="narrative"
16:
m="aspirin" 143:1 143:1
do="325 milligrams" 143:2 143:3
mo="p.o." 143:4 143:4
f="q.d." 143:5 143:5
du="nm"
r="nm"
ln="narrative"
17:
m="aspirin" 148:7 148:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="heparin" 149:0 149:0
do="nm"
mo="subcu" 148:10 148:10
f="nm"
du="while the patient was immobile" 149:1 149:5
r="nm"
ln="narrative"
19:
m="antihypertensives" 150:0 150:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="norvasc" 156:5 156:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="her blood pressure" 157:3 157:5
ln="narrative"
21:
m="antihypertensives" 165:4 165:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="aspirin" 177:10 177:10
do="higher doses" 178:2 178:3
mo="nm"
f="nm"
du="nm"
r="left shoulder pain" 178:6 178:8
ln="narrative"
23:
m="aspirin" 180:1 180:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="insulin" 182:4 182:4
do="nm"
mo="nm"
f="nm"
du="for several days" 182:5 182:7
r="diabetes mellitus" 181:8 181:9
ln="narrative"
25:
m="regular insulin" 183:5 183:6
do="sliding scale" 184:0 184:1
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 181:8 181:9
ln="narrative"
26:
m="nph" 186:5 186:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="regular insulin" 186:7 186:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="premarin" 187:4 187:4
do="nm"
mo="nm"
f="nm"
du="during this admission" 187:7 187:9
r="nm"
ln="narrative"
29:
m="fluids." 192:3 192:3
do="nm"
mo="iv" 192:2 192:2
f="nm"
du="nm"
r="nm"
ln="narrative"
