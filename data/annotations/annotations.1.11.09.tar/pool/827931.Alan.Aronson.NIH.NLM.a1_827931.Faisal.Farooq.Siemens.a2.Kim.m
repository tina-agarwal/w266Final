1:
m="insulin" 34:0 34:0
do="nm"
mo="iv" 33:12 33:12
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="morphine" 34:11 34:11
do="4 mg" 34:8 34:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nitroglycerin" 34:4 34:4
do="nm"
mo="sublingual" 34:3 34:3
f="nm"
du="x three" 34:5 34:6
r="nm"
ln="narrative"
4:
m="heparin drip" 35:9 35:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lopressor" 35:3 35:3
do="5 mg" 35:0 35:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="antibiotics" 36:0 36:0
do="nm"
mo="iv" 35:12 35:12
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="ms contin" 40:6 40:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="insulin-dependent diabetes mellitus" 37:4 37:6
ln="narrative"
8:
m="amitriptyline" 47:3 47:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="flexeril" 47:5 47:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="insulin" 47:1 47:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="prozac" 47:9 47:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="valium" 47:7 47:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="albuterol" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="atrovent inhalers." 48:2 48:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="ethanol" 54:4 54:4
do="nm"
mo="nm"
f="one drink per week" 54:8 55:0
du="nm"
r="nm"
ln="narrative"
16:
m="insulin drip" 94:5 94:6
do="nm"
mo="intravenous" 94:10 94:10
f="nm"
du="nm"
r="non-q-wave mi." 93:10 93:11
ln="narrative"
17:
m="nph with insulin" 95:9 96:1
do="sliding scale" 96:2 96:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="nph" 97:1 97:1
do="65 u" 97:4 97:5
mo="subcu" 97:6 97:6
f="b.i.d." 97:7 97:7
du="nm"
r="elevated blood sugar" 98:3 98:5
ln="narrative"
19:
m="insulin" 99:1 99:1
do="sliding scale." 99:2 99:3
mo="nm"
f="nm"
du="nm"
r="elevated blood sugars" 98:3 98:5
ln="narrative"
20:
m="cefotaxime" 125:3 125:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="gram negative coverage" 125:5 125:7
ln="narrative"
21:
m="cefotaxime" 127:2 127:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="gentamycin." 127:4 127:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="gentamycin" 129:2 129:2
do="one dose" 128:11 129:0
mo="nm"
f="nm"
du="nm"
r="synergy." 129:6 129:6
ln="narrative"
24:
m="cefotaxime" 130:5 130:5
do="nm"
mo="iv" 130:4 130:4
f="nm"
du="for the 7-day period" 130:6 130:9
r="nm"
ln="narrative"
25:
m="levofloxacin" 132:1 132:1
do="nm"
mo="p.o." 132:0 132:0
f="nm"
du="7 days" 132:5 132:6
r="nm"
ln="narrative"
26:
m="levofloxacin" 132:9 132:9
do="nm"
mo="p.o." 132:8 132:8
f="nm"
du="7 days" 132:5 132:6
r="urosepsis." 133:8 133:8
ln="narrative"
27:
m="antibiotics" 133:6 133:6
do="nm"
mo="nm"
f="nm"
du="14-day" 133:3 133:3
r="urosepsis." 133:8 133:8
ln="narrative"
28:
m="aspirin" 136:4 136:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="beta blocker." 136:10 136:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="heparin" 136:6 136:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="ace inhibitor" 137:5 137:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="heparin" 138:0 138:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="pe" 138:7 138:7
ln="narrative"
33:
m="ace inhibitor" 139:4 139:5
do="titrated up" 139:7 139:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="beta blocker" 139:1 139:2
do="titrated up" 139:7 139:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="carafate." 156:2 156:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="gi prophylaxis" 155:13 156:0
ln="narrative"
36:
m="carafate." 156:2 156:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="imodium" 161:3 161:3
do="nm"
mo="nm"
f="p.r.n." 161:4 161:4
du="nm"
r="diarrhea." 161:5 161:5
ln="narrative"
38:
m="pain medicines" 164:10 164:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="amitriptyline" 165:1 165:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="low back pain." 166:3 166:5
ln="narrative"
40:
m="amitriptyline" 165:1 165:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="sciatica" 166:1 166:1
ln="narrative"
41:
m="flexeril" 165:3 165:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="low back pain." 166:3 166:5
ln="narrative"
42:
m="flexeril" 165:3 165:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="sciatica" 166:1 166:1
ln="narrative"
43:
m="valium" 165:6 165:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="low back pain." 166:3 166:5
ln="narrative"
44:
m="valium" 165:6 165:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="sciatica" 166:1 166:1
ln="narrative"
45:
m="these medications" 166:10 167:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="neurontin" 167:8 167:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="likely diabetic neuropathy." 168:0 168:2
ln="narrative"
47:
m="enteric coated aspirin" 169:2 169:4
do="325 mg" 169:5 169:6
mo="p.o." 169:7 169:7
f="q.d." 169:8 169:8
du="nm"
r="nm"
ln="list"
48:
m="nph humulin insulin" 170:0 170:2
do="65 u" 170:3 170:4
mo="subcu" 170:5 170:5
f="b.i.d." 170:6 170:6
du="nm"
r="nm"
ln="list"
49:
m="human insulin" 171:0 171:1
do="10 u" 173:7 173:8
mo="nm"
f="nm"
du="nm"
r="blood sugars" 173:3 173:4
ln="list"
50:
m="human insulin" 171:0 171:1
do="4 u" 171:9 171:10
mo="nm"
f="nm"
du="nm"
r="blood sugars" 171:5 171:6
ln="list"
51:
m="human insulin" 171:0 171:1
do="6 u" 172:5 172:6
mo="nm"
f="nm"
du="nm"
r="blood sugars" 172:1 172:2
ln="list"
52:
m="human insulin" 171:0 171:1
do="8 u" 172:13 173:0
mo="nm"
f="nm"
du="nm"
r="blood sugars" 172:9 172:10
ln="list"
53:
m="human insulin" 171:0 171:1
do="sliding scale:" 171:2 171:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
54:
m="imodium" 173:10 173:10
do="2 mg" 173:11 173:12
mo="p.o." 173:13 173:13
f="q. 6 hrs" 173:14 173:16
du="nm"
r="diarrhea" 174:1 174:1
ln="list"
55:
m="niferex" 174:3 174:3
do="150 mg" 174:4 174:5
mo="p.o." 174:6 174:6
f="b.i.d." 174:7 174:7
du="nm"
r="nm"
ln="list"
56:
m="nitroglycerin 1/150" 174:9 174:10
do="one tab" 175:0 175:1
mo="sublingual" 175:2 175:2
f="q. 5 min. x 3 p.r.n." 175:3 175:8
du="nm"
r="chest pain" 175:9 175:10
ln="list"
57:
m="multivitamin" 175:12 175:12
do="one tab" 176:0 176:1
mo="p.o." 176:2 176:2
f="q.d." 176:3 176:3
du="nm"
r="nm"
ln="list"
58:
m="neurontin" 176:11 176:11
do="600 mg" 176:12 176:13
mo="p.o." 177:0 177:0
f="t.i.d." 177:1 177:1
du="nm"
r="nm"
ln="list"
59:
m="simvastatin" 176:5 176:5
do="10 mg" 176:6 176:7
mo="p.o." 176:8 176:8
f="q.h.s." 176:9 176:9
du="nm"
r="nm"
ln="list"
60:
m="levofloxacin" 177:3 177:3
do="500 mg" 177:4 177:5
mo="p.o." 177:6 177:6
f="q.d." 177:7 177:7
du="x 5 days" 177:8 177:10
r="nm"
ln="list"
61:
m="toprol xl" 177:12 177:13
do="400 mg" 177:14 178:0
mo="p.o." 178:1 178:1
f="q.d." 178:2 178:2
du="nm"
r="nm"
ln="list"
62:
m="lisinopril" 178:4 178:4
do="40 mg" 178:5 178:6
mo="p.o." 178:7 178:7
f="q.d." 178:8 178:8
du="nm"
r="nm"
ln="list"
