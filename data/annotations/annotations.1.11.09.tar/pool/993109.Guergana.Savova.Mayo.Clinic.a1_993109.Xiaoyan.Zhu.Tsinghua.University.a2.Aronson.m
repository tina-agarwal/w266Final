1:
m="diazepam" 19:0 19:0
do="10 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qam" 19:4 19:4
du="nm"
r="nm"
ln="list"
2:
m="lopressor ( metoprolol tartrate )" 20:0 20:4
do="25 mg" 20:5 20:6
mo="po" 20:7 20:7
f="bid" 20:8 20:8
du="nm"
r="nm"
ln="list"
3:
m="paxil ( paroxetine )" 23:0 23:3
do="20 mg" 23:4 23:5
mo="po" 23:6 23:6
f="qd" 23:7 23:7
du="nm"
r="nm"
ln="list"
4:
m="zocor ( simvastatin )" 24:0 24:3
do="40 mg" 24:4 24:5
mo="po" 24:6 24:6
f="qhs" 24:7 24:7
du="nm"
r="nm"
ln="list"
5:
m="lisinopril" 27:0 27:0
do="10 mg" 27:1 27:2
mo="po" 27:3 27:3
f="qd" 27:4 27:4
du="nm"
r="nm"
ln="list"
6:
m="potassium chloride" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="lisinopril" 30:0 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="acetylsalicylic acid" 31:0 31:1
do="81 mg" 31:2 31:3
mo="po" 31:4 31:4
f="qod" 31:5 31:5
du="nm"
r="nm"
ln="list"
9:
m="ntg" 50:11 50:11
do="nm"
mo="sl" 50:10 50:10
f="nm"
du="nm"
r="pain" 50:8 50:8
ln="narrative"
10:
m="heparin" 52:2 52:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="ace-i" 68:11 68:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="asa" 68:3 68:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="bb" 68:9 68:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="heparin" 68:14 68:14
do="nm"
mo="nm"
f="nm"
du="until cathed on 4/10" 68:15 69:2
r="nm"
ln="list"
15:
m="statin" 68:5 68:5
do="high dose" 68:6 68:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="lisinopril" 69:9 69:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="asa" 70:4 70:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="hctz" 70:6 70:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="lopressor" 70:0 70:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="zocor" 70:2 70:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
