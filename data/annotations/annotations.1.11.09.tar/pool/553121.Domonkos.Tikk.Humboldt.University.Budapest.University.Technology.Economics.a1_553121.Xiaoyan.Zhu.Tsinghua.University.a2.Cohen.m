1:
m="keppra" 34:1 34:1
do="nm"
mo="nm"
f="nm"
du="for approximately a year" 34:2 34:5
r="nm"
ln="narrative"
2:
m="flexeril" 42:7 42:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic low back pain" 42:10 43:2
ln="narrative"
3:
m="clonazepam" 58:5 58:5
do="1 mg" 58:6 58:7
mo="nm"
f="q.i.d." 58:8 58:8
du="nm"
r="nm"
ln="list"
4:
m="flexeril" 58:0 58:0
do="5 mg" 58:1 58:2
mo="nm"
f="daily" 58:3 58:3
du="nm"
r="nm"
ln="list"
5:
m="truvada" 58:10 58:10
do="one tablet" 58:11 58:12
mo="nm"
f="daily" 59:0 59:0
du="nm"
r="nm"
ln="list"
6:
m="glyburide" 59:7 59:7
do="2.5 mg" 59:12 59:13
mo="nm"
f="q.p.m." 60:0 60:0
du="nm"
r="nm"
ln="list"
7:
m="glyburide" 59:7 59:7
do="5 mg" 59:8 59:9
mo="nm"
f="q.a.m." 59:10 59:10
du="nm"
r="nm"
ln="list"
8:
m="norvir" 59:2 59:2
do="1400 mg" 59:3 59:4
mo="nm"
f="b.i.d." 59:5 59:5
du="nm"
r="nm"
ln="list"
9:
m="lomotil" 60:2 60:2
do="one tablet" 60:3 60:4
mo="nm"
f="q.i.d. p.r.n." 60:5 60:6
du="nm"
r="nm"
ln="list"
10:
m="methadone" 60:8 60:8
do="150 mg" 60:9 60:10
mo="nm"
f="daily" 60:11 60:11
du="nm"
r="nm"
ln="list"
11:
m="percocet" 61:6 61:6
do="325 mg/5 mg tablets one tablet" 61:7 61:12
mo="nm"
f="q.6 h. p.r.n." 62:0 62:2
du="nm"
r="nm"
ln="list"
12:
m="zofran" 61:0 61:0
do="4 mg" 61:1 61:2
mo="nm"
f="daily p.r.n." 61:3 61:4
du="nm"
r="nm"
ln="list"
13:
m="zantac" 62:4 62:4
do="150 mg" 62:5 62:6
mo="nm"
f="b.i.d." 62:7 62:7
du="nm"
r="nm"
ln="list"
14:
m="zoloft" 62:9 62:9
do="100 mg" 62:10 62:11
mo="nm"
f="q.a.m." 62:12 62:12
du="nm"
r="nm"
ln="list"
15:
m="trazodone" 63:0 63:0
do="100 mg" 63:1 63:2
mo="nm"
f="nightly." 63:3 63:3
du="nm"
r="nm"
ln="list"
16:
m="keppra" 112:3 112:3
do="nm"
mo="nm"
f="nm"
du="for the past year" 112:4 112:7
r="nm"
ln="narrative"
17:
m="aspirin." 145:7 145:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="beta-blocker" 145:5 145:5
do="low-dose" 145:4 145:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="beta-blocker" 150:1 150:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="metoprolol" 153:0 153:0
do="12.5" 153:1 153:1
mo="nm"
f="b.i.d." 153:2 153:2
du="nm"
r="nm"
ln="narrative"
21:
m="this medication" 154:9 154:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="keppra" 174:4 174:4
do="nm"
mo="nm"
f="nm"
du="for the past 12 months" 174:5 174:9
r="convulsive seizures" 173:8 173:9
ln="narrative"
23:
m="keppra" 180:7 180:7
do="250 mg" 181:3 181:4
mo="nm"
f="b.i.d." 181:5 181:5
du="nm"
r="nm"
ln="narrative"
24:
m="keppra" 180:7 180:7
do="500 mg" 181:12 181:13
mo="nm"
f="b.i.d." 182:0 182:0
du="7 days" 182:2 182:3
r="nm"
ln="narrative"
25:
m="keppra" 180:7 180:7
do="750 mg" 182:6 182:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="glyburide" 194:9 194:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="glyburide" 195:7 195:7
do="2.5 mg" 195:9 195:10
mo="nm"
f="daily" 196:0 196:0
du="nm"
r="nm"
ln="narrative"
28:
m="glyburide" 195:7 195:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="insulin" 198:7 198:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="lexiva" 201:9 201:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="truvada" 201:7 201:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="methadone" 206:1 206:1
do="155 mg" 206:4 206:5
mo="nm"
f="nm"
du="nm"
r="chronic pain" 205:4 205:5
ln="narrative"
33:
m="methadone" 206:1 206:1
do="155 mg" 206:4 206:5
mo="nm"
f="nm"
du="nm"
r="lumbar spine herniations." 205:7 205:9
ln="narrative"
34:
m="b12" 210:8 210:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="folate" 211:0 211:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="klonopin" 226:8 226:8
do="1 mg" 226:9 226:10
mo="nm"
f="q.i.d." 226:11 226:11
du="nm"
r="nm"
ln="narrative"
37:
m="klonopin" 228:3 228:3
do="three doses" 228:0 228:1
mo="nm"
f="nm"
du="over a six-day period." 228:4 228:7
r="nm"
ln="narrative"
38:
m="clonazepam" 238:5 238:5
do="1 mg" 238:6 238:7
mo="nm"
f="q.6 h. p.r.n." 238:8 238:10
du="nm"
r="nm"
ln="list"
39:
m="ecotrin" 238:0 238:0
do="81 mg" 238:1 238:2
mo="nm"
f="daily" 238:3 238:3
du="nm"
r="nm"
ln="list"
40:
m="imodium" 238:12 238:12
do="one to two tablets" 238:13 239:2
mo="nm"
f="q.i.d. p.r.n." 239:3 239:4
du="nm"
r="diarrhea" 239:6 239:6
ln="list"
41:
m="truvada" 239:8 239:8
do="one tablet" 239:9 239:10
mo="p.o." 240:0 240:0
f="daily" 240:1 240:1
du="nm"
r="nm"
ln="list"
42:
m="glyburide" 240:9 240:9
do="2.5 mg" 240:10 240:11
mo="nm"
f="daily" 240:12 240:12
du="nm"
r="nm"
ln="list"
43:
m="lexiva" 240:3 240:3
do="1400 mg" 240:4 240:5
mo="p.o." 240:6 240:6
f="b.i.d." 240:7 240:7
du="nm"
r="nm"
ln="list"
44:
m="keppra" 241:0 241:0
do="500 mg" 241:1 241:2
mo="nm"
f="b.i.d." 241:3 241:3
du="for 14 doses" 241:4 241:6
r="nm"
ln="list"
45:
m="keppra" 241:0 241:0
do="750 mg" 241:9 241:10
mo="nm"
f="b.i.d." 241:11 241:11
du="indefinitely" 242:0 242:0
r="nm"
ln="list"
46:
m="methadone" 242:2 242:2
do="155 mg" 242:3 242:4
mo="nm"
f="daily" 242:5 242:5
du="nm"
r="nm"
ln="list"
47:
m="zantac" 242:7 242:7
do="150 mg" 242:8 242:9
mo="nm"
f="b.i.d." 242:10 242:10
du="nm"
r="nm"
ln="list"
48:
m="trazodone" 243:5 243:5
do="100 mg" 243:6 243:7
mo="nm"
f="at bedtime p.r.n." 243:8 243:10
du="nm"
r="nm"
ln="list"
49:
m="zoloft" 243:0 243:0
do="300 mg" 243:1 243:2
mo="nm"
f="daily" 243:3 243:3
du="nm"
r="nm"
ln="list"
50:
m="zofran" 244:0 244:0
do="4 mg" 244:1 244:2
mo="nm"
f="daily p.r.n." 244:3 244:4
du="nm"
r="nausea" 244:6 244:6
ln="list"
51:
m="flexeril" 255:5 255:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="glyburide" 255:8 255:8
do="2.5 mg" 256:2 256:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="aspirin" 256:7 256:7
do="low-dose" 256:6 256:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
