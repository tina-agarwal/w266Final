1:
m="atenolol" 18:2 18:2
do="50 mg" 18:3 18:4
mo="p.o." 18:5 18:5
f="daily" 18:6 18:6
du="nm"
r="nm"
ln="list"
2:
m="hydrochlorothiazide" 19:0 19:0
do="25 mg" 19:1 19:2
mo="p.o." 19:3 19:3
f="daily" 19:4 19:4
du="nm"
r="nm"
ln="list"
3:
m="nexium" 19:6 19:6
do="40 mg" 19:7 19:8
mo="p.o." 19:9 19:9
f="daily." 19:10 19:10
du="nm"
r="nm"
ln="list"
4:
m="robitussin a-c" 42:2 42:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="aspirin" 47:2 47:2
do="81 mg" 47:3 47:4
mo="p.o." 47:5 47:5
f="daily" 47:6 47:6
du="nm"
r="nm"
ln="list"
6:
m="atenolol" 47:8 47:8
do="50 mg" 47:9 47:10
mo="p.o." 48:0 48:0
f="daily" 48:1 48:1
du="nm"
r="nm"
ln="list"
7:
m="hydrochlorothiazide" 48:3 48:3
do="25 mg" 48:4 48:5
mo="p.o." 48:6 48:6
f="daily" 48:7 48:7
du="nm"
r="nm"
ln="list"
8:
m="lipitor" 48:9 48:9
do="40 mg" 48:10 48:11
mo="p.o." 49:0 49:0
f="daily." 49:1 49:1
du="nm"
r="nm"
ln="list"
9:
m="new medications." 56:10 57:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="untreated diabetes" 56:2 56:3
ln="narrative"
