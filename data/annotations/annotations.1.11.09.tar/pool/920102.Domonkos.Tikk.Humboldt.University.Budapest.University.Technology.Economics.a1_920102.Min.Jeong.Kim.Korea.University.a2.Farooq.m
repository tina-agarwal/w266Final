1:
m="lisinopril" 21:2 21:2
do="20 mg" 21:3 21:4
mo="p.o." 21:5 21:5
f="daily" 21:6 21:6
du="nm"
r="nm"
ln="list"
2:
m="atorvastatin" 22:0 22:0
do="40 mg" 22:1 22:2
mo="p.o." 22:3 22:3
f="daily" 22:4 22:4
du="nm"
r="nm"
ln="list"
3:
m="xanax" 22:6 22:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="oxygen" 54:6 54:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="the following medications" 57:7 58:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 58:1 58:1
do="325 mg" 58:2 58:3
mo="p.o." 58:4 58:4
f="q. day" 58:5 58:6
du="nm"
r="nm"
ln="list"
7:
m="niferex" 58:8 58:8
do="150 mg" 58:9 58:10
mo="p.o." 58:11 58:11
f="b.i.d." 59:0 59:0
du="nm"
r="nm"
ln="list"
8:
m="oxycodone" 59:2 59:2
do="5 mg" 59:3 59:4
mo="p.o." 59:5 59:5
f="q.6h. p.r.n." 59:6 59:7
du="nm"
r="pain" 59:8 59:8
ln="list"
9:
m="toprol xl" 59:10 59:11
do="100 mg" 59:12 59:13
mo="p.o." 60:0 60:0
f="q. day" 60:1 60:2
du="nm"
r="nm"
ln="list"
10:
m="flovent" 60:4 60:4
do="44 mcg" 60:5 60:6
mo="inhaler" 60:7 60:7
f="b.i.d." 60:8 60:8
du="nm"
r="nm"
ln="list"
11:
m="lipitor" 60:10 60:10
do="40 mg" 60:11 60:12
mo="p.o." 60:13 60:13
f="daily." 61:0 61:0
du="nm"
r="nm"
ln="list"
