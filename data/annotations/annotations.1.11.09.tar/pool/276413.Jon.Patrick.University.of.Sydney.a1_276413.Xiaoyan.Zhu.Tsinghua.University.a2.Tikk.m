1:
m="anticoagulation" 14:3 14:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 14:0 14:1
ln="narrative"
2:
m="penicillin" 22:3 22:3
do="nm"
mo="iv" 22:2 22:2
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="flagyl" 23:0 23:0
do="nm"
mo="oral" 22:12 22:12
f="nm"
du="nm"
r="an elevated white count." 23:3 23:6
ln="narrative"
4:
m="nitroglycerin" 27:4 27:4
do="nm"
mo="sublingual" 27:3 27:3
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="fluid" 35:3 35:3
do="boluses" 35:4 35:4
mo="iv" 35:2 35:2
f="nm"
du="nm"
r="slightly hypotensive" 34:0 34:1
ln="narrative"
6:
m="ceftazidime" 36:2 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="vancomycin" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="glucotrol" 51:6 51:6
do="10 mg" 51:7 51:8
mo="p.o." 52:0 52:0
f="b.i.d." 52:1 52:1
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 52:3 52:3
do="5 mg" 52:4 52:5
mo="p.o." 52:6 52:6
f="q. day" 52:7 52:8
du="nm"
r="nm"
ln="list"
10:
m="metformin" 52:10 52:10
do="500 mg" 52:11 52:12
mo="p.o." 53:0 53:0
f="t.i.d." 53:1 53:1
du="nm"
r="nm"
ln="list"
11:
m="flagyl" 53:3 53:3
do="500 mg" 53:4 53:5
mo="p.o." 53:6 53:6
f="t.i.d." 53:7 53:7
du="x10 days" 53:8 53:9
r="nm"
ln="list"
12:
m="nitroglycerin" 54:4 54:4
do="nm"
mo="sublingual" 54:3 54:3
f="p.r.n." 54:5 54:5
du="nm"
r="nm"
ln="list"
13:
m="nystatin suspension" 54:7 54:8
do="nm"
mo="nm"
f="q.i.d." 55:0 55:0
du="nm"
r="nm"
ln="list"
14:
m="penicillin g" 55:9 55:10
do="3 million units" 55:11 55:13
mo="iv" 56:0 56:0
f="q. 4h" 56:1 56:2
du="x7 days" 56:3 56:4
r="nm"
ln="list"
15:
m="zyprexa" 55:2 55:2
do="2.5 mg" 55:3 55:4
mo="p.o." 55:5 55:5
f="q. h.s." 55:6 55:7
du="nm"
r="nm"
ln="list"
16:
m="dulcolax" 56:13 56:13
do="nm"
mo="nm"
f="p.r.n." 57:0 57:0
du="nm"
r="nm"
ln="list"
17:
m="milk of magnesia" 56:6 56:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="tylenol" 56:10 56:10
do="nm"
mo="nm"
f="p.r.n." 56:11 56:11
du="nm"
r="nm"
ln="list"
19:
m="atenolol" 57:5 57:5
do="50 mg" 57:6 57:7
mo="nm"
f="q. day" 57:8 57:9
du="nm"
r="nm"
ln="list"
20:
m="colace" 57:2 57:2
do="nm"
mo="nm"
f="p.r.n." 57:3 57:3
du="nm"
r="nm"
ln="list"
21:
m="lipitor" 57:11 57:11
do="20 mg" 57:12 57:13
mo="nm"
f="q. day" 57:14 58:0
du="nm"
r="nm"
ln="list"
22:
m="flomax" 58:7 58:7
do="0.4" 58:8 58:8
mo="nm"
f="q. day." 58:9 58:10
du="nm"
r="nm"
ln="list"
23:
m="senna liquid" 58:2 58:3
do="nm"
mo="nm"
f="q. h.s." 58:4 58:5
du="nm"
r="nm"
ln="list"
24:
m="fluids" 82:10 82:10
do="nm"
mo="iv" 82:9 82:9
f="nm"
du="nm"
r="possible early sepsis" 81:6 81:8
ln="narrative"
25:
m="antibiotics" 83:0 83:0
do="nm"
mo="iv" 82:9 82:9
f="nm"
du="nm"
r="possible early sepsis" 81:6 81:8
ln="narrative"
26:
m="ceftazidime." 83:4 83:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="possible early sepsis" 81:6 81:8
ln="narrative"
27:
m="vancomycin" 83:2 83:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="possible early sepsis" 81:6 81:8
ln="narrative"
28:
m="ceptaz" 85:5 85:5
do="nm"
mo="nm"
f="nm"
du="an empiric 7-day course" 85:0 85:3
r="aspiration pneumonia." 85:9 86:0
ln="narrative"
29:
m="flagyl" 85:7 85:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="aspiration pneumonia." 85:9 86:0
ln="narrative"
30:
m="vancomycin." 87:7 87:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="antibiotic" 88:5 88:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="his bacteremia." 88:8 89:0
ln="narrative"
32:
m="penicillin" 89:7 89:7
do="nm"
mo="iv" 89:6 89:6
f="nm"
du="for a full 3-4 week course" 90:4 90:9
r="nm"
ln="narrative"
33:
m="vancomycin" 89:2 89:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="antibiotics" 92:5 92:5
do="nm"
mo="nm"
f="nm"
du="for 4 weeks." 92:6 92:8
r="nm"
ln="narrative"
35:
m="oxygen" 109:2 109:2
do="2 liters" 108:10 109:0
mo="by nasal cannula." 109:3 109:5
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lasix." 111:3 111:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="oxygen" 112:6 112:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="aspirin" 117:6 117:6
do="home doses" 117:3 117:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="beta blocker" 117:10 117:11
do="2 pump." 117:12 118:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="statin" 117:8 117:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="ace inhibitor" 120:5 120:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="beta blocker" 120:1 120:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="fluids" 120:9 120:9
do="nm"
mo="iv" 120:8 120:8
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="coumadin" 123:0 123:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="vitamin k" 124:2 124:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="coumadin." 125:1 125:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="coumadin" 125:3 125:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="magnesium" 127:4 127:4
do="nm"
mo="nm"
f="nm"
du="while in hospital" 127:6 127:8
r="nm"
ln="narrative"
49:
m="potassium" 127:2 127:2
do="nm"
mo="nm"
f="nm"
du="while in hospital" 127:6 127:8
r="nm"
ln="narrative"
50:
m="bowel regimen" 130:10 131:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="coumadin" 140:3 140:3
do="nm"
mo="nm"
f="nm"
du="until 9/23/07" 140:7 140:8
r="nm"
ln="narrative"
52:
m="coumadin" 144:5 144:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="iron supplements" 146:8 146:9
do="nm"
mo="nm"
f="nm"
du="during his hospital stay." 147:0 147:3
r="nm"
ln="narrative"
54:
m="insulin" 154:7 154:7
do="sliding-scale" 154:8 154:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="lantus." 155:0 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="lantus" 156:4 156:4
do="15 units" 157:2 157:3
mo="nm"
f="q. p.m." 157:4 157:5
du="nm"
r="nm"
ln="narrative"
57:
m="flomax" 161:5 161:5
do="nm"
mo="nm"
f="nm"
du="during his hospital stay" 162:5 162:8
r="nm"
ln="narrative"
58:
m="zyprexa" 169:0 169:0
do="2.5 mg" 169:8 169:9
mo="nm"
f="q. day" 169:10 169:11
du="nm"
r="mildly agitated." 168:9 168:10
ln="narrative"
59:
m="zyprexa" 169:0 169:0
do="2.5 mg" 170:4 170:5
mo="nm"
f="b.i.d." 170:6 170:6
du="nm"
r="mildly agitated." 168:9 168:10
ln="narrative"
60:
m="coumadin" 172:9 172:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis:" 172:1 172:1
ln="narrative"
61:
m="nexium" 173:10 173:10
do="nm"
mo="nm"
f="nm"
du="while he is here." 174:3 174:6
r="nm"
ln="narrative"
