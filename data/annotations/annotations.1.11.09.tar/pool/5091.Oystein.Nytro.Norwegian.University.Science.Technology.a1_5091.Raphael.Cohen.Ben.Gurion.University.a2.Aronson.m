1:
m="antibiotics" 23:2 23:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="a nonhealing ulcer" 21:3 21:5
ln="narrative"
2:
m="narcotics." 33:7 33:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="throbbing pain" 31:7 31:8
ln="narrative"
3:
m="aspirin" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="lopressor" 48:2 48:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="norvasc" 48:4 48:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="phoslo" 48:10 48:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="plavix" 48:8 48:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="prandin" 48:12 48:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="zocor" 48:6 48:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="calcitriol." 49:4 49:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="epogen" 49:2 49:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="nephrocaps" 49:0 49:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="antibiotics" 92:0 92:0
do="nm"
mo="iv" 91:9 91:9
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="zyprexa." 94:9 94:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="delirium" 93:6 93:6
ln="narrative"
15:
m="aspirin" 104:1 104:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="coronary artery disease related event prophylaxis." 104:5 105:1
ln="narrative"
16:
m="zocor" 104:3 104:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="coronary artery disease related event prophylaxis." 104:5 105:1
ln="narrative"
17:
m="isosorbide dinitrate" 105:7 106:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure" 105:2 105:3
ln="narrative"
18:
m="lisinopril" 106:4 106:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure" 105:2 105:3
ln="narrative"
19:
m="lopressor" 106:7 106:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure" 105:2 105:3
ln="narrative"
20:
m="norvasc" 106:2 106:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressure" 105:2 105:3
ln="narrative"
21:
m="renal medications." 112:0 112:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="colace" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 114:0 114:0
ln="narrative"
23:
m="lactulose" 113:4 113:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 114:0 114:0
ln="narrative"
24:
m="dulcolax" 114:7 114:7
do="nm"
mo="nm"
f="p.r.n." 114:8 114:8
du="nm"
r="nm"
ln="narrative"
25:
m="narcotics" 114:3 114:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="vitamin c" 115:2 115:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="zinc" 115:0 115:0
do="nm"
mo="nm"
f="p.r.n." 114:8 114:8
du="nm"
r="nm"
ln="narrative"
28:
m="heparin" 116:3 116:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt prophylaxis" 116:5 116:6
ln="narrative"
29:
m="flagyl" 120:4 120:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="methicillin-resistant staphylococcus aureus" 120:6 121:1
ln="narrative"
30:
m="levofloxacin" 120:2 120:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="methicillin-resistant staphylococcus aureus" 120:6 121:1
ln="narrative"
31:
m="vancomycin" 120:0 120:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="methicillin-resistant staphylococcus aureus" 120:6 121:1
ln="narrative"
32:
m="levofloxacin" 122:6 122:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="flagyl" 123:0 123:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="vancomycin" 124:1 124:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="antibiotic" 125:0 125:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="insulin" 127:2 127:2
do="sliding scale" 127:3 127:4
mo="nm"
f="nm"
du="nm"
r="glycemic control" 127:6 127:7
ln="narrative"
37:
m="prandin" 127:0 127:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="glycemic control." 127:6 127:7
ln="narrative"
38:
m="vitamin d." 128:1 128:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="aspirin" 143:5 143:5
do="325 mg" 143:6 143:7
mo="p.o." 143:8 143:8
f="daily" 143:9 143:9
du="nm"
r="nm"
ln="list"
40:
m="calcitriol" 144:7 144:7
do="0.5 mcg" 144:8 144:9
mo="p.o." 144:10 144:10
f="daily" 144:11 144:11
du="nm"
r="nm"
ln="list"
41:
m="vitamin c" 144:0 144:1
do="500 mg" 144:2 144:3
mo="p.o." 144:4 144:4
f="b.i.d." 144:5 144:5
du="nm"
r="nm"
ln="list"
42:
m="colace" 145:0 145:0
do="100 mg" 145:1 145:2
mo="p.o." 145:3 145:3
f="daily" 145:4 145:4
du="nm"
r="nm"
ln="list"
43:
m="heparin" 145:6 145:6
do="5000 units" 145:7 145:8
mo="subcutaneous" 145:9 145:9
f="t.i.d." 145:10 145:10
du="nm"
r="nm"
ln="list"
44:
m="isosorbide dinitrate" 146:0 146:1
do="10 mg" 146:2 146:3
mo="p.o." 146:4 146:4
f="t.i.d." 146:5 146:5
du="nm"
r="nm"
ln="list"
45:
m="lactulose" 146:7 146:7
do="30 ml" 146:8 146:9
mo="p.o." 146:10 146:10
f="t.i.d." 147:0 147:0
du="nm"
r="nm"
ln="list"
46:
m="lisinopril" 147:2 147:2
do="50 mg" 147:3 147:4
mo="p.o." 147:5 147:5
f="daily" 147:6 147:6
du="nm"
r="nm"
ln="list"
47:
m="lopressor" 147:8 147:8
do="50 mg" 147:9 147:10
mo="p.o." 147:11 147:11
f="q.6h." 147:12 147:12
du="nm"
r="nm"
ln="list"
48:
m="simethicone" 148:0 148:0
do="80 mg" 148:1 148:2
mo="p.o." 148:3 148:3
f="q.i.d." 148:4 148:4
du="nm"
r="nm"
ln="list"
49:
m="vancomycin" 148:6 148:6
do="1 g" 148:7 148:8
mo="iv" 148:9 148:9
f="every other day" 148:10 148:12
du="nm"
r="nm"
ln="list"
50:
m="zinc sulfate" 149:0 149:1
do="220 mg" 149:2 149:3
mo="p.o." 149:4 149:4
f="daily" 149:5 149:5
du="for two weeks" 149:6 149:8
r="nm"
ln="list"
51:
m="zocor" 149:10 149:10
do="80 mg" 149:11 149:12
mo="p.o." 149:13 149:13
f="daily" 150:0 150:0
du="nm"
r="nm"
ln="list"
52:
m="nephro-vite" 150:8 150:8
do="one tab" 150:9 150:10
mo="p.o." 150:11 150:11
f="daily" 150:12 150:12
du="nm"
r="nm"
ln="list"
53:
m="norvasc" 150:2 150:2
do="10 mg" 150:3 150:4
mo="p.o." 150:5 150:5
f="daily" 150:6 150:6
du="nm"
r="nm"
ln="list"
54:
m="aranesp" 151:8 151:8
do="40 mcg" 151:9 151:10
mo="subcutaneous" 151:11 151:11
f="every week" 152:0 152:1
du="nm"
r="nm"
ln="list"
55:
m="prandin" 151:0 151:0
do="0.5 mg" 151:1 151:2
mo="p.o." 151:3 151:3
f="with each meal" 151:4 151:6
du="nm"
r="nm"
ln="list"
56:
m="insulin" 152:5 152:5
do="sliding scale" 152:3 152:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
57:
m="insulin aspart" 152:7 152:8
do="4 units" 152:9 152:10
mo="subcutaneous" 153:0 153:0
f="with breakfast and dinner" 153:1 153:4
du="nm"
r="nm"
ln="list"
58:
m="dulcolax" 153:6 153:6
do="10 mg" 153:7 153:8
mo="pr" 153:9 153:9
f="daily" 153:10 153:10
du="nm"
r="nm"
ln="list"
59:
m="dilaudid" 154:3 154:3
do="2-4 mg" 154:4 154:5
mo="p.o." 154:6 154:6
f="q.4h. as needed" 154:7 154:9
du="nm"
r="pain" 154:11 154:11
ln="list"
60:
m="tylenol" 154:0 154:0
do="nm"
mo="nm"
f="p.r.n." 154:1 154:1
du="nm"
r="nm"
ln="list"
61:
m="milk of magnesia" 155:0 155:2
do="nm"
mo="nm"
f="as needed" 155:3 155:4
du="nm"
r="constipation" 155:6 155:6
ln="list"
62:
m="reglan" 155:8 155:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nausea" 155:10 155:10
ln="list"
63:
m="oxycodone" 156:0 156:0
do="5-10 mg" 156:3 156:4
mo="p.o." 156:5 156:5
f="q.4h. hours as needed" 156:6 156:9
du="nm"
r="pain" 156:11 156:11
ln="list"
64:
m="zyprexa" 157:0 157:0
do="5 mg" 157:1 157:2
mo="p.o." 157:3 157:3
f="q.8h. as needed" 157:4 157:6
du="nm"
r="agitation" 157:10 157:10
ln="list"
65:
m="zyprexa" 157:0 157:0
do="5 mg" 157:1 157:2
mo="p.o." 157:3 157:3
f="q.8h. as needed" 157:4 157:6
du="nm"
r="anxiety" 157:8 157:8
ln="list"
66:
m="maalox" 158:0 158:0
do="nm"
mo="nm"
f="p.r.n." 158:1 158:1
du="nm"
r="upset stomach" 158:2 158:3
ln="list"
