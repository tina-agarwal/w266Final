1:
m="insulin." 17:4 17:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes" 17:1 17:1
ln="list"
2:
m="insulin" 30:9 30:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="novolin" 32:3 32:3
do="40 units" 32:4 32:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="glucose" 39:2 39:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lasix" 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="levaquin" 39:4 39:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="lasix" 43:1 43:1
do="40 mg" 43:10 43:11
mo="p.o." 43:12 43:12
f="q.d. in the evening." 43:13 44:0
du="nm"
r="nm"
ln="list"
8:
m="lasix" 43:1 43:1
do="80 mg" 43:2 43:3
mo="p.o" 43:4 43:4
f="q.d. in the morning" 43:5 43:8
du="nm"
r="nm"
ln="list"
9:
m="atenolol" 45:1 45:1
do="75 mg" 45:2 45:3
mo="p.o." 45:4 45:4
f="q.d." 45:5 45:5
du="nm"
r="nm"
ln="list"
10:
m="lipitor" 46:1 46:1
do="10 mg" 46:2 46:3
mo="p.o." 46:4 46:4
f="q.d." 46:5 46:5
du="nm"
r="nm"
ln="list"
11:
m="amitriptyline" 47:1 47:1
do="25 to 50 mg" 47:2 47:5
mo="p.o." 47:6 47:6
f="q.h.s. p.r.n." 47:7 47:8
du="nm"
r="nm"
ln="list"
12:
m="multivitamins." 48:1 48:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="aspirin" 49:1 49:1
do="325 mg" 49:2 49:3
mo="p.o." 49:4 49:4
f="q.d." 49:5 49:5
du="nm"
r="nm"
ln="list"
14:
m="folate" 50:1 50:1
do="100 mg" 50:2 50:3
mo="p.o." 50:4 50:4
f="q.d." 50:5 50:5
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 51:1 51:1
do="20 mg" 51:2 51:3
mo="p.o." 51:4 51:4
f="q.d." 51:5 51:5
du="nm"
r="nm"
ln="list"
16:
m="iron gluconate" 52:1 52:2
do="325 mg" 52:3 52:4
mo="p.o." 52:5 52:5
f="t.i.d." 52:6 52:6
du="nm"
r="nm"
ln="list"
17:
m="novolin" 53:1 53:1
do="34 to 40 units" 53:2 53:5
mo="subcu." 53:6 53:6
f="q.d." 53:7 53:7
du="nm"
r="nm"
ln="list"
18:
m="epogen" 54:1 54:1
do="5000 units" 54:2 54:3
mo="subcu." 54:4 54:4
f="q. week." 54:5 54:6
du="nm"
r="nm"
ln="list"
19:
m="levofloxacin" 98:6 98:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="lobar pneumonia" 99:4 99:5
ln="narrative"
20:
m="ace inhibitor." 113:9 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="nph" 117:2 117:2
do="20 units" 117:7 117:8
mo="subcu." 117:9 117:9
f="q.d." 117:10 117:10
du="nm"
r="nm"
ln="narrative"
22:
m="lispro" 118:0 118:0
do="5 units" 119:2 119:3
mo="nm"
f="a day" 119:4 119:5
du="nm"
r="nm"
ln="narrative"
23:
m="lispro" 118:0 118:0
do="sliding scale" 118:1 118:2
mo="nm"
f="q.a.c." 118:3 118:3
du="nm"
r="nm"
ln="narrative"
24:
m="lispro" 118:0 118:0
do="sliding scale" 118:1 118:2
mo="nm"
f="q.h.s." 118:5 118:5
du="nm"
r="nm"
ln="narrative"
25:
m="nph" 120:9 120:9
do="34 units" 121:1 121:2
mo="nm"
f="a day" 121:3 121:4
du="nm"
r="nm"
ln="narrative"
26:
m="lasix" 125:6 125:6
do="nm"
mo="iv" 125:5 125:5
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lasix" 127:3 127:3
do="nm"
mo="p.o." 127:2 127:2
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="aspirin" 128:6 128:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="atenolol" 128:8 128:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="lipitor" 128:4 128:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="lisinopril" 129:6 129:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="metoprolol" 129:1 129:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="renal insufficiency" 129:4 129:5
ln="narrative"
33:
m="captopril" 130:2 130:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="ace inhibitor." 131:5 131:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="captopril" 134:1 134:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lasix" 134:5 134:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="lasix" 135:2 135:2
do="80 mg" 135:6 135:7
mo="p.o." 135:8 135:8
f="b.i.d." 135:9 135:9
du="nm"
r="nm"
ln="narrative"
38:
m="lasix" 135:2 135:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="epogen" 141:9 141:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="iron" 141:7 141:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="h2 blocker." 147:3 147:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis" 147:0 147:0
ln="narrative"
42:
m="heparin" 147:1 147:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis" 147:0 147:0
ln="narrative"
43:
m="lasix" 155:1 155:1
do="80 mg" 155:2 155:3
mo="p.o." 155:4 155:4
f="b.i.d." 155:5 155:5
du="nm"
r="nm"
ln="list"
44:
m="metoprolol" 156:1 156:1
do="12.5 mg" 156:2 156:3
mo="p.o." 156:4 156:4
f="b.i.d." 156:5 156:5
du="nm"
r="nm"
ln="list"
45:
m="lipitor" 157:1 157:1
do="10 mg" 157:2 157:3
mo="p.o." 157:4 157:4
f="q.d." 157:5 157:5
du="nm"
r="nm"
ln="list"
46:
m="amitriptyline" 158:1 158:1
do="25 to 50 mg" 158:2 158:5
mo="p.o." 158:6 158:6
f="q.h.s. p.r.n." 158:7 158:8
du="nm"
r="nm"
ln="list"
47:
m="multivitamins." 159:1 159:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
48:
m="aspirin325" 160:1 160:1
do="aspirin325 mg" 160:1 160:2
mo="p.o." 160:3 160:3
f="q.d." 160:4 160:4
du="nm"
r="nm"
ln="list"
49:
m="colace" 161:1 161:1
do="100 mg" 161:2 161:3
mo="p.o." 161:4 161:4
f="b.i.d." 161:5 161:5
du="nm"
r="nm"
ln="list"
50:
m="lisinopril" 162:1 162:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="iron gluconate" 163:1 163:2
do="325 mg" 163:3 163:4
mo="p.o." 163:5 163:5
f="q.i.d." 163:6 163:6
du="nm"
r="nm"
ln="list"
52:
m="nph" 164:1 164:1
do="20 units" 164:2 164:3
mo="subcu." 164:4 164:4
f="q.h.s." 164:5 164:5
du="nm"
r="nm"
ln="list"
53:
m="lispro" 165:1 165:1
do="sliding scale" 165:2 165:3
mo="nm"
f="q.a.c." 165:4 165:4
du="nm"
r="nm"
ln="list"
54:
m="lispro" 165:1 165:1
do="sliding scale" 165:2 165:3
mo="nm"
f="q.h.s." 165:6 165:6
du="nm"
r="nm"
ln="list"
55:
m="epogen" 166:1 166:1
do="5000 units" 166:2 166:3
mo="subcu." 166:4 166:4
f="q. week." 166:5 166:6
du="nm"
r="nm"
ln="list"
56:
m="toprol" 170:4 170:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="lisinopril" 171:1 171:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="lasix" 174:7 174:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="better diuresis." 175:2 175:3
ln="narrative"
