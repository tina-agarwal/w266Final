1:
m="tylenol" 8:3 8:3
do="325 to 650 mg" 8:4 8:7
mo="p.o." 8:8 8:8
f="q.4 h. p.r.n." 8:9 9:0
du="nm"
r="pain" 9:1 9:1
ln="list"
2:
m="amiodarone" 9:10 9:10
do="400 mg" 10:8 10:9
mo="p.o." 10:10 10:10
f="daily" 10:11 10:11
du="nm"
r="nm"
ln="list"
3:
m="amiodarone" 9:10 9:10
do="400 mg" 9:11 9:12
mo="p.o." 10:0 10:0
f="b.i.d." 10:1 10:1
du="for six more days" 10:2 10:5
r="nm"
ln="list"
4:
m="duoneb" 9:3 9:3
do="3/0.5 mg" 9:4 9:5
mo="nm"
f="q.6 h. p.r.n." 9:6 9:8
du="nm"
r="nm"
ln="list"
5:
m="econazole nitrate" 11:12 12:0
do="nm"
mo="topical" 12:1 12:1
f="daily" 12:2 12:2
du="nm"
r="nm"
ln="list"
6:
m="heparin" 12:4 12:4
do="5000 units" 12:5 12:6
mo="subcutaneously" 12:7 12:7
f="q.12 h." 12:8 12:9
du="nm"
r="nm"
ln="list"
7:
m="imodium a-d" 13:8 13:9
do="2 mg" 14:0 14:1
mo="p.o." 14:2 14:2
f="b.i.d." 14:3 14:3
du="nm"
r="nm"
ln="list"
8:
m="regular insulin" 13:0 13:1
do="sliding scale" 13:2 13:3
mo="subcutaneously" 13:4 13:4
f="q.6 h." 13:5 13:6
du="nm"
r="nm"
ln="list"
9:
m="lopressor" 14:11 14:11
do="50 mg" 14:12 15:0
mo="p.o." 15:1 15:1
f="q.6 h." 15:2 15:3
du="nm"
r="nm"
ln="list"
10:
m="metoclopramide" 14:5 14:5
do="10 mg" 14:6 14:7
mo="p.o." 14:8 14:8
f="q.i.d." 14:9 14:9
du="nm"
r="nm"
ln="list"
11:
m="omeprazole" 16:3 16:3
do="40 mg" 16:4 16:5
mo="p.o." 16:6 16:6
f="b.i.d." 16:7 16:7
du="nm"
r="nm"
ln="list"
12:
m="oxycodone 1 mg per 1 ml solution" 16:9 17:0
do="5 mg" 17:5 17:6
mo="p.o." 17:7 17:7
f="q.4 h. p.r.n." 17:8 17:10
du="nm"
r="pain" 17:11 17:11
ln="list"
13:
m="carafate" 17:13 17:13
do="1 gm" 17:14 18:0
mo="p.o." 18:1 18:1
f="q.i.d." 18:2 18:2
du="nm"
r="nm"
ln="list"
14:
m="ambien" 18:5 18:5
do="2.5 mg" 18:6 18:7
mo="p.o." 18:8 18:8
f="nightly." 18:9 18:9
du="nm"
r="nm"
ln="list"
15:
m="tpn" 19:9 19:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lopressor" 44:7 44:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="diltiazem" 45:0 45:0
do="nm"
mo="drip." 45:1 45:1
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="amiodarone" 46:3 46:3
do="nm"
mo="drip" 46:6 46:6
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="digoxin" 48:1 48:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="amiodarone" 51:3 51:3
do="nm"
mo="iv." 51:4 51:4
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="packed cells" 54:7 54:8
do="two units" 54:4 54:5
mo="nm"
f="nm"
du="nm"
r="hematocrits" 54:0 54:0
ln="narrative"
22:
m="pepcid" 55:11 55:11
do="nm"
mo="iv" 55:12 55:12
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="nexium" 56:2 56:2
do="nm"
mo="drip" 56:3 56:3
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="these medications" 57:10 58:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="tpn" 58:5 58:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="carafate" 62:0 62:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="nexium" 62:5 62:5
do="nm"
mo="p.o." 62:6 62:6
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="tpn" 64:2 64:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="tpn" 66:0 66:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
