1:
m="nitroglycerin" 27:2 27:2
do="one" 27:1 27:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="isordil" 31:9 31:9
do="20 mg" 31:10 32:0
mo="p.o." 32:1 32:1
f="t.i.d." 32:2 32:2
du="nm"
r="nm"
ln="narrative"
3:
m="lopressor" 31:3 31:3
do="50 mg" 31:4 31:5
mo="p.o." 31:6 31:6
f="b.i.d." 31:7 31:7
du="nm"
r="nm"
ln="narrative"
4:
m="verapamil" 32:4 32:4
do="80 mg" 32:5 32:6
mo="p.o." 32:7 32:7
f="t.i.d" 32:8 32:8
du="nm"
r="nm"
ln="narrative"
5:
m="xanax" 32:10 32:10
do="0.25 mg" 32:11 32:12
mo="p.o." 32:13 32:13
f="b.i.d. p.r.n." 33:0 33:1
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 33:4 33:4
do="one" 33:3 33:3
mo="nm"
f="q.d." 33:5 33:5
du="nm"
r="nm"
ln="narrative"
7:
m="nitroglycerin." 33:8 33:8
do="nm"
mo="nm"
f="p.r.n." 33:7 33:7
du="nm"
r="nm"
ln="narrative"
8:
m="lopressor" 47:3 47:3
do="50 mg" 48:0 48:1
mo="p.o." 48:2 48:2
f="b.i.d." 48:3 48:3
du="nm"
r="nm"
ln="narrative"
9:
m="isordil" 48:5 48:5
do="20 mg" 48:6 48:7
mo="p.o." 48:8 48:8
f="t.i.d." 48:9 48:9
du="nm"
r="nm"
ln="narrative"
10:
m="verapamil" 48:11 48:11
do="80 mg" 48:12 48:13
mo="p.o." 49:0 49:0
f="t.i.d." 49:1 49:1
du="nm"
r="nm"
ln="narrative"
11:
m="aspirin" 49:4 49:4
do="one" 49:3 49:3
mo="nm"
f="q.d." 49:5 49:5
du="nm"
r="nm"
ln="list"
12:
m="pepcid" 49:7 49:7
do="20 mg" 49:8 49:9
mo="p.o." 49:10 49:10
f="b.i.d." 49:11 49:11
du="nm"
r="nm"
ln="list"
