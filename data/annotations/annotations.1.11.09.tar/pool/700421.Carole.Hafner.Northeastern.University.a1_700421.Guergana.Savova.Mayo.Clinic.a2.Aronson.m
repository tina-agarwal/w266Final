1:
m="antibiotics" 19:7 19:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="an infection" 18:22 19:0
ln="narrative"
2:
m="insulin" 31:9 31:9
do="20 units" 31:5 31:6
mo="iv" 31:8 31:8
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="insulin" 32:3 32:3
do="8 units" 32:5 32:6
mo="drip" 32:4 32:4
f="per hour" 32:7 32:8
du="nm"
r="nm"
ln="narrative"
4:
m="albuterol" 33:9 33:9
do="nm"
mo="nebs" 34:0 34:0
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="calcium gluconate" 33:2 33:3
do="2 amps" 32:12 33:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="kayexalate" 33:7 33:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="lantus" 58:1 58:1
do="24 units" 58:2 58:3
mo="subcu" 58:4 58:4
f="each night." 58:5 58:6
du="nm"
r="nm"
ln="list"
8:
m="novolog" 59:1 59:1
do="sliding scale." 59:2 59:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="phoslo." 60:1 60:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="nephrocaps." 61:1 61:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="vitamin d." 62:1 62:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="sevelamer" 63:1 63:1
do="1600" 63:2 63:2
mo="nm"
f="t.i.d." 63:3 63:3
du="nm"
r="nm"
ln="list"
13:
m="toprol" 64:1 64:1
do="100 mg" 64:2 64:3
mo="p.o." 64:4 64:4
f="daily." 64:5 64:5
du="nm"
r="nm"
ln="list"
14:
m="lisinopril" 65:1 65:1
do="5 mg" 65:2 65:3
mo="p.o." 65:4 65:4
f="daily." 65:5 65:5
du="nm"
r="nm"
ln="list"
15:
m="plavix" 66:1 66:1
do="75 mg" 66:2 66:3
mo="p.o." 66:4 66:4
f="daily." 66:5 66:5
du="nm"
r="nm"
ln="list"
16:
m="keppra" 67:1 67:1
do="500 mg" 67:2 67:3
mo="p.o." 67:4 67:4
f="b.i.d." 67:5 67:5
du="nm"
r="nm"
ln="list"
17:
m="flovent" 68:1 68:1
do="two puffs" 68:2 68:3
mo="nm"
f="b.i.d." 68:4 68:4
du="nm"
r="nm"
ln="list"
18:
m="albuterol" 69:1 69:1
do="nm"
mo="nm"
f="p.r.n." 69:2 69:2
du="nm"
r="nm"
ln="list"
19:
m="baclofen" 70:1 70:1
do="5 mg" 70:2 70:3
mo="p.o." 70:4 70:4
f="t.i.d." 70:5 70:5
du="nm"
r="nm"
ln="list"
20:
m="ambien" 71:1 71:1
do="10 mg" 71:2 71:3
mo="p.o." 71:4 71:4
f="at bedtime p.r.n." 71:5 71:7
du="nm"
r="nm"
ln="list"
21:
m="insulin" 115:11 115:11
do="nm"
mo="drip" 116:0 116:0
f="nm"
du="nm"
r="DKA:" 115:1 115:1
ln="narrative"
22:
m="normal saline" 121:11 122:0
do="250 ml" 122:5 122:6
mo="boluses" 122:7 122:7
f="nm"
du="nm"
r="her right thigh cellulitis" 120:6 120:9
ln="narrative"
23:
m="normal saline" 121:11 122:0
do="500 ml" 121:9 121:10
mo="boluses" 122:1 122:1
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="insulin" 124:7 124:7
do="nm"
mo="drip" 124:8 124:8
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="lantus" 125:7 125:7
do="24 units" 125:8 125:9
mo="subcu" 125:10 125:10
f="daily." 126:0 126:0
du="nm"
r="nm"
ln="narrative"
26:
m="nph" 125:3 125:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="insulin" 127:4 127:4
do="sliding scale." 127:5 127:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="novolog" 133:6 133:6
do="sliding scale" 133:7 133:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="lantus insulin." 134:0 134:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="right thigh cellulitis:" 137:1 137:3
ln="narrative"
30:
m="insulin" 135:5 135:5
do="nm"
mo="nm"
f="ac" 135:4 135:4
du="nm"
r="nm"
ln="narrative"
31:
m="augmentin" 137:9 137:9
do="nm"
mo="iv" 138:1 138:1
f="nm"
du="nm"
r="right thigh cellulitis:" 137:1 137:3
ln="narrative"
32:
m="vancomycin." 138:2 138:2
do="nm"
mo="iv" 138:1 138:1
f="nm"
du="nm"
r="right thigh cellulitis:" 137:1 137:3
ln="narrative"
33:
m="vancomycin" 143:0 143:0
do="nm"
mo="nm"
f="every other day." 143:6 143:8
du="nm"
r="nm"
ln="narrative"
34:
m="sodium bicarbonate" 154:10 155:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="d5w" 155:2 155:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lopressor" 168:5 168:5
do="25" 168:6 168:6
mo="nm"
f="q.i.d." 168:7 168:7
du="nm"
r="her hypertension" 166:3 166:4
ln="narrative"
37:
m="captopril" 169:0 169:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="heparin" 178:6 178:6
do="5000 units" 178:7 178:8
mo="subcu" 179:0 179:0
f="t.i.d." 179:1 179:1
du="nm"
r="prophylaxis" 178:4 178:4
ln="narrative"
39:
m="nephrocaps" 178:1 178:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="sevelamer." 178:3 178:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="heparin." 179:9 179:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis" 178:4 178:4
ln="narrative"
42:
m="augmentin" 191:3 191:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="diarrhea." 190:10 190:10
ln="narrative"
