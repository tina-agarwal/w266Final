1:
m="plaquenil" 25:9 25:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="diltiazem" 37:4 37:4
do="240 mg" 37:5 37:6
mo="nm"
f="a day" 37:7 37:8
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 38:0 38:0
do="40 mg" 38:1 38:2
mo="nm"
f="a day" 38:3 38:4
du="nm"
r="nm"
ln="list"
4:
m="naprosyn" 38:6 38:6
do="500 mg" 38:7 38:8
mo="nm"
f="b.i.d." 38:9 38:9
du="nm"
r="nm"
ln="list"
5:
m="nph insulin" 38:11 39:0
do="24 units" 39:1 39:2
mo="subcutaneously" 39:3 39:3
f="q.a.m." 39:4 39:4
du="nm"
r="nm"
ln="list"
6:
m="entex-la" 39:6 39:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="cefuroxime" 74:1 74:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="a presumed community acquired pneumonia" 74:9 75:3
ln="narrative"
8:
m="levofloxacin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="a presumed community acquired pneumonia" 74:9 75:3
ln="narrative"
9:
m="lasix" 75:8 75:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="azithromycin" 88:7 88:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="a community acquired pneumonia" 86:7 87:0
ln="narrative"
11:
m="cefuroxime" 88:5 88:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="a community acquired pneumonia" 86:7 87:0
ln="narrative"
12:
m="levofloxacin" 92:8 92:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="legionella" 90:6 90:6
ln="narrative"
13:
m="azithromycin" 94:2 94:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="cefuroxime" 94:5 94:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="lasix" 103:5 103:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="oxygen" 107:6 107:6
do="5 to 6 liters" 108:1 108:4
mo="per nasal cannula" 108:5 108:7
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="o2" 109:3 109:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="oxygen" 110:9 110:9
do="nm"
mo="nm"
f="p.r.n." 110:8 110:8
du="nm"
r="nm"
ln="narrative"
19:
m="oxygen" 124:4 124:4
do="nm"
mo="nm"
f="p.r.n." 124:3 124:3
du="nm"
r="nm"
ln="narrative"
20:
m="lasix" 127:6 127:6
do="80 mg" 128:0 128:1
mo="nm"
f="b.i.d." 128:2 128:2
du="nm"
r="nm"
ln="list"
21:
m="insulin" 128:4 128:4
do="sliding scale" 128:5 128:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="levofloxacin" 129:6 129:6
do="500 mg" 129:7 129:8
mo="nm"
f="nm"
du="times 14 days" 129:9 129:11
r="nm"
ln="list"
23:
m="lisinopril" 129:0 129:0
do="40 mg" 129:1 129:2
mo="nm"
f="a day" 129:3 129:4
du="nm"
r="nm"
ln="list"
24:
m="cardizem-cd" 130:0 130:0
do="240 mg" 130:1 130:2
mo="p.o." 130:3 130:3
f="q.d." 130:4 130:4
du="nm"
r="nm"
ln="list"
