1:
m="medication regimen" 20:2 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="anticoagulation" 55:3 55:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="beta-blocker" 59:2 59:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="coumadin." 59:8 59:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="lasix" 62:12 62:12
do="nm"
mo="iv" 62:11 62:11
f="once or twice a day as needed." 62:13 63:5
du="nm"
r="nm"
ln="narrative"
6:
m="lasix" 63:10 63:10
do="160" 65:1 65:1
mo="nm"
f="once a day" 65:2 65:4
du="nm"
r="nm"
ln="narrative"
7:
m="lasix" 63:10 63:10
do="160 mg" 63:12 63:13
mo="p.o." 63:14 63:14
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="lasix" 63:10 63:10
do="160 mg" 63:12 63:13
mo="p.o." 63:14 63:14
f="twice per day" 64:9 64:11
du="nm"
r="nm"
ln="narrative"
9:
m="lasix" 63:10 63:10
do="160 mg" 64:6 64:7
mo="iv" 64:8 64:8
f="twice per day" 64:9 64:11
du="two doses" 64:3 64:4
r="nm"
ln="narrative"
10:
m="procardia" 70:7 70:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="hydrochlorothiazide" 71:0 71:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="revatio" 71:2 71:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="toprol." 71:5 71:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="oxygen" 79:4 79:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="his pulmonary hypertension." 79:8 80:0
ln="narrative"
15:
m="oxygen" 80:7 80:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="coumadin" 85:0 85:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="inr goal" 85:3 85:4
ln="narrative"
17:
m="coumadin" 87:13 87:13
do="11 mg" 88:11 88:12
mo="nm"
f="on monday , wednesday and friday" 88:13 89:4
du="nm"
r="nm"
ln="narrative"
18:
m="coumadin" 87:13 87:13
do="12 mg" 89:6 89:7
mo="nm"
f="the other days of the week." 89:8 90:0
du="nm"
r="nm"
ln="narrative"
19:
m="coumadin" 87:13 87:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="home regimen" 88:6 88:7
do="11 mg" 88:11 88:12
mo="nm"
f="on monday , wednesday and friday" 88:13 89:4
du="nm"
r="nm"
ln="narrative"
21:
m="oxycodone." 102:9 102:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hip pain" 102:4 102:6
ln="narrative"
22:
m="dilaudid" 103:3 103:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="better pain control." 103:5 103:7
ln="narrative"
23:
m="oxycodone" 104:11 104:11
do="home dose" 104:8 104:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="dilaudid" 105:8 105:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="allopurinol" 110:9 110:9
do="home doses" 110:6 110:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="colchicine." 111:0 111:0
do="home doses" 110:6 110:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="indocin" 111:1 111:1
do="nm"
mo="nm"
f="nm"
du="two days" 112:1 112:2
r="nm"
ln="narrative"
28:
m="indocin" 112:4 112:4
do="nm"
mo="nm"
f="nm"
du="two days" 112:1 112:2
r="nm"
ln="narrative"
29:
m="indocin." 113:5 113:5
do="nm"
mo="nm"
f="nm"
du="a total of three days" 112:11 113:3
r="nm"
ln="narrative"
30:
m="narcotics" 113:8 113:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his gouty pain." 114:8 114:10
ln="narrative"
31:
m="tylenol" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="his gouty pain." 114:8 114:10
ln="narrative"
32:
m="nexium" 115:5 115:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="prilosec" 116:0 116:0
do="nm"
mo="nm"
f="nm"
du="while an inpatient." 116:1 116:3
r="nm"
ln="narrative"
34:
m="nexium" 117:0 117:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="coumadin" 132:2 132:2
do="11 mg" 132:3 132:4
mo="nm"
f="monday , wednesday and friday" 132:5 133:0
du="nm"
r="nm"
ln="list"
36:
m="coumadin" 132:2 132:2
do="12 mg" 133:2 133:3
mo="nm"
f="nightly on tuesdays , thursdays , saturday and sunday" 133:4 134:0
du="nm"
r="nm"
ln="list"
37:
m="diovan" 134:2 134:2
do="320" 134:3 134:3
mo="nm"
f="a day" 134:4 134:5
du="nm"
r="nm"
ln="list"
38:
m="multivitamin" 134:7 134:7
do="1 tab" 134:8 134:9
mo="nm"
f="daily " 134:10 134:10
du="nm"
r="nm"
ln="list"
39:
m="toprol-xl" 134:12 134:12
do="50" 134:13 134:13
mo="nm"
f="once a day" 135:0 135:2
du="nm"
r="nm"
ln="list"
40:
m="nifedipine extended release" 135:4 135:6
do="30" 135:7 135:7
mo="nm"
f="once a day" 135:8 135:10
du="nm"
r="nm"
ln="list"
41:
m="revatio" 135:12 135:12
do="20 mg" 135:13 136:0
mo="nm"
f="3 times a day" 136:1 136:4
du="nm"
r="nm"
ln="list"
42:
m="hydrochlorothiazide" 136:6 136:6
do="25" 136:7 136:7
mo="nm"
f="once a day" 136:8 136:10
du="nm"
r="nm"
ln="list"
43:
m="lasix" 136:12 136:12
do="160" 136:13 136:13
mo="iv" 136:14 136:14
f="once per day" 137:0 137:2
du="nm"
r="nm"
ln="list"
44:
m="allopurinol" 137:4 137:4
do="200" 137:5 137:5
mo="nm"
f="once per day" 137:6 137:8
du="nm"
r="nm"
ln="list"
45:
m="colchicine" 137:10 137:10
do="0.6" 137:11 137:11
mo="nm"
f="once per day" 137:12 138:1
du="nm"
r="nm"
ln="list"
46:
m="colace " 138:3 138:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="dilaudid" 138:11 138:11
do="2 mg" 138:12 138:13
mo="p.o." 139:0 139:0
f="q.4 h....p.r.n." 138:14 138:15,139:1 139:1
du="nm"
r="pain" 139:2 139:2
ln="list"
48:
m="prilosec" 138:5 138:5
do="20" 138:6 138:6
mo="nm"
f="once a day" 138:7 138:9
du="nm"
r="pain" 139:2 139:2
ln="list"
49:
m="tylenol" 139:4 139:4
do="500-1000 mg" 139:5 139:6
mo="p.o." 139:7 139:7
f="q.6 h. p.r.n." 139:8 139:10
du="nm"
r="pain" 139:11 139:11
ln="list"
50:
m="ambien" 140:13 140:13
do="10 mg" 141:0 141:1
mo="p.o." 141:2 141:2
f="nightly p.r.n." 141:3 141:4
du="nm"
r="insomnia" 141:5 141:5
ln="list"
