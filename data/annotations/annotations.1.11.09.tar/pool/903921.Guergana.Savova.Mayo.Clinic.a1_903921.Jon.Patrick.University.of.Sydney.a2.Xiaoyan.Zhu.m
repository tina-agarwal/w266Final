1:
m="aspirin" 56:1 56:1
do="325 mg" 56:2 56:3
mo="p.o." 56:4 56:4
f="daily" 56:5 56:5
du="nm"
r="nm"
ln="list"
2:
m="plavix" 57:1 57:1
do="75 mg" 57:2 57:3
mo="p.o." 57:4 57:4
f="daily" 57:5 57:5
du="nm"
r="nm"
ln="list"
3:
m="cardizem" 58:1 58:1
do="60 mg" 58:2 58:3
mo="p.o." 58:4 58:4
f="t.i.d." 58:5 58:5
du="nm"
r="nm"
ln="list"
4:
m="lipitor" 59:1 59:1
do="80 mg" 59:2 59:3
mo="nm"
f="daily" 59:4 59:4
du="nm"
r="nm"
ln="list"
5:
m="atrovent" 60:1 60:1
do="2 puffs" 60:2 60:3
mo="nm"
f="four times a day" 60:4 60:7
du="nm"
r="nm"
ln="list"
6:
m="albuterol" 61:1 61:1
do="2 puffs" 61:2 61:3
mo="nm"
f="b.i.d." 61:4 61:4
du="nm"
r="nm"
ln="list"
7:
m="renagel" 62:1 62:1
do="806 mg" 62:2 62:3
mo="p.o." 62:4 62:4
f="every meal" 62:5 62:6
du="nm"
r="nm"
ln="list"
8:
m="allopurinol" 63:1 63:1
do="100 mg" 63:2 63:3
mo="p.o." 63:4 63:4
f="daily" 63:5 63:5
du="nm"
r="nm"
ln="list"
9:
m="zaroxylyn" 64:1 64:1
do="2.5 mg" 64:2 64:3
mo="p.o." 64:4 64:4
f="daily p.r.n." 64:5 64:6
du="nm"
r="overload" 64:7 64:7
ln="list"
10:
m="lantus" 65:1 65:1
do="10 units" 65:2 65:3
mo="subcutaneous" 65:4 65:4
f="nightly" 65:5 65:5
du="nm"
r="nm"
ln="list"
11:
m="regular insulin" 66:1 66:2
do="sliding scale" 66:3 66:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="valium" 67:1 67:1
do="5 mg" 67:2 67:3
mo="p.o." 67:4 67:4
f="b.i.d. p.r.n." 67:5 67:6
du="nm"
r="nm"
ln="list"
13:
m="isordil" 68:1 68:1
do="40 mg" 68:2 68:3
mo="p.o." 68:4 68:4
f="t.i.d." 68:5 68:5
du="nm"
r="nm"
ln="list"
14:
m="hydralazine" 69:1 69:1
do="20 mg" 69:2 69:3
mo="p.o." 69:4 69:4
f="t.i.d." 69:5 69:5
du="nm"
r="nm"
ln="list"
15:
m="lopressor" 70:1 70:1
do="75 mg" 70:2 70:3
mo="p.o." 70:4 70:4
f="t.i.d." 70:5 70:5
du="nm"
r="nm"
ln="list"
16:
m="zantac" 71:1 71:1
do="150 mg" 71:2 71:3
mo="p.o." 71:4 71:4
f="b.i.d." 71:5 71:5
du="nm"
r="nm"
ln="list"
17:
m="aciphex" 72:1 72:1
do="20 mg" 72:2 72:3
mo="p.o." 72:4 72:4
f="daily" 72:5 72:5
du="nm"
r="nm"
ln="list"
18:
m="neurontin" 73:1 73:1
do="300 mg" 73:2 73:3
mo="p.o." 73:4 73:4
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="metamucil" 74:1 74:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="nitroglycerine" 75:1 75:1
do="nm"
mo="nm"
f="p.r.n." 75:2 75:2
du="nm"
r="nm"
ln="list"
21:
m="procrit" 76:1 76:1
do="40 , 000 units" 76:2 76:5
mo="subcutaneously" 76:6 76:6
f="every week" 76:7 76:8
du="nm"
r="nm"
ln="list"
22:
m="lilly insulin pen" 77:1 77:3
do="10 units" 78:0 78:1
mo="nm"
f="every evening" 78:2 78:3
du="nm"
r="nm"
ln="list"
23:
m="lilly insulin pen" 77:1 77:3
do="20 units" 77:7 77:8
mo="nm"
f="every morning" 77:9 77:10
du="nm"
r="nm"
ln="list"
24:
m="loperamide" 79:1 79:1
do="2 tabs" 79:2 79:3
mo="p.o." 79:4 79:4
f="four times a day" 79:5 79:8
du="nm"
r="nm"
ln="list"
25:
m="ambien" 80:1 80:1
do="10 mg" 80:2 80:3
mo="p.o." 80:4 80:4
f="nightly p.r.n." 80:5 80:6
du="nm"
r="nm"
ln="list"
26:
m="antibiotics" 105:3 105:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="narcotic" 109:1 109:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="haldol" 110:9 110:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="agitation" 111:2 111:2
ln="narrative"
29:
m="haldol" 110:9 110:9
do="significant doses" 110:4 110:5
mo="nm"
f="nm"
du="nm"
r="delirium" 111:4 111:4
ln="narrative"
30:
m="zyprexa" 110:7 110:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="agitation" 111:2 111:2
ln="narrative"
31:
m="zyprexa" 110:7 110:7
do="significant doses" 110:4 110:5
mo="nm"
f="nm"
du="nm"
r="delirium" 111:4 111:4
ln="narrative"
32:
m="beta blockade" 133:7 133:8
do="titrated up" 134:0 134:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="home medications" 151:2 151:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="lopressor" 151:10 151:10
do="50 mg" 152:11 152:12
mo="p.o." 152:13 152:13
f="t.i.d." 152:14 152:14
du="nm"
r="nm"
ln="narrative"
35:
m="betadine paint" 153:10 154:0
do="nm"
mo="incisions" 154:2 154:2
f="daily." 154:3 154:3
du="nm"
r="wound care" 153:7 153:8
ln="narrative"
36:
m="tylenol" 160:1 160:1
do="325 mg" 160:2 160:3
mo="p.o." 160:4 160:4
f="every four hours p.r.n." 160:5 160:8
du="nm"
r="pain" 160:9 160:9
ln="list"
37:
m="albuterol inhaler" 161:1 161:2
do="2 puffs" 161:3 161:4
mo="nm"
f="b.i.d." 161:5 161:5
du="nm"
r="nm"
ln="list"
38:
m="allopurinol" 162:1 162:1
do="100 mg" 162:2 162:3
mo="p.o." 162:4 162:4
f="daily" 162:5 162:5
du="nm"
r="nm"
ln="list"
39:
m="aspirin" 163:1 163:1
do="325 mg" 163:2 163:3
mo="p.o." 163:4 163:4
f="daily" 163:5 163:5
du="nm"
r="nm"
ln="list"
40:
m="calcitriol" 164:1 164:1
do="1.5 mcg" 164:2 164:3
mo="p.o." 164:4 164:4
f="every monday" 164:5 164:6
du="nm"
r="nm"
ln="list"
41:
m="calcitriol" 164:1 164:1
do="1.5 mcg" 164:2 164:3
mo="p.o." 164:4 164:4
f="every monday and every friday" 164:5 164:9
du="nm"
r="nm"
ln="list"
42:
m="plavix" 165:1 165:1
do="75 mg" 165:2 165:3
mo="p.o." 165:4 165:4
f="daily" 165:5 165:5
du="nm"
r="nm"
ln="list"
43:
m="darbepoetin alfa" 166:1 166:2
do="100 mcg" 166:3 166:4
mo="subcutaneous" 166:5 166:5
f="every week" 166:6 166:7
du="nm"
r="nm"
ln="list"
44:
m="ferrous sulfate" 167:1 167:2
do="325 mg" 167:3 167:4
mo="p.o." 167:5 167:5
f="t.i.d." 167:6 167:6
du="nm"
r="nm"
ln="list"
45:
m="prozac" 168:1 168:1
do="40 mg" 168:2 168:3
mo="p.o." 168:4 168:4
f="daily" 168:5 168:5
du="nm"
r="nm"
ln="list"
46:
m="neurontin" 169:1 169:1
do="300 mg" 169:2 169:3
mo="p.o." 169:4 169:4
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="motrin" 170:1 170:1
do="400 mg" 170:2 170:3
mo="p.o." 170:4 170:4
f="every eight hours p.r.n." 170:5 170:8
du="nm"
r="pain" 170:9 170:9
ln="list"
48:
m="lantus" 171:1 171:1
do="10 units" 171:2 171:3
mo="subcutaneous" 171:4 171:4
f="nightly" 171:5 171:5
du="nm"
r="nm"
ln="list"
49:
m="insulin regular" 172:1 172:2
do="sliding scale" 172:3 172:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="atrovent" 174:1 174:1
do="2 puffs" 174:2 174:3
mo="nm"
f="four times a day" 174:4 174:7
du="nm"
r="nm"
ln="list"
51:
m="lopressor" 175:1 175:1
do="50 mg" 175:2 175:3
mo="p.o." 175:4 175:4
f="t.i.d." 175:5 175:5
du="nm"
r="nm"
ln="list"
52:
m="metamucil" 177:1 177:1
do="1 packet" 177:2 177:3
mo="p.o." 177:4 177:4
f="daily" 177:5 177:5
du="nm"
r="nm"
ln="list"
53:
m="sevelamer" 178:1 178:1
do="800 mg" 178:2 178:3
mo="p.o." 178:4 178:4
f="t.i.d." 178:5 178:5
du="nm"
r="nm"
ln="list"
54:
m="lipitor" 179:1 179:1
do="80 mg" 179:2 179:3
mo="p.o." 179:4 179:4
f="nightly" 179:5 179:5
du="nm"
r="nm"
ln="list"
