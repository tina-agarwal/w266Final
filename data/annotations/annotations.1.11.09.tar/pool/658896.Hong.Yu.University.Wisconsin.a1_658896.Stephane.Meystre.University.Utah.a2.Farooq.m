1:
m="lisinopril" 28:5 28:5
do="20 mg" 28:6 28:7
mo="p.o." 28:8 28:8
f="q. day." 28:9 28:10
du="nm"
r="nm"
ln="list"
2:
m="diltiazem" 29:0 29:0
do="240 mg" 29:1 29:2
mo="p.o." 29:3 29:3
f="q. day." 29:4 29:5
du="nm"
r="nm"
ln="list"
3:
m="ace inhibitor" 56:4 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lisinopril" 56:7 56:7
do="40 mg" 56:8 57:0
mo="p.o." 57:1 57:1
f="q. day" 57:2 57:3
du="nm"
r="nm"
ln="narrative"
5:
m="diltiazem" 57:7 57:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="beta blocker" 58:8 58:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="hydrochlorothiazide" 58:0 58:0
do="25 mg" 58:1 58:2
mo="p.o." 58:3 58:3
f="q. daily" 58:4 58:5
du="nm"
r="nm"
ln="narrative"
8:
m="lopressor" 59:0 59:0
do="25 mg" 59:1 59:2
mo="p.o." 59:3 59:3
f="q.i.d." 59:4 59:4
du="nm"
r="nm"
ln="narrative"
9:
m="ancef" 62:10 62:10
do="1 gram" 62:11 63:0
mo="iv" 63:1 63:1
f="q. 8h." 63:2 63:3
du="nm"
r="nm"
ln="narrative"
10:
m="antibiotics" 62:7 62:7
do="nm"
mo="iv" 62:6 62:6
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="cephradine" 71:6 71:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="keflex" 71:4 71:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="enteric coated aspirin" 73:5 73:7
do="325 mg" 73:8 73:9
mo="p.o." 73:10 73:10
f="q. day." 74:0 74:1
du="nm"
r="nm"
ln="list"
14:
m="colace" 74:4 74:4
do="100 mg" 74:5 74:6
mo="p.o." 74:7 74:7
f="b.i.d." 74:8 74:8
du="nm"
r="nm"
ln="list"
15:
m="hydrochlorothiazide" 75:2 75:2
do="25 mg" 75:3 75:4
mo="p.o." 75:5 75:5
f="q. daily." 75:6 75:7
du="nm"
r="nm"
ln="list"
16:
m="lisinopril" 75:10 75:10
do="40 mg" 75:11 75:12
mo="p.o." 76:0 76:0
f="q. daily." 76:1 76:2
du="nm"
r="nm"
ln="list"
17:
m="tylox" 76:5 76:5
do="1-2 capsules" 76:6 76:7
mo="p.o." 76:8 76:8
f="q. 4-6h. p.r.n." 76:9 76:11
du="nm"
r="pain." 76:12 76:12
ln="list"
18:
m="atenolol" 77:2 77:2
do="100 mg" 77:3 77:4
mo="p.o." 77:5 77:5
f="q. daily." 77:6 77:7
du="nm"
r="nm"
ln="list"
19:
m="cephradine" 77:10 77:10
do="100 mg" 77:11 77:12
mo="p.o." 77:13 77:13
f="q.i.d." 78:0 78:0
du="times five days." 78:1 78:3
r="nm"
ln="list"
