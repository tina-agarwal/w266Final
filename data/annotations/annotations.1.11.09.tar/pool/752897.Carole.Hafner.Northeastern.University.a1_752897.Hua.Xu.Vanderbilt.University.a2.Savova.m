1:
m="ec asa ( aspirin enteric coated )" 18:0 18:6
do="325 mg" 18:7 18:8
mo="po" 18:9 18:9
f="qd" 18:10 18:10
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 19:0 19:0
do="50 mg" 19:1 19:2
mo="po" 19:3 19:3
f="qpm" 19:4 19:4
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 21:0 21:0
do="75 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qam" 21:4 21:4
du="nm"
r="nm"
ln="list"
4:
m="cipro ( ciprofloxacin )" 23:0 23:3
do="250 mg" 23:4 23:5
mo="po" 23:6 23:6
f="bid" 23:7 23:7
du="nm"
r="nm"
ln="list"
5:
m="insulin nph human" 28:0 28:2
do="30 units" 28:3 28:4
mo="sc" 28:5 28:5
f="qam" 28:6 28:6
du="nm"
r="nm"
ln="list"
6:
m="insulin nph human" 29:0 29:2
do="20 units" 29:3 29:4
mo="sc" 29:5 29:5
f="before dinner" 29:6 29:7
du="nm"
r="nm"
ln="list"
7:
m="insulin regular ( human )" 30:0 30:4
do="18 units" 30:5 30:6
mo="sc" 30:7 30:7
f="qam" 30:8 30:8
du="nm"
r="nm"
ln="list"
8:
m="insulin regular ( human )" 31:0 31:4
do="14 units" 31:5 31:6
mo="sc" 31:7 31:7
f="before dinner" 31:8 31:9
du="nm"
r="nm"
ln="list"
9:
m="levoxyl ( levothyroxine sodium )" 32:0 32:4
do="75 mcg" 32:5 32:6
mo="po" 32:7 32:7
f="qd" 32:8 32:8
du="nm"
r="nm"
ln="list"
10:
m="lisinopril" 33:0 33:0
do="20 mg" 33:1 33:2
mo="po" 33:3 33:3
f="qd" 33:4 33:4
du="nm"
r="nm"
ln="list"
11:
m="nitroglycerin 1/150 ( 0.4 mg )" 34:0 34:5
do="1 tab" 34:6 34:7
mo="sl" 34:8 34:8
f="q5 min...prn" 34:9 34:10,35:0 35:0
du="x 3" 34:11 34:12
r="chest pain" 35:1 35:2
ln="list"
12:
m="pravachol ( pravastatin )" 36:0 36:3
do="20 mg" 36:4 36:5
mo="po" 36:6 36:6
f="qhs" 36:7 36:7
du="nm"
r="nm"
ln="list"
13:
m="amlodipine" 39:0 39:0
do="5 mg" 39:1 39:2
mo="po" 39:3 39:3
f="qd" 39:4 39:4
du="nm"
r="nm"
ln="list"
14:
m="imdur ( isosorbide mononit.( sr ) )" 41:0 41:6
do="60 mg" 41:7 41:8
mo="po" 41:9 41:9
f="qd" 41:10 41:10
du="nm"
r="nm"
ln="list"
15:
m="wellbutrin sr ( bupropion hcl sr )" 45:0 45:6
do="150 mg" 45:7 45:8
mo="po" 45:9 45:9
f="bid" 45:10 45:10
du="number of doses required ( approximate ): 2" 46:0 46:7
r="nm"
ln="list"
16:
m="clopidogrel" 47:0 47:0
do="75 mg" 47:1 47:2
mo="po" 47:3 47:3
f="qd" 47:4 47:4
du="nm"
r="nm"
ln="list"
17:
m="integrilin" 72:1 72:1
do="nm"
mo="nm"
f="nm"
du="for 16 hours" 71:6 72:0
r="nm"
ln="narrative"
18:
m="plavix." 72:5 72:5
do="nm"
mo="nm"
f="nm"
du="30 days" 72:3 72:4
r="nm"
ln="narrative"
