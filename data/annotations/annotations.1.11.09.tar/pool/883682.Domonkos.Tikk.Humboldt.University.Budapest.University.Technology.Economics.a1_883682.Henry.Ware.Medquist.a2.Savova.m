1:
m="insulin regimen" 21:0 21:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetic control" 20:4 20:5
ln="narrative"
2:
m="tpa" 34:5 34:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="thrombosis" 34:0 34:0
ln="narrative"
3:
m="humalog" 43:2 43:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lantus" 43:5 43:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="humalog" 44:4 44:4
do="7 units" 44:5 44:6
mo="nm"
f="b.i.d." 44:7 44:7
du="nm"
r="nm"
ln="narrative"
6:
m="lantus" 44:9 44:9
do="12 units" 44:10 44:11
mo="nm"
f="in the evening." 44:12 45:1
du="nm"
r="nm"
ln="narrative"
7:
m="epivir" 50:5 50:5
do="150 mg" 50:6 50:7
mo="p.o." 50:8 50:8
f="daily" 50:9 50:9
du="nm"
r="a positive e antigen" 49:6 49:9
ln="narrative"
8:
m="oxycodone" 57:0 57:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="fibroid pain." 57:2 57:3
ln="narrative"
9:
m="actinomycin d" 78:10 78:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="choriocarcinoma." 77:11 77:11
ln="narrative"
10:
m="cytoxan" 78:13 78:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="choriocarcinoma." 77:11 77:11
ln="narrative"
11:
m="methotrexate" 78:8 78:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="choriocarcinoma." 77:11 77:11
ln="narrative"
12:
m="bleomycin" 79:5 79:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="cisplatin" 79:3 79:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="vp-16" 79:1 79:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="humalog insulin" 82:3 82:4
do="7 units" 82:5 82:6
mo="nm"
f="twice a day" 82:7 82:9
du="nm"
r="nm"
ln="list"
16:
m="aspirin" 83:7 83:7
do="81 mg" 83:8 83:9
mo="p.o." 83:10 83:10
f="daily" 83:11 83:11
du="nm"
r="nm"
ln="list"
17:
m="lantus" 83:0 83:0
do="12 units" 83:1 83:2
mo="nm"
f="in the evening" 83:3 83:5
du="nm"
r="nm"
ln="list"
18:
m="lamivudine/epivir" 84:6 84:6
do="150" 84:9 84:9
mo="nm"
f="daily" 84:10 84:10
du="nm"
r="nm"
ln="list"
19:
m="insulin" 98:1 98:1
do="sliding scale" 97:5 97:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="lantus" 99:5 99:5
do="20 units" 99:9 99:10
mo="nm"
f="at nighttime" 99:11 100:0
du="nm"
r="nm"
ln="narrative"
21:
m="insulin lispro" 100:13 101:0
do="8 units" 100:6 100:7
mo="nm"
f="three times a day" 100:8 100:11
du="nm"
r="nm"
ln="narrative"
22:
m="lispro" 101:6 101:6
do="sliding scale" 101:7 101:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="aspirin" 109:8 109:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="myocardial infarct" 110:3 110:4
ln="narrative"
24:
m="lovenox" 118:6 118:6
do="90 mg" 119:11 119:12
mo="nm"
f="daily" 120:0 120:0
du="for the duration of this pregnancy" 118:7 119:0
r="nm"
ln="narrative"
25:
m="coumadin" 120:7 120:7
do="nm"
mo="nm"
f="nm"
du="for likely long-term , possibly lifelong duration." 121:1 121:7
r="nm"
ln="narrative"
26:
m="folate supplementation" 124:4 124:5
do="high doses" 124:7 124:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lovenox" 125:7 125:7
do="90 mg" 125:8 125:9
mo="subcutaneously" 126:0 126:0
f="daily" 125:10 125:10
du="nm"
r="nm"
ln="narrative"
28:
m="aspirin" 126:3 126:3
do="81 mg" 126:4 126:5
mo="p.o." 126:6 126:6
f="daily" 126:7 126:7
du="nm"
r="nm"
ln="narrative"
29:
m="epivir" 134:9 134:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="lamivudine" 144:8 144:8
do="nm"
mo="nm"
f="nm"
du="until gastroenterology followup." 144:9 145:1
r="nm"
ln="narrative"
31:
m="oxycodone" 150:0 150:0
do="intermittent doses" 149:7 149:8
mo="nm"
f="rare intermittent...as required" 149:6 149:7,150:1 150:2
du="nm"
r="pain" 150:4 150:4
ln="narrative"
32:
m="prenatal vitamins" 156:4 156:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="b12" 157:3 157:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="b6." 157:5 157:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="folic acid" 157:0 157:1
do="high-dose" 156:10 156:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="aspirin" 172:1 172:1
do="81 mg" 172:2 172:3
mo="p.o." 172:4 172:4
f="daily." 172:5 172:5
du="nm"
r="nm"
ln="list"
37:
m="lovenox" 173:1 173:1
do="90 mg" 173:3 173:4
mo="subcutaneously" 173:2 173:2
f="daily." 173:5 173:5
du="nm"
r="nm"
ln="list"
38:
m="vitamin b12" 174:1 174:2
do="100 mcg" 174:3 174:4
mo="p.o." 174:5 174:5
f="daily." 174:6 174:6
du="nm"
r="nm"
ln="list"
39:
m="folate" 175:1 175:1
do="4 mg" 175:2 175:3
mo="p.o." 175:4 175:4
f="daily." 175:5 175:5
du="nm"
r="nm"
ln="list"
40:
m="prenatal vitamins" 176:1 176:2
do="one tablet" 176:3 176:4
mo="p.o." 176:5 176:5
f="daily." 176:6 176:6
du="nm"
r="nm"
ln="list"
41:
m="lantus" 177:1 177:1
do="20 units" 177:2 177:3
mo="subcutaneously" 177:4 177:4
f="q.p.m.." 177:5 177:5
du="nm"
r="nm"
ln="list"
42:
m="insulin lispro" 178:1 178:2
do="8 units" 178:3 178:4
mo="subcutaneously" 178:5 178:5
f="ac" 178:6 178:6
du="nm"
r="nm"
ln="list"
43:
m="lispro" 178:11 178:11
do="sliding scale" 179:0 179:1
mo="nm"
f="ac." 179:6 179:6
du="nm"
r="nm"
ln="list"
