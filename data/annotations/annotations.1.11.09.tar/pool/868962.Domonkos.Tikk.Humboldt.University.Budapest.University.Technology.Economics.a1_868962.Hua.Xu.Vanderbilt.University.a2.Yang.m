1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="lasix ( furosemide )" 20:0 20:3
do="120 mg" 20:7 20:8
mo="po" 20:10 20:10
f="qpm" 20:9 20:9
du="nm"
r="nm"
ln="list"
3:
m="lasix ( furosemide )" 20:0 20:3
do="120 mg" 21:0 21:1
mo="po" 20:10 20:10
f="qpm" 21:2 21:2
du="nm"
r="nm"
ln="list"
4:
m="lasix ( furosemide )" 20:0 20:3
do="160 mg" 20:11 20:12
mo="nm"
f="qam" 20:13 20:13
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 20:0 20:3
do="160 mg" 20:4 20:5
mo="nm"
f="qam;" 20:6 20:6
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 22:0 22:0
do="80 mg" 22:1 22:2
mo="po" 22:3 22:3
f="qd" 22:4 22:4
du="nm"
r="nm"
ln="list"
7:
m="kcl slow release" 25:3 25:5
do="nm"
mo="po" 25:6 25:6
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 26:3 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 26:5 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="mvi therapeutic ( therapeutic multivitamins )" 28:0 28:5
do="1 tab" 28:6 28:7
mo="po" 28:8 28:8
f="qd" 28:9 28:9
du="nm"
r="nm"
ln="list"
11:
m="norvasc ( amlodipine )" 29:0 29:3
do="10 mg" 29:4 29:5
mo="po" 29:6 29:6
f="qd" 29:7 29:7
du="nm"
r="nm"
ln="list"
12:
m="toprol xl ( metoprolol ( sust. rel. ) )" 32:0 32:8
do="200 mg" 32:9 32:10
mo="po" 32:11 32:11
f="qd" 32:12 32:12
du="number of doses required (approximate): 5" 35:0 35:7
r="nm"
ln="list"
13:
m="ambien ( zolpidem tartrate )" 36:0 36:4
do="5 mg" 36:5 36:6
mo="po" 36:7 36:7
f="qhs" 36:8 36:8
du="nm"
r="nm"
ln="list"
14:
m="depakote er ( divalproex sodium er )" 40:0 40:6
do="1 , 000 mg" 40:7 40:10
mo="po" 40:11 40:11
f="qd" 40:12 40:12
du="nm"
r="nm"
ln="list"
15:
m="asa" 67:7 67:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="norvasc" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="statin" 67:9 67:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="toprol lisinopril" 67:2 67:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="depakote" 68:0 68:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="asa" 79:3 79:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="lasix" 79:7 79:7
do="120" 79:12 79:12
mo="nm"
f="pm" 79:14 79:14
du="nm"
r="volume control." 80:0 80:1
ln="narrative"
22:
m="lasix" 79:7 79:7
do="160" 79:8 79:8
mo="nm"
f="am" 79:10 79:10
du="nm"
r="volume control." 80:0 80:1
ln="narrative"
23:
m="statin" 79:5 79:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="mucomyst" 82:10 82:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="riss" 83:8 83:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="cpap." 84:5 84:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="cpap" 85:1 85:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="your medications" 86:7 86:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
