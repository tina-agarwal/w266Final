1:
m="vitamin c ( ascorbic acid )" 16:0 16:5
do="500 mg" 16:6 16:7
mo="po" 16:8 16:8
f="bid" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="ciprofloxacin" 17:0 17:0
do="400 mg" 17:1 17:2
mo="po" 17:3 17:3
f="q12h" 17:4 17:4
du="number of doses required ( approximate ): 2" 19:0 19:7
r="nm"
ln="list"
3:
m="folate ( folic acid )" 20:0 20:4
do="1 mg" 20:5 20:6
mo="po" 20:7 20:7
f="daily" 20:8 20:8
du="nm"
r="nm"
ln="list"
4:
m="lasix ( furosemide )" 21:0 21:3
do="40 mg" 21:4 21:5
mo="po" 21:6 21:6
f="daily" 21:7 21:7
du="nm"
r="nm"
ln="list"
5:
m="lactulose" 22:0 22:0
do="30 milliliters" 22:1 22:2
mo="po" 22:3 22:3
f="qid" 22:4 22:4
du="nm"
r="nm"
ln="list"
6:
m="flagyl ( metronidazole )" 25:0 25:3
do="500 mg" 25:4 25:5
mo="po" 25:6 25:6
f="q8h" 25:7 25:7
du="nm"
r="nm"
ln="list"
7:
m="aldactone ( spironolactone )" 28:0 28:3
do="75 mg" 28:4 28:5
mo="po" 28:6 28:6
f="bid" 28:7 28:7
du="nm"
r="nm"
ln="list"
8:
m="kcl" 32:3 32:3
do="nm"
mo="iv" 32:4 32:4
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 33:4 33:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="spironolactone" 33:2 33:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="thiamine hcl" 35:0 35:1
do="100 mg" 35:2 35:3
mo="po" 35:4 35:4
f="daily" 35:5 35:5
du="nm"
r="nm"
ln="list"
12:
m="multivitamin therapeutic ( therapeutic multivi... )" 36:0 36:5
do="1 tab" 37:0 37:1
mo="po" 37:2 37:2
f="daily" 37:3 37:3
du="nm"
r="nm"
ln="list"
13:
m="msir ( morphine immediate release )" 38:0 38:5
do="7.5 mg" 38:6 38:7
mo="po" 38:8 38:8
f="q4h prn" 38:9 38:10
du="nm"
r="pain" 38:11 38:11
ln="list"
14:
m="flovent hfa ( fluticasone propionate )" 39:0 39:5
do="220 mcg" 39:6 39:7
mo="inh" 39:8 39:8
f="bid" 39:9 39:9
du="nm"
r="nm"
ln="list"
15:
m="celexa ( citalopram )" 40:0 40:3
do="20 mg" 40:4 40:5
mo="po" 40:6 40:6
f="daily" 40:7 40:7
du="nm"
r="nm"
ln="list"
16:
m="celecoxib" 41:0 41:0
do="100 mg" 41:1 41:2
mo="po" 41:3 41:3
f="daily...prn" 41:4 41:4,42:0 42:0
du="nm"
r="pain" 42:1 42:1
ln="list"
17:
m="keppra ( levetiracetam )" 46:0 46:3
do="1 , 000 mg" 46:4 46:7
mo="po" 46:8 46:8
f="bid" 46:9 46:9
du="nm"
r="nm"
ln="list"
18:
m="caltrate 600 + d ( calcium carbonate 1 , 500 mg ( ... )" 47:0 47:13
do="1 tab" 48:0 48:1
mo="po" 48:2 48:2
f="bid" 48:3 48:3
du="nm"
r="nm"
ln="list"
19:
m="lidoderm 5% patch ( lidocaine 5% patch )" 49:0 49:7
do="nm"
mo="topical tp" 49:8 49:9
f="daily" 49:10 49:10
du="nm"
r="nm"
ln="list"
20:
m="novolog ( insulin aspart )" 53:0 53:4
do="0 units" 55:9 55:10
mo="subcutaneously" 55:11 55:11
f="nm"
du="nm"
r="bs" 55:1 55:1
ln="list"
21:
m="novolog ( insulin aspart )" 53:0 53:4
do="10 units" 61:7 61:8
mo="subcutaneously" 61:9 61:9
f="nm"
du="nm"
r="bs" 61:1 61:1
ln="list"
22:
m="novolog ( insulin aspart )" 53:0 53:4
do="2 units" 56:7 56:8
mo="subcutaneously" 56:9 56:9
f="nm"
du="nm"
r="bs" 56:1 56:1
ln="list"
23:
m="novolog ( insulin aspart )" 53:0 53:4
do="3 units" 57:7 57:8
mo="subcutaneously" 57:9 57:9
f="nm"
du="nm"
r="bs" 57:1 57:1
ln="list"
24:
m="novolog ( insulin aspart )" 53:0 53:4
do="4 units" 58:7 58:8
mo="subcutaneously" 58:9 58:9
f="nm"
du="nm"
r="bs" 58:1 58:1
ln="list"
25:
m="novolog ( insulin aspart )" 53:0 53:4
do="6 units" 59:7 59:8
mo="subcutaneously" 59:9 59:9
f="nm"
du="nm"
r="bs" 59:1 59:1
ln="list"
26:
m="novolog ( insulin aspart )" 53:0 53:4
do="8 units" 60:7 60:8
mo="subcutaneously" 60:9 60:9
f="nm"
du="nm"
r="bs" 60:1 60:1
ln="list"
27:
m="novolog ( insulin aspart )" 53:0 53:4
do="sliding scale" 54:0 54:1
mo="( subcutaneously ) sc" 54:2 54:5
f="ac" 54:6 54:6
du="nm"
r="nm"
ln="list"
28:
m="maalox-tablets quick dissolve/chewable" 63:0 63:2
do="1-2 tab" 63:3 63:4
mo="po" 63:5 63:5
f="q6h prn" 63:6 64:0
du="nm"
r="upset stomach" 64:1 64:2
ln="list"
29:
m="vitamin k ( phytonadione )" 65:0 65:4
do="5 mg" 65:5 65:6
mo="po" 65:7 65:7
f="daily" 65:8 65:8
du="nm"
r="nm"
ln="list"
30:
m="protonix ( pantoprazole )" 66:0 66:3
do="40 mg" 66:4 66:5
mo="po" 66:6 66:6
f="daily" 66:7 66:7
du="nm"
r="nm"
ln="list"
31:
m="toprol xl ( metoprolol succinate extended release )" 67:0 67:7
do="50 mg" 68:0 68:1
mo="po" 68:2 68:2
f="daily" 68:3 68:3
du="nm"
r="nm"
ln="list"
32:
m="magnesium oxide" 70:0 70:1
do="420 mg" 70:2 70:3
mo="po" 70:4 70:4
f="bid" 70:5 70:5
du="nm"
r="nm"
ln="narrative"
33:
m="thiamine" 100:11 100:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="narcan." 101:0 101:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="narcan." 101:7 101:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="keppra" 111:4 111:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="++seizure disorder" 111:0 111:1
ln="narrative"
37:
m="opiates" 148:4 148:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="lactulose" 149:7 149:7
do="nm"
mo="nm"
f="qid." 149:8 149:8
du="nm"
r="++mental status" 149:0 149:1
ln="narrative"
39:
m="narcotics." 149:5 149:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="narcotic" 155:5 155:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="msir" 156:8 156:8
do="nm"
mo="nm"
f="prn" 156:9 156:9
du="nm"
r="pain" 156:3 156:3
ln="narrative"
42:
m="celecoxib" 157:0 157:0
do="nm"
mo="nm"
f="daily prn" 157:1 157:2
du="nm"
r="nm"
ln="narrative"
43:
m="lidoderm patch" 158:7 158:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="nsaids" 159:0 159:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="ciprofloxacin" 166:5 166:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="coag negative staph" 165:6 165:8
ln="narrative"
46:
m="metronidazol" 167:0 167:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="coag negative staph" 165:6 165:8
ln="narrative"
47:
m="vancomycin" 167:7 167:7
do="nm"
mo="nm"
f="nm"
du="until speciation of blood cultures" 167:8 168:0
r="nm"
ln="narrative"
48:
m="vancomycin" 171:6 171:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="cipro" 172:4 172:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="flagyl" 172:6 172:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="cipro" 173:7 173:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="flagyl." 173:9 173:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="flovent" 181:11 181:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="known copd" 182:0 182:1
ln="narrative"
54:
m="lopressor" 184:1 184:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="caltrate" 188:0 188:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="fosamax" 188:7 188:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="vit d." 188:2 188:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="zometa" 189:2 189:2
do="nm"
mo="nm"
f="nm"
du="x 1." 189:3 189:4
r="nm"
ln="narrative"
59:
m="calcium" 190:1 190:1
do="nm"
mo="nm"
f="nm"
du="1 week." 190:3 190:4
r="nm"
ln="narrative"
60:
m="fluids" 191:7 191:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="folate" 191:5 191:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="thiamine" 191:3 191:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="lovenox" 192:2 192:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="nexium" 192:4 192:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="pain medication" 194:15 195:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="celebrex" 195:9 195:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="lidoderm patch" 195:12 195:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="msir" 195:2 195:2
do="nm"
mo="nm"
f="every 4 hr as needed" 195:3 195:7
du="nm"
r="pain" 194:15 194:15
ln="narrative"
