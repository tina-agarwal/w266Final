1:
m="asa ( acetylsalicylic acid )" 14:0 14:4
do="81 mg" 14:5 14:6
mo="po" 14:7 14:7
f="qd" 14:8 14:8
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 17:3 17:3
do="nm"
mo="po" 17:4 17:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 18:3 18:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 18:5 18:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="allopurinol" 20:0 20:0
do="300 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
6:
m="digoxin" 21:0 21:0
do="0.25 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
7:
m="folic acid" 22:0 22:1
do="1 mg" 22:2 22:3
mo="po" 22:4 22:4
f="qd" 22:5 22:5
du="nm"
r="nm"
ln="list"
8:
m="lasix ( furosemide )" 23:0 23:3
do="80 mg" 23:4 23:5
mo="po" 23:6 23:6
f="bid" 23:7 23:7
du="nm"
r="nm"
ln="list"
9:
m="ativan ( lorazepam )" 24:0 24:3
do="1 mg" 24:4 24:5
mo="po" 24:6 24:6
f="bid prn" 24:7 24:8
du="nm"
r="anxiety" 24:9 24:9
ln="list"
10:
m="ativan ( lorazepam )" 24:0 24:3
do="1 mg" 24:4 24:5
mo="po" 24:6 24:6
f="bid prn" 24:7 24:8
du="nm"
r="insomnia" 24:11 24:11
ln="list"
11:
m="lopressor ( metoprolol tartrate )" 25:0 25:4
do="12.5 mg" 25:5 25:6
mo="po" 25:7 25:7
f="bid" 25:8 25:8
du="nm"
r="nm"
ln="list"
12:
m="thiamine ( thiamine hcl )" 28:0 28:4
do="100 mg" 28:5 28:6
mo="po" 28:7 28:7
f="qd" 28:8 28:8
du="nm"
r="nm"
ln="list"
13:
m="coumadin ( warfarin sodium )" 29:0 29:4
do="5 mg" 29:5 29:6
mo="po" 29:7 29:7
f="qhs" 29:8 29:8
du="nm"
r="nm"
ln="list"
14:
m="aspirin" 34:3 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="warfarin" 34:5 34:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="simvastatin" 35:3 35:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="warfarin" 35:5 35:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="levofloxacin" 36:3 36:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="warfarin" 36:5 36:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="insulin 70/30 ( human )" 38:0 38:4
do="30 units" 38:5 38:6
mo="sc" 38:7 38:7
f="bid" 38:8 38:8
du="number of doses required ( approximate ): 10" 39:0 39:7
r="nm"
ln="list"
21:
m="imdur ( isosorbide mononit.( sr ) )" 40:0 40:6
do="60 mg" 40:7 40:8
mo="po" 40:9 40:9
f="qd" 40:10 40:10
du="nm"
r="nm"
ln="list"
22:
m="kcl slow rel." 44:0 44:2
do="20 meq" 44:3 44:4
mo="po" 44:7 44:7
f="bid" 44:8 44:8
du="x 1" 44:5 44:6
r="nm"
ln="list"
23:
m="allegra ( fexofenadine hcl )" 47:0 47:4
do="60 mg" 47:5 47:6
mo="po" 47:7 47:7
f="qd" 47:8 47:8
du="nm"
r="nm"
ln="list"
24:
m="levofloxacin" 50:0 50:0
do="250 mg" 50:1 50:2
mo="po" 50:3 50:3
f="qd" 50:4 50:4
du="nm"
r="nm"
ln="list"
25:
m="coumadin" 56:3 56:3
do="nm"
mo="po" 56:4 56:4
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="levofloxacin" 57:3 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="warfarin" 57:5 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="avapro ( irbesartan )" 59:0 59:3
do="300 mg" 59:4 59:5
mo="po" 59:6 59:6
f="qd" 59:7 59:7
du="number of doses required ( approximate ): 5" 60:0 60:7
r="nm"
ln="list"
29:
m="lipitor ( atorvastatin )" 61:0 61:3
do="20 mg" 61:4 61:5
mo="po" 61:6 61:6
f="qd" 61:7 61:7
du="nm"
r="nm"
ln="list"
30:
m="atorvastatin calcium" 63:5 64:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 63:3 63:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="coumadin" 89:3 89:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib dx" 88:6 88:7
ln="narrative"
33:
m="lasix" 92:6 92:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="rocephin" 92:8 92:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="bibasilar infiltrates" 93:0 93:1
ln="narrative"
35:
m="o2" 95:7 95:7
do="nm"
mo="fm" 95:6 95:6
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="levofloxacin" 97:2 97:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="?comm acq pna" 97:6 98:0
ln="narrative"
37:
m="diuretics" 106:3 106:3
do="nm"
mo="po" 106:2 106:2
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="levoflox." 106:9 106:9
do="nm"
mo="nm"
f="nm"
du="14 day course" 106:5 106:7
r="nm"
ln="narrative"
