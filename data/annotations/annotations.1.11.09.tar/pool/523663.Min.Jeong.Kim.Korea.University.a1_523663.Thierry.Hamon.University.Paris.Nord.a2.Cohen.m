1:
m="amiodarone" 37:1 37:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="atrovent" 37:7 37:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="colchicine" 37:5 37:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="digoxin" 37:3 37:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lisinopril" 37:9 37:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="ativan" 38:4 38:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="prilosec." 38:9 38:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="spironolactone" 38:0 38:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="torsemide" 38:2 38:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="zocor" 38:6 38:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lasix" 65:12 65:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="torsemide." 66:1 66:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="ace inhibitor" 73:5 73:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="baby aspirin" 73:10 74:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="statin" 73:8 73:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="torsemide" 74:10 74:10
do="100 mg" 75:0 75:1
mo="nm"
f="daily" 75:2 75:2
du="nm"
r="nm"
ln="narrative"
17:
m="spironolactone" 75:7 75:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="atrovent nebulizers" 76:5 76:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="shortness of breath." 77:4 77:6
ln="narrative"
19:
m="dopamine" 80:3 80:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="his diuresis" 79:1 79:2
ln="narrative"
20:
m="lasix" 80:8 80:8
do="nm"
mo="drips" 80:9 80:9
f="nm"
du="nm"
r="his diuresis" 79:1 79:2
ln="narrative"
21:
m="nesiritide" 80:5 80:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="his diuresis" 79:1 79:2
ln="narrative"
22:
m="dopamine." 81:7 81:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="nesiritide" 81:5 81:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="oxygen" 84:3 84:3
do="nm"
mo="nm"
f="nm"
du="overnight" 84:6 84:6
r="nm"
ln="narrative"
25:
m="colchicine" 89:6 89:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="colchicine" 91:8 91:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lovenox" 106:0 106:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt prophylaxis" 105:7 105:8
ln="list"
28:
m="amiodarone" 119:1 119:1
do="300 mg" 119:2 119:3
mo="nm"
f="daily." 119:4 119:4
du="nm"
r="nm"
ln="list"
29:
m="colchicine" 120:1 120:1
do="0.6 mg" 120:2 120:3
mo="nm"
f="every other day." 120:4 120:6
du="nm"
r="nm"
ln="list"
30:
m="digoxin" 121:1 121:1
do="0.125 mg" 121:2 121:3
mo="nm"
f="every other day." 121:4 121:6
du="nm"
r="nm"
ln="list"
31:
m="ferrous sulfate" 122:1 122:2
do="325 mg" 122:3 122:4
mo="nm"
f="daily" 122:5 122:5
du="nm"
r="nm"
ln="list"
32:
m="lisinopril" 123:1 123:1
do="5 mg" 123:2 123:3
mo="nm"
f="daily." 123:4 123:4
du="nm"
r="nm"
ln="list"
33:
m="ativan" 124:1 124:1
do="0.5 mg" 124:2 124:3
mo="nm"
f="b.i.d." 124:4 124:4
du="nm"
r="nm"
ln="list"
34:
m="spironolactone" 125:1 125:1
do="12.5 mg" 125:2 125:3
mo="nm"
f="daily." 125:4 125:4
du="nm"
r="nm"
ln="list"
35:
m="trazodone" 126:1 126:1
do="50 mg" 126:2 126:3
mo="nm"
f="at night" 126:4 126:5
du="nm"
r="nm"
ln="list"
36:
m="multivitamins" 127:1 127:1
do="one tablet" 127:2 127:3
mo="nm"
f="daily." 127:4 127:4
du="nm"
r="nm"
ln="list"
37:
m="torsemide" 128:1 128:1
do="100 mg" 128:2 128:3
mo="nm"
f="daily." 128:4 128:4
du="nm"
r="nm"
ln="list"
38:
m="prilosec" 129:1 129:1
do="20 mg" 129:2 129:3
mo="nm"
f="b.i.d." 129:4 129:4
du="nm"
r="nm"
ln="list"
39:
m="simvastatin" 130:1 130:1
do="80 mg" 130:2 130:3
mo="nm"
f="at night." 130:4 130:5
du="nm"
r="nm"
ln="list"
