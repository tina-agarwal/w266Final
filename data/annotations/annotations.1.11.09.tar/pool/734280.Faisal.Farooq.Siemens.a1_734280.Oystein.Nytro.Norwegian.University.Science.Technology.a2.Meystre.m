1:
m="ecasa ( aspirin enteric coated )" 14:0 14:5
do="81 mg" 14:6 14:7
mo="po " 14:8 14:8
f="qd " 14:9 14:9
du="nm"
r="nm"
ln="list"
2:
m="aspirin" 17:5 17:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="warfarin" 17:3 17:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="colace ( docusate sodium )" 19:0 19:4
do="100 mg" 19:5 19:6
mo="po" 19:7 19:7
f="bid" 19:8 19:8
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 20:0 20:3
do="160 mg" 20:4 20:5
mo="po" 20:6 20:6
f="bid" 20:7 20:7
du="nm"
r="nm"
ln="list"
6:
m="glipizide" 21:0 21:0
do="10 mg" 21:1 21:2
mo="po" 21:3 21:3
f="bid" 21:4 21:4
du="nm"
r="nm"
ln="list"
7:
m="ocean spray ( sodium chloride 0.65% )" 22:0 22:6
do="2 spray" 22:7 22:8
mo="na" 22:9 22:9
f="qid prn" 22:10 23:0
du="nm"
r="other:dried nasal mucosa" 23:1 23:3
ln="list"
8:
m="coumadin ( warfarin sodium )" 24:0 24:4
do="5 mg" 24:5 24:6
mo="po" 24:7 24:7
f="qpm" 24:8 24:8
du="nm"
r="nm"
ln="list"
9:
m="ecasa" 29:8 29:8
do="nm"
mo="po " 29:9 29:9
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="aspirin" 30:5 30:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="warfarin" 30:3 30:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="zoloft ( sertraline )" 32:0 32:3
do="150 mg" 32:4 32:5
mo="po" 32:6 32:6
f="qd" 32:7 32:7
du="nm"
r="nm"
ln="list"
13:
m="ambien ( zolpidem tartrate )" 33:0 33:4
do="10 mg" 33:5 33:6
mo="po" 33:7 33:7
f="qhs" 33:8 33:8
du="nm"
r="nm"
ln="list"
14:
m="kcl slow release" 37:0 37:2
do="20 meq" 37:3 37:4
mo="po" 37:5 37:5
f="bid" 37:6 37:6
du="nm"
r="nm"
ln="list"
15:
m="atrovent nasal 0.06% ( ipratropium nasal 0.06% )" 40:0 40:7
do="2 spray" 41:0 41:1
mo="na" 41:2 41:2
f="tid" 41:3 41:3
du="number of doses required (approximate):10" 42:0 42:7
r="nm"
ln="list"
16:
m="nexium ( esomeprazole )" 43:0 43:3
do="20 mg" 43:4 43:5
mo="po" 43:6 43:6
f="qd" 43:7 43:7
du="nm"
r="nm"
ln="list"
17:
m="tracleer ( bosentan )" 44:0 44:3
do="125 mg" 44:4 44:5
mo="po" 44:6 44:6
f="bid" 44:7 44:7
du="number of doses required (approximate):10" 45:0 45:7
r="nm"
ln="list"
18:
m="ventavis" 46:0 46:0
do="1 neb" 46:1 46:2
mo="neb" 46:3 46:3
f="q3h" 46:4 46:4
du="during wake hours" 46:6 46:8
r="nm"
ln="list"
19:
m="albuterol inhaler" 47:0 47:1
do="2 puff" 47:2 47:3
mo="inh" 47:4 47:4
f="q4h prn" 47:5 48:0
du="nm"
r="shortness of breath" 48:1 48:3
ln="list"
20:
m="albuterol inhaler" 47:0 47:1
do="2 puff" 47:2 47:3
mo="inh" 47:4 47:4
f="q4h prn" 47:5 48:0
du="nm"
r="wheezing" 48:5 48:5
ln="list"
21:
m="o2" 72:1 72:1
do="8l" 72:3 72:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="acei" 86:8 86:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="cephalopsporins" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="k-dur" 88:1 88:1
do="20" 88:2 88:2
mo="nm"
f="bid " 88:3 88:3
du="nm"
r="nm"
ln="list"
25:
m="lasix" 88:8 88:8
do="160" 88:9 88:9
mo="nm"
f="bid" 88:10 88:10
du="nm"
r="nm"
ln="list"
26:
m="nexium" 88:5 88:5
do="20" 88:6 88:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="coumadin" 89:8 89:8
do="5/7.5" 89:9 89:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="ecasa" 89:11 89:11
do="81" 89:12 89:12
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="glipizide" 89:4 89:4
do="80" 89:5 89:5
mo="nm"
f="bid" 89:6 89:6
du="nm"
r="nm"
ln="list"
30:
m="tracleer" 89:0 89:0
do="125" 89:1 89:1
mo="nm"
f="bid" 89:2 89:2
du="nm"
r="nm"
ln="list"
31:
m="zoloft" 89:14 89:14
do="100" 90:0 90:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="ambien" 90:6 90:6
do="10" 90:7 90:7
mo="nm"
f="qhs" 90:8 90:8
du="nm"
r="nm"
ln="list"
33:
m="mvi" 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="oceanspray" 90:4 90:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="ventavis" 90:10 90:10
do="nm"
mo="nebs" 90:11 90:11
f="q3h" 91:0 91:0
du="nm"
r="nm"
ln="list"
36:
m="o2" 99:11 99:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="tracleer" 99:13 99:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="albuterol." 100:0 100:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="asa" 103:7 103:7
do="81" 103:8 103:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="kcl" 103:5 103:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="lasix" 103:3 103:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="ambien." 104:10 104:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression." 104:3 104:3
ln="narrative"
43:
m="zoloft" 104:8 104:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression." 104:3 104:3
ln="narrative"
44:
m="coumadin" 106:2 106:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary microclots" 106:4 106:5
ln="narrative"
45:
m="coumadin" 107:3 107:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="nexium" 112:4 112:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="gerd" 112:2 112:2
ln="narrative"
