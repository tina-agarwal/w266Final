1:
m="opium tincture" 26:8 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
2:
m="aspirin" 27:2 27:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="ditropan" 27:8 27:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="lasix" 27:6 27:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lomotil" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="atapryl" 28:4 28:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="iron" 28:7 28:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lopid" 28:0 28:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="zocor" 28:2 28:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="albuterol" 49:6 49:6
do="nm"
mo="nebulizer" 49:3 49:3
f="occasional" 49:2 49:2
du="nm"
r="wheezes" 47:8 47:8
ln="narrative"
11:
m="atrovent" 50:0 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="losartan" 53:2 53:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="outpatient medications" 54:6 54:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="flagyl" 66:4 66:4
do="nm"
mo="nm"
f="nm"
du="a 7-day course" 65:8 66:0
r="empiric abdominal coverage" 66:6 66:8
ln="narrative"
15:
m="levofloxacin" 66:2 66:2
do="nm"
mo="nm"
f="nm"
du="a 7-day course" 65:8 66:0
r="empiric abdominal coverage." 66:6 66:8
ln="narrative"
16:
m="antibiotics" 67:9 67:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="kaopectate" 71:7 71:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="explosive diarrhea" 70:3 70:4
ln="narrative"
18:
m="kaopectate" 71:7 71:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="guaiac positive brown stool." 70:6 71:0
ln="narrative"
19:
m="lomotil" 71:9 71:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="explosive diarrhea" 70:3 70:4
ln="narrative"
20:
m="lomotil" 71:9 71:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="guaiac positive brown stool." 70:6 71:0
ln="narrative"
21:
m="nexium" 82:10 82:10
do="40" 82:11 82:11
mo="nm"
f="b.i.d." 83:0 83:0
du="nm"
r="grade iv gastritis" 81:5 82:0
ln="narrative"
