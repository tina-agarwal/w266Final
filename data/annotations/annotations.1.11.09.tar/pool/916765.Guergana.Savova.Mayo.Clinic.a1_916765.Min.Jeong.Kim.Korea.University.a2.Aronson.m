1:
m="aspirin" 23:11 23:11
do="nm"
mo="nm"
f="once a day" 24:0 24:2
du="nm"
r="nm"
ln="list"
2:
m="toprol xl" 23:4 23:5
do="50" 23:6 23:6
mo="nm"
f="once a day" 23:7 23:9
du="nm"
r="nm"
ln="list"
3:
m="nitroglycerin" 24:5 24:5
do="nm"
mo="sublingual" 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="zocor" 24:7 24:7
do="50" 24:8 24:8
mo="nm"
f="once a day" 25:0 25:2
du="nm"
r="nm"
ln="list"
5:
m="lasix" 38:12 38:12
do="40 mg" 38:13 38:14
mo="nm"
f="once a day" 39:0 39:2
du="for two days" 39:3 39:5
r="nm"
ln="list"
6:
m="lopressor" 38:5 38:5
do="50 mg" 38:6 38:7
mo="nm"
f="twice a day" 38:8 38:10
du="nm"
r="nm"
ln="list"
7:
m="k-dur tabs" 39:9 39:10
do="10 meq" 39:11 39:12
mo="nm"
f="once a day" 39:13 40:0
du="for two days" 40:1 40:3
r="nm"
ln="list"
8:
m="potassium" 39:7 39:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="coumadin" 40:7 40:7
do="5 mg one tab" 40:8 40:11
mo="nm"
f="once a day" 40:12 40:14
du="nm"
r="nm"
ln="list"
10:
m="lasix" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="coumadin" 41:2 41:2
do="nm"
mo="nm"
f="nm"
du="for a total of three months" 43:0 43:5
r="right leg dvt" 41:7 41:9
ln="list"
12:
m="percocet" 43:6 43:6
do="one tab" 43:8 43:9
mo="nm"
f="q.4h. prn" 43:10 43:11
du="nm"
r="pain" 44:0 44:0
ln="list"
