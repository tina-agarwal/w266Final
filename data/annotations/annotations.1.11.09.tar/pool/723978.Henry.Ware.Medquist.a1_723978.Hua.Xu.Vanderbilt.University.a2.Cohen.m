1:
m="amiodarone" 16:0 16:0
do="200 mg" 16:1 16:2
mo="po" 16:3 16:3
f="qd" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 19:3 19:3
do="nm"
mo="po" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="amiodarone hcl" 20:3 20:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 20:6 20:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="coumadin" 24:3 24:3
do="nm"
mo="po" 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="amiodarone hcl" 25:3 25:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 25:6 25:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="amiodarone hcl" 29:5 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="levofloxacin" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="glipizide" 31:0 31:0
do="2.5 mg" 31:1 31:2
mo="po" 31:3 31:3
f="qd" 31:4 31:4
du="nm"
r="nm"
ln="list"
11:
m="glyburide" 35:4 35:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="guaifenesin" 40:0 40:0
do="10 milliliters" 40:1 40:2
mo="po" 40:3 40:3
f="q6h...prn" 40:4 40:4,41:0 41:0
du="nm"
r="other:cough" 41:1 41:1
ln="list"
13:
m="isordil ( isosorbide dinitrate )" 42:0 42:4
do="20 mg" 42:5 42:6
mo="po" 42:7 42:7
f="tid" 42:8 42:8
du="nm"
r="nm"
ln="list"
14:
m="sarna" 44:0 44:0
do="nm"
mo="topical tp" 44:1 44:2
f="qd" 44:3 44:3
du="nm"
r="nm"
ln="list"
15:
m="coumadin ( warfarin sodium )" 45:0 45:4
do="2.5 mg" 45:5 45:6
mo="po" 45:7 45:7
f="qod" 45:8 45:8
du="nm"
r="nm"
ln="list"
16:
m="coumadin ( warfarin sodium )" 45:0 45:4
do="5mg" 47:3 47:3
mo="po" 45:7 45:7
f="qod" 47:4 47:4
du="nm"
r="nm"
ln="list"
17:
m="levofloxacin" 52:3 52:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="warfarin" 52:5 52:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="levofloxacin" 53:3 53:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="warfarin" 53:5 53:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="amiodarone hcl" 54:3 54:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="warfarin" 54:6 54:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="hydrocortisone 1% -topical cream" 56:0 56:3
do="nm"
mo="tp" 56:4 56:4
f="bid" 56:5 56:5
du="nm"
r="r elbow eczema" 57:2 57:4
ln="list"
24:
m="levofloxacin" 58:0 58:0
do="250 mg" 58:1 58:2
mo="po" 58:3 58:3
f="qd" 58:4 58:4
du="nm"
r="nm"
ln="list"
25:
m="iron products" 60:1 60:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="ciprofloxacin" 61:4 61:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="levofloxacin" 61:2 61:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="coumadin" 66:3 66:3
do="nm"
mo="po" 66:4 66:4
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="levofloxacin" 67:3 67:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="warfarin" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="levofloxacin" 68:3 68:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="warfarin" 68:5 68:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="coumadin" 72:3 72:3
do="nm"
mo="po" 72:4 72:4
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levofloxacin" 73:3 73:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="warfarin" 73:5 73:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="levofloxacin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 74:5 74:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="amiodarone" 78:3 78:3
do="nm"
mo="po" 78:4 78:4
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="amiodarone hcl" 79:5 80:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="levofloxacin" 79:3 79:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="nizoral 2% shampoo ( ketoconazole 2% shampoo ) topical" 81:0 82:0
do="nm"
mo="topical tp" 82:0 82:1
f="tiweek" 82:2 82:2
du="nm"
r="nm"
ln="list"
42:
m="synalar 0.025% cream ( fluocinolone 0.025% cream ) topical" 83:0 84:0
do="nm"
mo="topical tp" 84:0 84:1
f="bid" 84:2 84:2
du="nm"
r="nm"
ln="list"
43:
m="plaquenil ( hydroxychloroquine )" 86:0 86:3
do="200 mg" 86:4 86:5
mo="po" 86:6 86:6
f="bid" 86:7 86:7
du="nm"
r="nm"
ln="list"
44:
m="norvasc ( amlodipine )" 88:0 88:3
do="10 mg" 88:4 88:5
mo="po" 88:6 88:6
f="qd" 88:7 88:7
du="nm"
r="nm"
ln="list"
45:
m="coumadin" 148:4 148:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="afib" 148:1 148:1
ln="narrative"
46:
m="htn meds" 191:4 191:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="antibiotics" 194:1 194:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="colchicine" 201:4 201:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="lasix" 201:0 201:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lisinopril" 201:2 201:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="ivf" 202:7 202:7
do="approximately 1l" 202:9 202:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="colchicine" 205:4 205:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="lasix" 205:0 205:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="lisinopril" 205:2 205:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="tylenol" 211:10 211:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 211:7 211:7
ln="narrative"
56:
m="levofloxacin" 215:6 215:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="levofloxacin" 216:2 216:2
do="nm"
mo="nm"
f="nm"
du="2 days" 215:12 216:0
r="nm"
ln="narrative"
58:
m="glipizide" 218:8 218:8
do="2.5mg" 218:9 218:9
mo="nm"
f="qd" 218:10 218:10
du="nm"
r="nm"
ln="narrative"
59:
m="micronase" 218:6 218:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="levo" 224:5 224:5
do="nm"
mo="nm"
f="nm"
du="6 more days" 224:1 224:3
r="nm"
ln="narrative"
61:
m="diabetes medication" 228:1 228:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="glipizide" 228:6 228:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="colchicine" 229:8 229:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="lasix" 229:4 229:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="lisinopril" 229:6 229:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="micronase" 229:2 229:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="levofloxacin" 240:9 240:9
do="nm"
mo="nm"
f="nm"
du="6 more days" 240:5 240:7
r="nm"
ln="narrative"
