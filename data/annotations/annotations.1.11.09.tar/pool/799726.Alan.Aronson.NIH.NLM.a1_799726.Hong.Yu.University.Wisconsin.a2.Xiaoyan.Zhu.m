1:
m="coumadin" 19:10 19:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="peripheral vascular disease" 20:0 20:2
ln="narrative"
2:
m="aspirin" 44:5 44:5
do="325 mg" 44:6 44:7
mo="nm"
f="daily" 44:8 44:8
du="nm"
r="nm"
ln="list"
3:
m="colace" 44:10 44:10
do="100 mg" 44:11 44:12
mo="nm"
f="b.i.d." 45:0 45:0
du="nm"
r="nm"
ln="list"
4:
m="lopressor" 44:0 44:0
do="37.5 mg" 44:1 44:2
mo="nm"
f="b.i.d." 44:3 44:3
du="nm"
r="nm"
ln="list"
5:
m="insulin" 45:8 45:8
do="sliding scale" 45:9 45:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="pepcid" 45:2 45:2
do="20 mg" 45:3 45:4
mo="iv" 45:5 45:5
f="q.12h." 45:6 45:6
du="nm"
r="nm"
ln="list"
7:
m="atorvastatin" 46:0 46:0
do="80 mg" 46:1 46:2
mo="nm"
f="daily" 46:3 46:3
du="nm"
r="nm"
ln="list"
8:
m="avandia" 46:7 46:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="glipizide" 46:5 46:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="metformin" 46:11 46:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="zestril" 46:9 46:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="lactulose" 47:2 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="meclizine" 47:0 47:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="neurontin" 47:11 47:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="niaspan" 47:9 47:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="protonix" 47:7 47:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="vitamin c" 47:4 47:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="coumadin" 48:2 48:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="peripheral vascular disease." 48:4 48:6
ln="list"
19:
m="zincate" 48:0 48:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="glipizide" 82:3 82:3
do="5 mg" 82:4 82:5
mo="oral" 82:0 82:0
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="novolog" 82:11 82:11
do="sliding scale." 83:0 83:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="packed red blood cells" 83:9 84:1
do="3 units" 83:6 83:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="coumadin" 84:8 84:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his peripheral vascular disease." 84:10 85:2
ln="narrative"
24:
m="flomax" 92:5 92:5
do="0.4 mg" 92:6 92:7
mo="nm"
f="once a day." 92:8 92:10
du="nm"
r="some urinary retention" 91:0 91:2
ln="narrative"
25:
m="flomax" 95:2 95:2
do="nm"
mo="nm"
f="nm"
du="until that time" 95:3 95:5
r="nm"
ln="narrative"
26:
m="colace" 104:6 104:6
do="100 mg" 104:7 104:8
mo="nm"
f="b.i.d." 104:9 104:9
du="nm"
r="nm"
ln="list"
27:
m="enteric-coated aspirin" 104:0 104:1
do="81 mg" 104:2 104:3
mo="nm"
f="qd" 104:4 104:4
du="nm"
r="nm"
ln="list"
28:
m="dilaudid" 105:2 105:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="glipizide" 105:11 105:11
do="5 mg" 105:12 105:13
mo="nm"
f="daily" 106:0 106:0
du="nm"
r="nm"
ln="list"
30:
m="lasix" 105:4 105:4
do="40 mg" 105:5 105:6
mo="nm"
f="qd" 105:7 105:7
du="x3 doses" 105:8 105:9
r="nm"
ln="list"
31:
m="dilaudid" 106:2 106:2
do="2-4 mg" 106:3 106:4
mo="nm"
f="every three hours p.r.n." 106:5 106:8
du="nm"
r="pain" 106:9 106:9
ln="list"
32:
m="lisinopril" 106:11 106:11
do="2.5 mg" 107:0 107:1
mo="nm"
f="daily" 107:2 107:2
du="nm"
r="nm"
ln="list"
33:
m="niferex" 107:4 107:4
do="150 mg" 107:5 107:6
mo="nm"
f="b.i.d." 107:7 107:7
du="nm"
r="nm"
ln="list"
34:
m="toprol-xl" 107:9 107:9
do="150 mg" 107:10 107:11
mo="nm"
f="qd" 107:12 107:12
du="nm"
r="nm"
ln="list"
35:
m="flomax" 108:5 108:5
do="0.4 mg" 108:6 108:7
mo="nm"
f="qd" 108:8 108:8
du="nm"
r="nm"
ln="list"
36:
m="lipitor" 108:0 108:0
do="80 mg" 108:1 108:2
mo="nm"
f="daily" 108:3 108:3
du="nm"
r="nm"
ln="list"
37:
m="potassium chloride slow release" 108:10 109:0
do="10 meq" 109:1 109:2
mo="nm"
f="qd" 109:3 109:3
du="x3 doses" 109:4 109:5
r="nm"
ln="list"
38:
m="coumadin" 109:9 109:9
do="nm"
mo="nm"
f="qd per inr result" 109:10 109:13
du="nm"
r="nm"
ln="list"
39:
m="lasix" 109:7 109:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="coumadin" 110:6 110:6
do="4 mg" 110:3 110:4
mo="nm"
f="this evening" 110:7 110:8
du="nm"
r="his peripheral vascular disease." 110:10 111:2
ln="list"
41:
m="coumadin" 111:4 111:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
