1:
m="digoxin" 16:0 16:0
do="0.25 mg" 16:1 16:2
mo="po" 16:3 16:3
f="daily" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="lasix ( furosemide )" 17:0 17:3
do="20 mg" 17:4 17:5
mo="po" 17:6 17:6
f="every other day" 17:7 17:9
du="nm"
r="nm"
ln="list"
3:
m="glyburide" 18:0 18:0
do="10 mg" 18:1 18:2
mo="po" 18:3 18:3
f="bid" 18:4 18:4
du="nm"
r="nm"
ln="list"
4:
m="isordil ( isosorbide dinitrate )" 19:0 19:4
do="20 mg" 19:5 19:6
mo="po" 19:7 19:7
f="tid" 19:8 19:8
du="nm"
r="nm"
ln="list"
5:
m="dilantin ( phenytoin )" 20:0 20:3
do="200 mg" 20:4 20:5
mo="nm"
f="qam;" 20:6 20:6
du="nm"
r="nm"
ln="list"
6:
m="dilantin ( phenytoin )" 20:0 20:3
do="200 mg" 21:0 21:1
mo="nm"
f="qam" 21:2 21:2
du="nm"
r="nm"
ln="list"
7:
m="dilantin ( phenytoin )" 20:0 20:3
do="200mg" 22:3 22:3
mo="nm"
f="every afternoon" 22:4 22:5
du="nm"
r="nm"
ln="list"
8:
m="dilantin ( phenytoin )" 20:0 20:3
do="250 mg" 20:7 20:8
mo="po" 20:10 20:10
f="qpm" 20:9 20:9
du="nm"
r="nm"
ln="list"
9:
m="dilantin ( phenytoin )" 20:0 20:3
do="250 mg" 20:7 20:8
mo="po" 20:10 20:10
f="qpm...bedtime" 20:9 20:11
du="nm"
r="nm"
ln="list"
10:
m="dilantin ( phenytoin )" 20:0 20:3
do="250 mg" 21:3 21:4
mo="nm"
f="qpm" 21:5 21:5
du="nm"
r="nm"
ln="list"
11:
m="toprol xl ( metoprolol succinate extended release )" 26:0 26:7
do="100 mg" 27:0 27:1
mo="po" 27:2 27:2
f="daily" 27:3 27:3
du="nm"
r="nm"
ln="list"
12:
m="neurontin ( gabapentin )" 30:0 30:3
do="300 mg" 30:4 30:5
mo="po" 30:6 30:6
f="tid" 30:7 30:7
du="nm"
r="nm"
ln="list"
13:
m="plavix ( clopidogrel )" 31:0 31:3
do="75 mg" 31:4 31:5
mo="po" 31:6 31:6
f="daily" 31:7 31:7
du="nm"
r="nm"
ln="list"
14:
m="benazepril" 32:0 32:0
do="10 mg" 32:1 32:2
mo="po" 32:3 32:3
f="daily" 32:4 32:4
du="nm"
r="nm"
ln="list"
15:
m="glucophage ( metformin )" 33:0 33:3
do="850 mg" 33:4 33:5
mo="po" 33:6 33:6
f="tid" 33:7 33:7
du="nm"
r="nm"
ln="list"
16:
m="celontin ( methsuximide )" 35:0 35:3
do="300 mg" 35:4 35:5
mo="po" 35:6 35:6
f="tid" 35:7 35:7
du="nm"
r="nm"
ln="list"
17:
m="dilantin300/300/250" 63:1 63:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="glyburide" 63:3 63:3
do="10" 63:4 63:4
mo="nm"
f="bid" 63:5 63:5
du="nm"
r="nm"
ln="list"
19:
m="metformin" 63:7 63:7
do="850" 64:0 64:0
mo="nm"
f="tid" 64:1 64:1
du="nm"
r="nm"
ln="list"
20:
m="asa" 64:7 64:7
do="325" 64:8 64:8
mo="nm"
f="daily" 64:9 64:9
du="nm"
r="nm"
ln="list"
21:
m="isordil" 64:11 64:11
do="20tid" 64:12 64:12
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="lasix" 64:14 64:14
do="20" 64:15 64:15
mo="nm"
f="qod" 65:0 65:0
du="nm"
r="nm"
ln="list"
23:
m="toprol" 64:3 64:3
do="100" 64:4 64:4
mo="nm"
f="daily" 64:5 64:5
du="nm"
r="nm"
ln="list"
24:
m="celondin" 65:8 65:8
do="300" 65:9 65:9
mo="nm"
f="tid" 65:10 65:10
du="nm"
r="nm"
ln="list"
25:
m="digoxin" 65:12 65:12
do="0.25" 65:13 65:13
mo="nm"
f="daily" 66:0 66:0
du="nm"
r="nm"
ln="list"
26:
m="lipitor" 65:2 65:2
do="40" 65:3 65:3
mo="nm"
f="daily" 65:4 65:4
du="nm"
r="nm"
ln="list"
27:
m="neurontin" 65:6 65:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="benazepril" 66:2 66:2
do="10" 66:3 66:3
mo="nm"
f="daily." 66:4 66:4
du="nm"
r="nm"
ln="list"
29:
m="asa" 72:8 72:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="isordil" 73:11 73:11
do="20" 73:12 73:12
mo="nm"
f="tid" 74:0 74:0
du="nm"
r="nm"
ln="list"
31:
m="plavix" 73:2 73:2
do="75" 73:3 73:3
mo="nm"
f="daily." 73:4 73:4
du="nm"
r="nm"
ln="list"
32:
m="toprol" 73:7 73:7
do="100" 73:8 73:8
mo="nm"
f="daily" 73:9 73:9
du="nm"
r="nm"
ln="list"
33:
m="atorva" 74:4 74:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="benazepril" 74:11 74:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="lasix" 74:1 74:1
do="20" 74:2 74:2
mo="nm"
f="qod." 74:3 74:3
du="nm"
r="nm"
ln="list"
36:
m="simva" 74:7 74:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="digoxin" 75:3 75:3
do="0.25" 76:0 76:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="lisinopril" 75:0 75:0
do="10" 75:1 75:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="metformin" 76:7 76:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="glyburide" 77:0 77:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="riss." 77:3 77:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="celondin-" 79:10 79:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="dilantin" 79:7 79:7
do="200/200/250" 79:8 79:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="neurontin" 79:3 79:3
do="300" 79:4 79:4
mo="nm"
f="tid" 79:5 79:5
du="nm"
r="nm"
ln="narrative"
45:
m="meds" 80:10 80:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="meds" 80:2 80:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="medications" 84:5 84:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
