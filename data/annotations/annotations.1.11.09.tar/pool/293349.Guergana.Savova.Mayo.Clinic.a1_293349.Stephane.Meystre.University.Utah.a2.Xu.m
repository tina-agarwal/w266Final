1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 19:3 19:3
do="nm"
mo="po" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="coumadin" 24:3 24:3
do="nm"
mo="po" 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="aspirin" 25:3 25:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 25:5 25:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="calcium carbonate ( 500 mg elemental ca++ )" 27:0 27:7
do="500 mg" 27:8 27:9
mo="po" 27:10 27:10
f="tid" 27:11 27:11
du="nm"
r="nm"
ln="list"
9:
m="colace ( docusate sodium )" 28:0 28:4
do="100 mg" 28:5 28:6
mo="po" 28:7 28:7
f="bid" 28:8 28:8
du="nm"
r="nm"
ln="list"
10:
m="iron sulfate ( ferrous sulfate )" 29:0 29:5
do="325 mg" 29:6 29:7
mo="po" 29:8 29:8
f="tid" 29:9 29:9
du="nm"
r="nm"
ln="list"
11:
m="folate ( folic acid )" 31:0 31:4
do="1 mg" 31:5 31:6
mo="po" 31:7 31:7
f="qd" 31:8 31:8
du="nm"
r="nm"
ln="list"
12:
m="lasix ( furosemide )" 32:0 32:3
do="80 mg" 32:4 32:5
mo="po" 32:6 32:6
f="bid" 32:7 32:7
du="nm"
r="nm"
ln="list"
13:
m="hydralazine hcl" 33:0 33:1
do="25 mg" 33:2 33:3
mo="po" 33:4 33:4
f="tid" 33:5 33:5
du="nm"
r="nm"
ln="list"
14:
m="insulin regular human" 36:0 36:2
do="0 units" 38:9 38:10
mo="subcutaneously" 38:11 38:11
f="nm"
du="nm"
r="bs" 38:1 38:1
ln="list"
15:
m="insulin regular human" 36:0 36:2
do="10 units" 44:7 44:8
mo="subcutaneously" 44:9 44:9
f="nm"
du="nm"
r="bs" 44:1 44:1
ln="list"
16:
m="insulin regular human" 36:0 36:2
do="2 units" 39:7 39:8
mo="subcutaneously" 39:9 39:9
f="nm"
du="nm"
r="bs" 39:1 39:1
ln="list"
17:
m="insulin regular human" 36:0 36:2
do="3 units" 40:7 40:8
mo="subcutaneously" 40:9 40:9
f="nm"
du="nm"
r="bs" 40:1 40:1
ln="list"
18:
m="insulin regular human" 36:0 36:2
do="4 units" 41:7 41:8
mo="subcutaneously" 41:9 41:9
f="nm"
du="nm"
r="bs" 41:1 41:1
ln="list"
19:
m="insulin regular human" 36:0 36:2
do="6 units" 42:7 42:8
mo="subcutaneously" 42:9 42:9
f="nm"
du="nm"
r="bs" 42:1 42:1
ln="list"
20:
m="insulin regular human" 36:0 36:2
do="8 units" 43:7 43:8
mo="subcutaneously" 43:9 43:9
f="nm"
du="nm"
r="bs" 43:1 43:1
ln="list"
21:
m="insulin regular human" 36:0 36:2
do="sliding scale" 37:0 37:1
mo="( subcutaneously ) sc ac" 37:2 37:6
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="isordil ( isosorbide dinitrate )" 46:0 46:4
do="20 mg" 46:5 46:6
mo="po" 46:7 46:7
f="tid" 46:8 46:8
du="nm"
r="nm"
ln="list"
23:
m="lopressor ( metoprolol tartrate )" 48:0 48:4
do="12.5 mg" 48:5 48:6
mo="po" 48:7 48:7
f="tid" 48:8 48:8
du="nm"
r="nm"
ln="list"
24:
m="dilantin ( phenytoin )" 52:0 52:3
do="100 mg" 52:4 52:5
mo="po" 52:6 52:6
f="qid" 52:7 52:7
du="nm"
r="nm"
ln="list"
25:
m="coumadin" 58:3 58:3
do="nm"
mo="po" 58:4 58:4
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="phenytoin" 59:3 59:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="warfarin" 59:5 59:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="coumadin" 63:3 63:3
do="nm"
mo="po" 63:4 63:4
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="phenytoin" 64:3 64:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="warfarin" 64:5 64:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="prednisone" 66:0 66:0
do="10 mg" 66:1 66:2
mo="po" 66:3 66:3
f="qam" 66:4 66:4
du="nm"
r="nm"
ln="list"
32:
m="sodium bicarbonate" 67:0 67:1
do="325 mg" 67:2 67:3
mo="po" 67:4 67:4
f="tid" 67:5 67:5
du="nm"
r="nm"
ln="list"
33:
m="coumadin ( warfarin sodium )" 68:0 68:4
do="5 mg" 68:5 68:6
mo="po" 68:7 68:7
f="qpm" 68:8 68:8
du="nm"
r="nm"
ln="list"
34:
m="phenytoin" 74:3 74:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="warfarin" 74:5 74:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="simvastatin" 75:3 75:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 75:5 75:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="aspirin" 76:3 76:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="warfarin" 76:5 76:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="sulfamethoxazole" 77:2 77:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="warfarin" 77:4 77:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="mvi therapeutic ( therapeutic multivitamins )" 79:0 79:5
do="1 tab" 79:6 79:7
mo="po" 79:8 79:8
f="qd" 79:9 79:9
du="nm"
r="nm"
ln="list"
43:
m="niacin" 82:5 82:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="simvastatin" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
45:
m="vit. b-3" 83:0 83:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="lovenox ( enoxaparin )" 84:0 84:3
do="50 mg" 84:4 84:5
mo="sc" 84:6 84:6
f="qd" 84:7 84:7
du="nm"
r="nm"
ln="list"
47:
m="glipizide xl" 86:0 86:1
do="2.5 mg" 86:2 86:3
mo="po" 86:4 86:4
f="qd" 86:5 86:5
du="nm"
r="nm"
ln="list"
48:
m="bactrim ds ( trimethoprim/sulfamethoxazole dou... )" 87:0 87:5
do="1 tab" 88:0 88:1
mo="po" 88:2 88:2
f="3x/week m-w-f" 88:3 88:4
du="nm"
r="nm"
ln="list"
49:
m="coumadin" 91:3 91:3
do="nm"
mo="po" 91:4 91:4
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="sulfamethoxazole" 92:2 92:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="warfarin" 92:4 92:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="sulfamethoxazole" 96:4 96:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="warfarin" 96:2 96:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
54:
m="flovent ( fluticasone propionate )" 98:0 98:4
do="220 mcg" 98:5 98:6
mo="inh" 98:7 98:7
f="bid" 98:8 98:8
du="nm"
r="nm"
ln="list"
55:
m="plavix ( clopidogrel )" 99:0 99:3
do="75 mg" 99:4 99:5
mo="po" 99:6 99:6
f="qd" 99:7 99:7
du="nm"
r="nm"
ln="list"
56:
m="esomeprazole" 100:0 100:0
do="40 mg" 100:1 100:2
mo="po" 100:3 100:3
f="qd" 100:4 100:4
du="nm"
r="nm"
ln="list"
57:
m="duoneb ( albuterol and ipratropium nebulizer )" 101:0 101:6
do="3/0.5 mg" 102:0 102:1
mo="neb" 102:2 102:2
f="q6h" 102:3 102:3
du="nm"
r="nm"
ln="list"
58:
m="darbepoetin alfa" 103:0 103:1
do="25 mcg" 103:2 103:3
mo="sc" 103:4 103:4
f="qweek" 103:5 103:5
du="nm"
r="nm"
ln="list"
59:
m="lipitor ( atorvastatin )" 109:0 109:3
do="40 mg" 109:4 109:5
mo="po" 109:6 109:6
f="qd" 109:7 109:7
du="nm"
r="nm"
ln="list"
60:
m="niacin" 111:3 111:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
61:
m="vit. b-3" 111:5 111:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
62:
m="atorvastatin calcium" 112:0 112:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
63:
m="atorvastatin calcium" 113:5 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
64:
m="warfarin" 113:3 113:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
65:
m="lasix" 146:7 146:7
do="usual dose" 146:4 146:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="lasix" 148:0 148:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="dilantin" 153:0 153:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="lasix" 170:2 170:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="lasix" 174:7 174:7
do="40" 174:8 174:8
mo="iv" 174:9 174:9
f="bid" 174:10 174:10
du="nm"
r="nm"
ln="narrative"
70:
m="lasix" 174:7 174:7
do="80" 174:13 174:13
mo="iv" 174:9 174:9
f="bid" 175:0 175:0
du="nm"
r="nm"
ln="narrative"
71:
m="lasix" 176:7 176:7
do="15/hr" 176:10 176:10
mo="drip" 176:8 176:8
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="lasix" 178:11 178:11
do="nm"
mo="po" 178:10 178:10
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="lasix" 179:1 179:1
do="80" 179:2 179:2
mo="po" 179:3 179:3
f="bid" 179:4 179:4
du="nm"
r="nm"
ln="narrative"
74:
m="hydralazine" 180:5 180:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="lopressol" 180:7 180:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
76:
m="isordil" 181:0 181:0
do="20" 181:7 181:7
mo="nm"
f="tid" 181:8 181:8
du="nm"
r="nm"
ln="narrative"
77:
m="asa" 182:5 182:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
78:
m="plavix" 182:7 182:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
79:
m="zocor" 182:9 182:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="ace inhibitor" 190:1 190:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="kayexylate" 192:11 192:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
82:
m="lasix" 192:9 192:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperkalemia" 192:3 192:3
ln="narrative"
83:
m="glipizide" 195:3 195:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
84:
m="insulin" 195:12 195:12
do="ss" 195:13 195:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
85:
m="coumadin" 198:4 198:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="history dvt" 198:6 198:7
ln="narrative"
86:
m="prbc" 200:4 200:4
do="1.5 u" 200:1 200:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
87:
m="darbopoetin" 202:0 202:0
do="25" 202:1 202:1
mo="nm"
f="qwk" 202:2 202:2
du="nm"
r="nm"
ln="narrative"
88:
m="lovenox" 203:14 203:14
do="renal dose" 203:11 203:12
mo="nm"
f="nm"
du="until her inr&gt;2." 204:0 204:2
r="a clot" 202:5 202:6
ln="narrative"
89:
m="lovenox" 204:3 204:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
90:
m="dilantin" 205:4 205:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="partial seizures" 205:8 205:9
ln="narrative"
91:
m="lasix" 209:9 209:9
do="80" 209:7 209:7
mo="po" 209:8 209:8
f="bid" 209:10 209:10
du="nm"
r="nm"
ln="narrative"
92:
m="coumadin" 211:11 211:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
93:
m="lovenox" 211:1 211:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
94:
m="o2" 217:16 217:16
do="2l" 218:0 218:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
95:
m="lovenox" 231:3 231:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
