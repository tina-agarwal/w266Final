1:
m="beta blocker" 23:7 23:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="pendalol" 23:10 23:10
do="2.5 mg" 24:3 24:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="pendalol" 23:10 23:10
do="5 mg" 24:0 24:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="amoxicillin" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="a cough" 26:5 26:6
ln="narrative"
5:
m="amoxicillin" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="low grade fevers" 26:1 26:3
ln="narrative"
6:
m="amoxicillin" 27:4 27:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="upper respiratory and pharyngeal symptoms" 25:6 25:10
ln="narrative"
7:
m="prinivil" 30:9 30:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="nitroglycerin" 36:6 36:6
do="nm"
mo="sublingual" 36:5 36:5
f="nm"
du="nm"
r="substernal chest pain" 34:3 34:5
ln="narrative"
9:
m="prinivil" 53:12 53:12
do="5 mg" 54:0 54:1
mo="p.o." 54:2 54:2
f="q. day" 54:3 54:4
du="nm"
r="nm"
ln="list"
10:
m="zocor" 53:5 53:5
do="5 mg" 53:6 53:7
mo="p.o." 53:8 53:8
f="q.h.s." 53:9 53:9
du="nm"
r="nm"
ln="list"
11:
m="pendalol" 54:7 54:7
do="2.5 mg" 54:8 54:9
mo="p.o." 55:0 55:0
f="q. day." 55:1 55:2
du="nm"
r="nm"
ln="list"
12:
m="aspirin" 55:5 55:5
do="325 mg" 55:6 55:7
mo="p.o." 55:8 55:8
f="q. day" 55:9 55:10
du="nm"
r="nm"
ln="list"
13:
m="synthroid" 55:13 55:13
do="0.100 mg" 55:14 56:0
mo="p.o." 56:1 56:1
f="q. monday , wednesday and friday" 56:2 56:7
du="nm"
r="nm"
ln="list"
14:
m="synthroid" 55:13 55:13
do="0.12 mg" 56:9 56:10
mo="p.o." 56:11 56:11
f="tuesday , thursday , saturday and sunday." 56:12 57:4
du="nm"
r="nm"
ln="list"
15:
m="pepcid" 57:7 57:7
do="nm"
mo="nm"
f="p.r.n" 57:8 57:8
du="nm"
r="nm"
ln="list"
16:
m="ace inhibitor" 97:11 98:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="nitrates." 98:7 98:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="cardiac catheterization" 98:10 99:0
ln="narrative"
18:
m="statin" 98:2 98:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="aspirin" 110:5 110:5
do="325 mg" 110:6 110:7
mo="p.o." 110:8 110:8
f="q. day" 110:9 110:10
du="nm"
r="nm"
ln="list"
20:
m="colace" 111:0 111:0
do="100 mg" 111:1 111:2
mo="p.o." 111:3 111:3
f="b.i.d." 111:4 111:4
du="nm"
r="nm"
ln="list"
21:
m="synthroid" 111:7 111:7
do="100 mcg" 112:0 112:1
mo="p.o." 112:2 112:2
f="q. monday , wednesday and friday" 112:3 112:8
du="nm"
r="nm"
ln="list"
22:
m="synthroid" 111:7 111:7
do="112 mcg" 112:10 112:11
mo="p.o." 112:12 112:12
f="q. tuesday , thursday , saturday and sunday." 112:13 113:6
du="nm"
r="nm"
ln="list"
23:
m="lisinopril" 113:9 113:9
do="10 mg" 113:10 113:11
mo="p.o." 113:12 113:12
f="q. day." 114:0 114:1
du="nm"
r="nm"
ln="list"
24:
m="beclomethasone diproprionate double strength spray" 114:4 114:8
do="nm"
mo="each nostril" 115:0 115:1
f="b.i.d." 115:2 115:2
du="nm"
r="nm"
ln="list"
25:
m="toprol xl" 115:12 115:13
do="75 mg" 115:14 116:0
mo="p.o." 116:1 116:1
f="q. day." 116:2 116:3
du="nm"
r="nm"
ln="list"
26:
m="zocor" 115:5 115:5
do="20 mg" 115:6 115:7
mo="p.o." 115:8 115:8
f="q.h.s." 115:9 115:9
du="nm"
r="nm"
ln="list"
27:
m="augmentin" 116:14 116:14
do="one tablet" 116:15 117:0
mo="p.o." 117:1 117:1
f="q. day" 117:2 117:3
du="for seven additional days." 117:4 117:7
r="nm"
ln="list"
28:
m="imdur" 116:6 116:6
do="30 mg" 116:7 116:8
mo="p.o." 116:9 116:9
f="q. day." 116:10 116:11
du="nm"
r="nm"
ln="list"
