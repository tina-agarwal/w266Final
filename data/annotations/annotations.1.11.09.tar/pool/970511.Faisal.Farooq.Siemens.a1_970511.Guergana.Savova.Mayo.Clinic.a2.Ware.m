1:
m="atenolol" 8:2 8:2
do="50" 8:3 8:3
mo="nm"
f="daily" 8:4 8:4
du="nm"
r="nm"
ln="list"
2:
m="lisinopril" 8:6 8:6
do="5" 8:7 8:7
mo="nm"
f="daily" 8:8 8:8
du="nm"
r="nm"
ln="list"
3:
m="humalog" 9:12 9:12
do="20" 10:0 10:0
mo="nm"
f="before meals" 10:1 10:2
du="nm"
r="nm"
ln="list"
4:
m="lantus" 9:8 9:8
do="60" 9:9 9:9
mo="nm"
f="daily" 9:10 9:10
du="nm"
r="nm"
ln="list"
5:
m="metformin" 9:4 9:4
do="1500" 9:5 9:5
mo="nm"
f="daily" 9:6 9:6
du="nm"
r="nm"
ln="list"
6:
m="protonix" 9:0 9:0
do="40" 9:1 9:1
mo="nm"
f="daily" 9:2 9:2
du="nm"
r="nm"
ln="list"
7:
m="byetta" 10:4 10:4
do="5 mcg" 10:5 10:6
mo="nm"
f="twice daily" 10:7 10:8
du="nm"
r="nm"
ln="list"
8:
m="levothyroxine" 10:10 10:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="oxycontin" 11:3 11:3
do="40" 11:4 11:4
mo="nm"
f="every eight hours" 11:5 11:7
du="nm"
r="nm"
ln="list"
10:
m="percocet" 11:9 11:9
do="two tabs" 11:10 11:11
mo="nm"
f="every 3 hours as needed" 11:12 12:3
du="nm"
r="pain" 12:5 12:5
ln="list"
11:
m="gabapentin" 12:7 12:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="r-chop" 16:5 16:5
do="nm"
mo="nm"
f="nm"
du="for 18 weeks." 17:2 17:4
r="non-hodgkin's lymphoma" 15:6 15:7
ln="narrative"
13:
m="normal saline" 26:8 26:9
do="nm"
mo="iv" 26:7 26:7
f="nm"
du="nm"
r="hypotensive" 26:4 26:4
ln="narrative"
14:
m="coumadin" 47:7 47:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="heparin" 47:3 47:3
do="nm"
mo="iv" 47:2 47:2
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lovenox" 48:5 48:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="long-term anticoagulation." 48:8 49:0
ln="narrative"
