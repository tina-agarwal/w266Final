1:
m="chemotherapy" 16:0 16:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="chop/rituxan." 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="cvp" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="bcnu chemotherapy" 52:10 53:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="o2." 53:7 53:7
do="5 liters" 53:4 53:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="prednisone" 57:1 57:1
do="10 mg" 57:2 57:3
mo="p.o." 57:4 57:4
f="daily." 57:5 57:5
du="nm"
r="nm"
ln="list"
7:
m="imuran" 58:1 58:1
do="100 mg" 58:2 58:3
mo="p.o." 58:4 58:4
f="q.a.m." 58:5 58:5
du="nm"
r="nm"
ln="list"
8:
m="imuran" 58:1 58:1
do="50 mg" 58:7 58:8
mo="p.o." 58:9 58:9
f="q.p.m." 58:10 58:10
du="nm"
r="nm"
ln="list"
9:
m="coumadin" 59:1 59:1
do="6 mg" 59:2 59:3
mo="p.o." 59:4 59:4
f="q.h.s." 59:5 59:5
du="nm"
r="nm"
ln="list"
10:
m="lasix" 60:1 60:1
do="60 mg" 60:2 60:3
mo="p.o." 60:4 60:4
f="daily." 60:5 60:5
du="nm"
r="nm"
ln="list"
11:
m="potassium" 61:1 61:1
do="nm"
mo="nm"
f="t.i.d." 61:2 61:2
du="nm"
r="nm"
ln="list"
12:
m="folic acid" 62:1 62:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="multivitamin" 63:1 63:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="colace" 64:1 64:1
do="100 mg" 64:2 64:3
mo="p.o." 64:4 64:4
f="b.i.d." 64:5 64:5
du="nm"
r="nm"
ln="list"
15:
m="miralax" 65:1 65:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="paxil" 66:1 66:1
do="10 mg" 66:2 66:3
mo="p.o." 66:4 66:4
f="daily." 66:5 66:5
du="nm"
r="nm"
ln="list"
17:
m="ms-contin" 67:1 67:1
do="60 mg" 67:2 67:3
mo="p.o." 67:4 67:4
f="t.i.d." 67:5 67:5
du="nm"
r="nm"
ln="list"
18:
m="flexeril" 68:1 68:1
do="one tab" 68:2 68:3
mo="p.o." 68:4 68:4
f="t.i.d." 68:5 68:5
du="nm"
r="nm"
ln="list"
19:
m="methadone" 131:6 131:6
do="5 mg" 131:7 132:0
mo="p.o." 132:1 132:1
f="t.i.d." 132:2 132:2
du="nm"
r="nm"
ln="narrative"
20:
m="pain regimen" 131:3 131:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="neurontin" 132:4 132:4
do="100 mg" 132:11 132:12
mo="p.o." 132:13 132:13
f="q.8. a.m....q. noon" 133:0 133:1,133:3 133:4
du="nm"
r="pain" 131:3 131:3
ln="narrative"
22:
m="neurontin" 132:4 132:4
do="300 mg" 132:5 132:6
mo="p.o." 132:7 132:7
f="q.h.s." 132:8 132:8
du="nm"
r="nm"
ln="narrative"
23:
m="msir" 133:6 133:6
do="15-30 mg" 133:14 133:15
mo="nm"
f="q.2h. as needed." 134:0 134:2
du="nm"
r="nm"
ln="narrative"
24:
m="msir" 133:6 133:6
do="30 mg" 133:7 133:8
mo="p.o." 133:9 133:9
f="q.h.s." 133:10 133:10
du="nm"
r="nm"
ln="narrative"
25:
m="decadron" 134:9 134:9
do="10 mg" 134:10 134:11
mo="p.o." 135:0 135:0
f="q.a.m." 135:1 135:1
du="nm"
r="spinal cord compression." 135:7 136:0
ln="narrative"
26:
m="decadron" 136:8 136:8
do="4 mg" 137:3 137:4
mo="p.o." 137:5 137:5
f="q.a.m." 137:6 137:6
du="nm"
r="nm"
ln="narrative"
27:
m="decadron" 138:7 138:7
do="2 mg" 139:0 139:1
mo="p.o." 139:2 139:2
f="q.a.m." 139:3 139:3
du="x3 doses" 139:4 139:5
r="nm"
ln="narrative"
28:
m="prednisone" 140:0 140:0
do="10 mg" 140:1 140:2
mo="p.o." 140:3 140:3
f="daily" 140:4 140:4
du="nm"
r="pulmonary disease." 140:10 141:0
ln="narrative"
29:
m="pamidronate" 141:5 141:5
do="90 mg" 141:6 141:7
mo="iv" 141:8 141:8
f="x1" 141:9 141:9
du="during this hospitalization." 141:10 142:1
r="nm"
ln="narrative"
30:
m="acyclovir" 146:0 146:0
do="200 mg" 146:1 146:2
mo="p.o." 146:3 146:3
f="five times per day" 146:4 146:7
du="a five-day course" 145:5 145:7
r="genital herpes." 147:0 147:1
ln="narrative"
31:
m="fluconazole" 148:4 148:4
do="150 mg" 148:5 148:6
mo="nm"
f="nm"
du="x1" 148:7 148:7
r="a presumed yeast infection." 149:0 149:3
ln="narrative"
32:
m="colace" 152:5 152:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="dulcolax" 152:11 152:11
do="nm"
mo="nm"
f="p.r.n." 153:0 153:0
du="nm"
r="constipation" 153:2 153:2
ln="narrative"
34:
m="miralax" 152:1 152:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="senna" 152:3 152:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="coumadin" 154:6 154:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="dvt." 155:0 155:0
ln="narrative"
37:
m="o2" 160:4 160:4
do="5 liters." 160:7 160:8
mo="nm"
f="nm"
du="nm"
r="pulmonary dysfunction" 159:10 160:0
ln="narrative"
38:
m="o2" 161:4 161:4
do="nm"
mo="nm"
f="nm"
du="throughout this hospitalization." 161:6 162:0
r="nm"
ln="narrative"
39:
m="regular insulin" 166:10 166:11
do="sliding scale" 166:7 166:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="decadron" 167:2 167:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="decadron" 168:2 168:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="tums" 171:0 171:0
do="500 mg" 171:1 171:2
mo="p.o." 171:3 171:3
f="t.i.d." 171:4 171:4
du="nm"
r="some hypocalcemia" 169:9 170:0
ln="narrative"
43:
m="pamidronate" 172:0 172:0
do="nm"
mo="nm"
f="x1" 172:1 172:1
du="nm"
r="nm"
ln="narrative"
44:
m="dulcolax" 186:10 186:10
do="5 mg" 186:11 186:12
mo="p.o." 186:13 186:13
f="daily p.r.n." 187:0 187:1
du="nm"
r="constipation" 187:3 187:3
ln="list"
45:
m="imuran" 186:0 186:0
do="100 mg" 186:1 186:2
mo="p.o." 186:3 186:3
f="q.a.m." 186:4 186:4
du="nm"
r="nm"
ln="list"
46:
m="imuran" 186:0 186:0
do="50 mg" 186:6 186:7
mo="p.o." 186:8 186:8
f="q.p.m.;" 186:9 186:9
du="nm"
r="nm"
ln="list"
47:
m="calcium carbonate" 187:4 187:5
do="500 mg" 187:6 187:7
mo="p.o." 187:8 187:8
f="t.i.d." 188:0 188:0
du="nm"
r="nm"
ln="list"
48:
m="dexamethasone" 188:6 188:6
do="2 mg" 189:3 189:4
mo="p.o." 189:5 189:5
f="daily" 189:6 189:6
du="x3 doses" 189:7 189:8
r="nm"
ln="list"
49:
m="dexamethasone" 188:6 188:6
do="4 mg" 188:7 188:8
mo="p.o." 188:9 188:9
f="daily" 188:10 188:10
du="x2 doses" 189:0 189:1
r="nm"
ln="list"
50:
m="flexeril" 188:1 188:1
do="10 mg" 188:2 188:3
mo="p.o." 188:4 188:4
f="t.i.d." 188:5 188:5
du="nm"
r="nm"
ln="list"
51:
m="prednisone" 189:11 189:11
do="10 mg" 189:12 190:0
mo="p.o." 190:1 190:1
f="daily." 190:2 190:2
du="nm"
r="nm"
ln="list"
52:
m="colace" 190:3 190:3
do="100 mg" 190:4 190:5
mo="p.o." 190:6 190:6
f="b.i.d." 190:7 190:7
du="nm"
r="nm"
ln="list"
53:
m="lasix" 190:9 190:9
do="60 mg" 190:10 190:11
mo="p.o." 190:12 190:12
f="daily" 191:0 191:0
du="nm"
r="nm"
ln="list"
54:
m="methadone" 191:7 191:7
do="5 mg" 191:8 191:9
mo="p.o." 191:10 191:10
f="t.i.d." 191:11 191:11
du="nm"
r="nm"
ln="list"
55:
m="regular insulin" 191:2 191:3
do="sliding scale" 191:4 191:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
56:
m="coumadin" 192:6 192:6
do="4.5 mg" 192:7 192:8
mo="p.o." 192:9 192:9
f="q.p.m." 192:10 192:10
du="nm"
r="nm"
ln="list"
57:
m="sennosides" 192:0 192:0
do="two tables" 192:1 192:2
mo="p.o." 192:3 192:3
f="b.i.d." 192:4 192:4
du="nm"
r="nm"
ln="list"
58:
m="msir" 193:0 193:0
do="30 mg" 193:1 193:2
mo="p.o." 193:3 193:3
f="q.h.s." 193:4 193:4
du="nm"
r="nm"
ln="list"
59:
m="msir" 193:6 193:6
do="50-30 mg" 193:7 193:8
mo="p.o." 193:9 193:9
f="q.2h. as needed" 193:10 193:12
du="nm"
r="pain" 194:0 194:0
ln="list"
60:
m="mepron" 194:8 194:8
do="750 mg" 194:9 194:10
mo="p.o." 194:11 194:11
f="b.i.d." 194:12 194:12
du="nm"
r="nm"
ln="list"
61:
m="paxil" 194:2 194:2
do="10 mg" 194:3 194:4
mo="p.o." 194:5 194:5
f="daily" 194:6 194:6
du="nm"
r="nm"
ln="list"
62:
m="neurontin" 195:0 195:0
do="300 mg" 195:1 195:2
mo="p.o." 195:3 195:3
f="q.h.s." 195:4 195:4
du="nm"
r="nm"
ln="list"
63:
m="neurontin" 195:6 195:6
do="100 mg" 195:7 195:8
mo="p.o." 195:9 195:9
f="q.8 a.m....q. noon" 195:10 195:11,196:0 196:1
du="nm"
r="nm"
ln="list"
64:
m="miralax" 196:3 196:3
do="17 g" 196:4 196:5
mo="p.o." 196:6 196:6
f="daily." 196:7 196:7
du="nm"
r="nm"
ln="list"
