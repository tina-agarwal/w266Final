1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po " 19:4 19:4
f="daily " 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="lipitor ( atorvastatin )" 20:0 20:3
do="80 mg" 20:4 20:5
mo="po" 20:6 20:6
f="bedtime" 20:7 20:7
du="nm"
r="nm"
ln="list"
3:
m="caltrate 600 + d ( calcium carbonate 1 , 500 mg ( ... )" 21:0 21:13
do="2 tab" 22:0 22:1
mo="po" 22:2 22:2
f="daily" 22:3 22:3
du="nm"
r="nm"
ln="list"
4:
m="plavix ( clopidogrel )" 23:0 23:3
do="75 mg" 23:4 23:5
mo="po " 23:6 23:6
f="qam " 23:7 23:7
du="nm"
r="nm"
ln="list"
5:
m="nexium ( esomeprazole )" 24:0 24:3
do="20 mg" 24:4 24:5
mo="po" 24:6 24:6
f="qam" 24:7 24:7
du="nm"
r="nm"
ln="list"
6:
m="lasix ( furosemide )" 27:0 27:3
do="40 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qam" 27:7 27:7
du="nm"
r="nm"
ln="list"
7:
m="insulin 70/30 human" 28:0 28:2
do="40 units" 28:3 28:4
mo="sc" 28:5 28:5
f="bid" 28:6 28:6
du="nm"
r="nm"
ln="list"
8:
m="imdur er ( isosorbide mononitrate ( sr ) )" 29:0 29:8
do="60 mg" 29:9 29:10
mo="po" 29:11 29:11
f="daily" 29:12 29:12
du="nm"
r="nm"
ln="list"
9:
m="labetalol hcl" 33:0 33:1
do="400 mg" 33:2 33:3
mo="po" 33:4 33:4
f="q8h" 33:5 33:5
du="nm"
r="nm"
ln="list"
10:
m="levoxyl ( levothyroxine sodium )" 36:0 36:4
do="112 mcg" 36:5 36:6
mo="po" 36:7 36:7
f="daily" 36:8 36:8
du="nm"
r="nm"
ln="list"
11:
m="oxycodone" 38:0 38:0
do="5-10 mg" 38:1 38:2
mo="po" 38:3 38:3
f="q4h prn" 38:4 38:5
du="nm"
r="pain" 38:6 38:6
ln="list"
12:
m="oxycodone" 41:3 41:3
do="nm"
mo="po" 41:4 41:4
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="aldactone ( spironolactone )" 44:0 44:3
do="12.5 mg" 44:4 44:5
mo="po" 44:6 44:6
f="qam" 44:7 44:7
du="nm"
r="nm"
ln="list"
14:
m="diovan ( valsartan )" 46:0 46:3
do="160 mg" 46:4 46:5
mo="po" 46:6 46:6
f="daily" 46:7 46:7
du="number of doses required ( approximate ): 5" 47:0 47:7
r="nm"
ln="list"
15:
m="nitro." 74:4 74:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="asa/plavix" 76:6 76:6
do="home dose" 76:8 76:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="heparin" 76:1 76:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="hydralazine" 78:0 78:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="lopressor" 78:12 78:12
do="25." 78:13 78:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="nitro" 78:3 78:3
do="nm"
mo="sl" 78:2 78:2
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="nitro" 78:5 78:5
do="nm"
mo="drip" 78:6 78:6
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="nitro" 89:8 89:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="heparin" 108:2 108:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="a pulmonary embolism" 110:7 110:9
ln="narrative"
24:
m="asa/plavix/bb/statin;" 117:2 117:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="heparin" 119:10 119:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="labetalol" 124:9 124:9
do="uptitrated" 124:8 124:8
mo="nm"
f="nm"
du="nm"
r="bp." 124:11 124:11
ln="narrative"
27:
m="nph" 135:6 135:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="short acting...insulin" 135:8 135:9,135:11 135:11
do="nm"
mo="nm"
f="pre-meal" 135:10 135:10
du="nm"
r="tight control." 136:0 136:1
ln="narrative"
29:
m="insulin" 136:9 136:9
do="nm"
mo="sc" 136:8 136:8
f="nm"
du="nm"
r="tight control" 136:11 136:12
ln="narrative"
30:
m="nph" 137:9 137:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="short acting...regimen" 137:11 137:12,138:0 138:0
do="nm"
mo="nm"
f="pre-meal" 137:13 137:13
du="nm"
r="nm"
ln="narrative"
32:
m="insulin regimen;" 141:0 141:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="levoxyl" 143:3 143:3
do="112 mcg" 143:0 143:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="oxycodone" 145:2 145:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="tylenol" 145:4 145:4
do="nm"
mo="nm"
f="prn" 145:5 145:5
du="nm"
r="nm"
ln="narrative"
36:
m="mag/k/calcium" 146:1 146:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="heparin" 147:1 147:1
do="nm"
mo="nm"
f="nm"
du="while in house" 147:2 147:4
r="nm"
ln="narrative"
38:
m="insulin" 150:4 150:4
do="titrate" 150:3 150:3
mo="nm"
f="nm"
du="nm"
r="blood sugars" 150:0 150:1
ln="narrative"
39:
m="insulin" 157:9 157:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
