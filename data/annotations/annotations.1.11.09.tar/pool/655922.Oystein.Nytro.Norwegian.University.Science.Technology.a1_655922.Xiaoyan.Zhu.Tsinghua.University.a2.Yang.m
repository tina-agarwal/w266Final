1:
m="enteric coated asa ( aspirin enteric coated )" 16:0 16:7
do="325 mg" 17:0 17:1
mo="po" 17:2 17:2
f="qd" 17:3 17:3
du="nm"
r="nm"
ln="list"
2:
m="enteric coated asa" 20:3 20:5
do="325 mg" 20:7 20:8
mo="po" 20:6 20:6
f="qd" 20:9 20:9
du="nm"
r="nm"
ln="list"
3:
m="enteric coated asa" 25:3 25:5
do="325 mg" 25:7 25:8
mo="po" 25:6 25:6
f="qd" 25:9 25:9
du="nm"
r="nm"
ln="list"
4:
m="ecasa" 30:3 30:3
do="325 mg" 30:5 30:6
mo="po" 30:4 30:4
f="qd" 30:7 30:7
du="nm"
r="nm"
ln="list"
5:
m="insulin nph human" 33:0 33:2
do="36 units" 33:3 33:4
mo="nm"
f="qam;" 33:5 33:5
du="nm"
r="nm"
ln="list"
6:
m="insulin nph human" 33:0 33:2
do="36 units" 34:0 34:1
mo="nm"
f="qam" 33:5 33:5
du="nm"
r="nm"
ln="list"
7:
m="insulin nph human" 33:0 33:2
do="40 units" 33:6 33:7
mo="sc" 33:9 33:9
f="qpm" 33:8 33:8
du="nm"
r="nm"
ln="list"
8:
m="insulin nph human" 33:0 33:2
do="40 units" 34:3 34:4
mo="nm"
f="qpm" 34:5 34:5
du="nm"
r="nm"
ln="list"
9:
m="neurontin ( gabapentin )" 35:0 35:3
do="600 mg" 35:4 35:5
mo="po" 35:6 35:6
f="bid" 35:7 35:7
du="nm"
r="nm"
ln="list"
10:
m="plavix ( clopidogrel )" 36:0 36:3
do="75 mg" 36:4 36:5
mo="po" 36:6 36:6
f="qd" 36:7 36:7
du="nm"
r="nm"
ln="list"
11:
m="zetia ( ezetimibe )" 37:0 37:3
do="10 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
12:
m="lisinopril" 38:0 38:0
do="40 mg" 38:1 38:2
mo="po" 38:3 38:3
f="qd" 38:4 38:4
du="nm"
r="nm"
ln="list"
13:
m="hydrochlorothiazide" 39:0 39:0
do="25 mg" 39:1 39:2
mo="po" 39:3 39:3
f="qd" 39:4 39:4
du="nm"
r="nm"
ln="list"
14:
m="prevacid ( lansoprazole )" 40:0 40:3
do="30 mg" 40:4 40:5
mo="po" 40:6 40:6
f="qd" 40:7 40:7
du="nm"
r="nm"
ln="list"
15:
m="glucophage ( metformin )" 41:0 41:3
do="1 , 000 mg" 41:4 41:7
mo="po" 41:8 41:8
f="bid" 41:9 41:9
du="nm"
r="nm"
ln="list"
16:
m="ibuprofen" 42:0 42:0
do="600-800 mg" 42:1 42:2
mo="po" 42:3 42:3
f="q6h prn" 42:4 42:5
du="nm"
r="pain" 42:6 42:6
ln="list"
17:
m="ibuprofen" 45:3 45:3
do="nm"
mo="po" 45:4 45:4
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="clopidogrel bisulfate" 49:3 49:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="ibuprofen" 50:0 50:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="atenolol" 51:0 51:0
do="25 mg" 51:1 51:2
mo="po" 51:3 51:3
f="qd" 51:4 51:4
du="nm"
r="nm"
ln="list"
21:
m="atropine" 91:3 91:3
do="nm"
mo="nm"
f="nm"
du="x 1" 91:4 91:5
r="bp" 90:2 90:2
ln="narrative"
22:
m="dopamine." 93:5 93:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="leni" 99:4 99:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="hct drop/hematoma." 99:2 99:3
ln="narrative"
24:
m="prbc" 101:14 101:14
do="2 u" 101:12 101:13
mo="trandfused" 101:11 101:11
f="nm"
du="nm"
r="her hct" 101:0 101:1
ln="narrative"
25:
m="ibuprofen" 108:0 108:0
do="nm"
mo="nm"
f="prn" 108:1 108:1
du="nm"
r="nm"
ln="narrative"
26:
m="anti-ischemic regimen" 110:0 110:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="asa" 110:4 110:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="atenolol" 110:8 110:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="lisinopril." 110:10 110:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="plavix" 110:6 110:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="diabetic regimen" 111:12 112:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="statin" 111:2 111:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
