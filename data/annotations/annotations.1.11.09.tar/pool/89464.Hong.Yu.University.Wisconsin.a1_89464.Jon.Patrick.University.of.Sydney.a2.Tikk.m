1:
m="bactrim" 36:2 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="a urinary tract infection" 35:5 35:8
ln="narrative"
2:
m="bactrim" 36:2 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="his incontinence" 36:6 36:7
ln="narrative"
3:
m="lasix" 93:11 93:11
do="nm"
mo="p.o." 93:12 93:12
f="q day" 94:0 94:1
du="nm"
r="his peripheral edema" 94:4 94:6
ln="narrative"
4:
m="coumadin" 97:6 97:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nystatin powder" 100:3 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="his pannus rash." 100:6 100:8
ln="narrative"
6:
m="bactrim" 102:5 102:5
do="nm"
mo="nm"
f="nm"
du="seven days" 102:2 102:3
r="his urinary tract infection" 101:3 101:6
ln="narrative"
7:
m="aspirin" 106:3 106:3
do="325 mg" 106:4 106:5
mo="p.o." 106:6 106:6
f="q day" 106:7 106:8
du="nm"
r="nm"
ln="list"
8:
m="colace" 106:10 106:10
do="100 mg" 106:11 107:0
mo="p.o." 107:1 107:1
f="b.i.d." 107:2 107:2
du="nm"
r="nm"
ln="list"
9:
m="lasix" 107:4 107:4
do="40 mg" 107:5 107:6
mo="p.o." 107:7 107:7
f="q a.m." 107:8 107:9
du="nm"
r="nm"
ln="list"
10:
m="indomethacin" 108:0 108:0
do="25 mg" 108:1 108:2
mo="p.o." 108:3 108:3
f="t.i.d. p.r.n." 108:4 108:5
du="nm"
r="pain" 108:6 108:6
ln="list"
11:
m="lisinopril" 108:8 108:8
do="15 mg" 108:9 108:10
mo="p.o." 108:11 108:11
f="q day" 108:12 109:0
du="nm"
r="nm"
ln="list"
12:
m="bactrim ds" 109:9 109:10
do="one tablet" 109:11 109:12
mo="p.o." 109:13 109:13
f="t.i.d." 110:0 110:0
du="nm"
r="nm"
ln="list"
13:
m="multivitamin" 109:2 109:2
do="one tablet" 109:3 109:4
mo="p.o." 109:5 109:5
f="q day" 109:6 109:7
du="nm"
r="nm"
ln="list"
14:
m="miconazole 2% topical powder" 110:9 110:12
do="nm"
mo="nm"
f="b.i.d." 111:0 111:0
du="nm"
r="nm"
ln="list"
15:
m="tamsulosin" 110:2 110:2
do="0.4 mg" 110:3 110:4
mo="p.o." 110:5 110:5
f="q day" 110:6 110:7
du="nm"
r="nm"
ln="list"
