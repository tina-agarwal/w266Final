1:
m="lasix" 16:9 16:9
do="nm"
mo="drip" 16:10 16:10
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="amiodarone" 17:3 17:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="a new paroxysmal atrial fibrillation." 17:7 18:1
ln="narrative"
3:
m="coumadin" 17:5 17:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="a new paroxysmal atrial fibrillation." 17:7 18:1
ln="narrative"
4:
m="lasix" 24:10 24:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="torsemide" 25:1 25:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="coumadin" 31:7 31:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="paroxysmal atrial fibrillation" 31:1 31:3
ln="narrative"
7:
m="amiodarone." 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="paroxysmal atrial fibrillation" 31:1 31:3
ln="narrative"
8:
m="torsemide" 46:1 46:1
do="100 mg" 46:2 46:3
mo="nm"
f="q.a.m." 46:4 46:4
du="nm"
r="nm"
ln="list"
9:
m="torsemide" 46:1 46:1
do="50 mg" 46:6 46:7
mo="nm"
f="q.p.m." 46:8 46:8
du="nm"
r="nm"
ln="list"
10:
m="ativan" 47:1 47:1
do="0.5 mg" 47:2 47:3
mo="p.o." 47:4 47:4
f="t.i.d. p.r.n." 47:5 47:6
du="nm"
r="anxiety." 47:7 47:7
ln="list"
11:
m="folate" 48:1 48:1
do="1 mg" 48:2 48:3
mo="p.o." 48:4 48:4
f="daily." 48:5 48:5
du="nm"
r="nm"
ln="list"
12:
m="lipitor" 49:1 49:1
do="80 mg" 49:2 49:3
mo="p.o." 49:4 49:4
f="at bedtime." 49:5 49:6
du="nm"
r="nm"
ln="list"
13:
m="lantus" 50:1 50:1
do="18 units" 50:2 50:3
mo="subcutaneously" 50:4 50:4
f="nightly" 50:5 50:5
du="nm"
r="nm"
ln="list"
14:
m="coumadin" 51:1 51:1
do="1 mg" 51:2 51:3
mo="nm"
f="q.p.m." 51:4 51:4
du="nm"
r="nm"
ln="list"
15:
m="lopressor" 52:1 52:1
do="25 mg" 52:2 52:3
mo="p.o." 52:4 52:4
f="b.i.d." 52:5 52:5
du="nm"
r="nm"
ln="list"
16:
m="procrit" 53:1 53:1
do="40 , 000 units" 53:2 53:5
mo="subcutaneously" 53:6 53:6
f="every other week." 53:7 53:9
du="nm"
r="nm"
ln="list"
17:
m="nitroglycerin" 54:1 54:1
do="nm"
mo="sublingual" 54:2 54:2
f="p.r.n." 54:3 54:3
du="nm"
r="chest pain." 54:4 54:5
ln="list"
18:
m="aspirin" 55:1 55:1
do="81 mg" 55:2 55:3
mo="p.o." 55:4 55:4
f="daily." 55:5 55:5
du="nm"
r="nm"
ln="list"
19:
m="vitamin b12" 56:1 56:2
do="nm"
mo="subcutaneous injections" 56:3 56:4
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="amiodarone" 57:1 57:1
do="200 mg" 57:2 57:3
mo="p.o." 57:4 57:4
f="daily." 57:5 57:5
du="nm"
r="nm"
ln="list"
21:
m="iron" 58:1 58:1
do="325 mg" 58:2 58:3
mo="p.o." 58:4 58:4
f="t.i.d." 58:5 58:5
du="nm"
r="nm"
ln="list"
22:
m="metolazone" 59:1 59:1
do="nm"
mo="nm"
f="p.r.n." 59:2 59:2
du="nm"
r="nm"
ln="list"
23:
m="lasix drip" 96:6 96:7
do="10 mg" 96:9 96:10
mo="nm"
f="per hour" 96:11 96:12
du="nm"
r="nm"
ln="narrative"
24:
m="lopressor" 97:8 97:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="a decompensated heart failure." 97:12 98:2
ln="narrative"
25:
m="zaroxolyn" 97:1 97:1
do="2.5 mg" 97:3 97:4
mo="p.o." 97:5 97:5
f="daily." 97:6 97:6
du="nm"
r="nm"
ln="narrative"
26:
m="lasix drip" 100:2 100:3
do="20 mg" 100:8 100:9
mo="drip" 100:3 100:3
f="per hour" 100:10 100:11
du="nm"
r="her diuresis" 99:7 99:8
ln="narrative"
27:
m="zaroxolyn" 101:0 101:0
do="nm"
mo="nm"
f="b.i.d." 101:4 101:4
du="nm"
r="her diuresis" 99:7 99:8
ln="narrative"
28:
m="diuril." 104:4 104:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="zaroxolyn" 104:0 104:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="diuril" 107:7 107:7
do="250 mg" 108:3 108:4
mo="iv" 108:5 108:5
f="b.i.d." 108:6 108:6
du="nm"
r="nm"
ln="narrative"
31:
m="zaroxolyn" 107:5 107:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="lasix" 115:7 115:7
do="nm"
mo="drip" 115:8 115:8
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="torsemide regimen" 117:4 117:5
do="100 mg" 117:7 117:8
mo="p.o." 117:9 117:9
f="q.a.m." 117:10 117:10
du="nm"
r="nm"
ln="narrative"
34:
m="torsemide regimen" 117:4 117:5
do="50 mg" 117:12 118:0
mo="p.o." 118:1 118:1
f="q.p.m." 118:2 118:2
du="nm"
r="nm"
ln="narrative"
35:
m="diuril" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="metolazone" 120:7 120:7
do="nm"
mo="p.o." 120:5 120:5
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="torsemide" 120:3 120:3
do="nm"
mo="nm"
f="b.i.d." 120:2 120:2
du="nm"
r="nm"
ln="narrative"
38:
m="amiodarone" 127:8 127:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 126:9 126:10
ln="narrative"
39:
m="coumadin" 127:10 127:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 126:9 126:10
ln="narrative"
40:
m="amiodarone" 131:8 131:8
do="home dose" 131:5 131:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="coumadin;" 132:0 132:0
do="0.5 mg" 133:7 133:8
mo="nm"
f="q.p.m." 133:9 133:9
du="nm"
r="nm"
ln="narrative"
42:
m="coumadin;" 132:0 132:0
do="1 mg" 133:2 133:3
mo="nm"
f="q.p.m." 133:4 133:4
du="nm"
r="nm"
ln="narrative"
43:
m="coumadin" 134:5 134:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="coumadin" 135:5 135:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="coumadin" 137:6 137:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="aspirin" 141:1 141:1
do="nm"
mo="nm"
f="nm"
du="throughout the admission." 141:4 141:6
r="nm"
ln="narrative"
47:
m="lipitor" 141:3 141:3
do="nm"
mo="nm"
f="nm"
du="throughout the admission." 141:4 141:6
r="nm"
ln="narrative"
48:
m="magnesium" 146:6 146:6
do="nm"
mo="nm"
f="nm"
du="throughout the admission" 147:2 147:4
r="nm"
ln="narrative"
49:
m="potassium" 146:4 146:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="lantus" 161:6 161:6
do="16 units" 162:2 162:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="lantus" 161:6 161:6
do="18 units" 161:11 162:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="novolog" 162:6 162:6
do="sliding scale" 162:7 162:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="novolog regimen." 165:8 165:9
do="nm"
mo="nm"
f="q.a.c." 165:7 165:7
du="nm"
r="nm"
ln="narrative"
54:
m="insulin" 173:1 173:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
55:
m="lantus" 174:1 174:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="home regimen" 176:8 176:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
57:
m="lantus" 177:3 177:3
do="12 units" 177:7 177:8
mo="nm"
f="nightly." 177:9 177:9
du="nm"
r="nm"
ln="narrative"
58:
m="lantus" 177:3 177:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="insulin" 180:0 180:0
do="nm"
mo="nm"
f="nm"
du="during this hospitalization." 180:1 180:3
r="nm"
ln="narrative"
60:
m="aranesp" 185:8 185:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="procrit" 186:6 186:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="potassium" 190:10 190:10
do="nm"
mo="nm"
f="as needed" 191:3 191:4
du="nm"
r="nm"
ln="narrative"
63:
m="magnesium" 191:0 191:0
do="nm"
mo="nm"
f="as needed" 191:3 191:4
du="nm"
r="nm"
ln="narrative"
64:
m="coumadin" 192:5 192:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis" 192:2 192:2
ln="narrative"
65:
m="nexium." 192:7 192:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="prophylaxis" 192:2 192:2
ln="narrative"
66:
m="coumadin" 197:8 197:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="aspirin" 200:1 200:1
do="81 mg" 200:2 200:3
mo="p.o." 200:4 200:4
f="daily." 200:5 200:5
du="nm"
r="nm"
ln="list"
68:
m="amiodarone" 201:1 201:1
do="200 mg" 201:2 201:3
mo="p.o." 201:4 201:4
f="daily." 201:5 201:5
du="nm"
r="nm"
ln="list"
69:
m="lipitor" 202:1 202:1
do="80 mg" 202:2 202:3
mo="p.o." 202:4 202:4
f="daily." 202:5 202:5
du="nm"
r="nm"
ln="list"
70:
m="folate" 203:1 203:1
do="1 mg" 203:2 203:3
mo="p.o." 203:4 203:4
f="daily." 203:5 203:5
du="nm"
r="nm"
ln="list"
71:
m="lantus insulin" 204:1 204:2
do="12 units" 204:3 204:4
mo="subcutaneous" 204:5 204:5
f="nightly." 204:6 204:6
du="nm"
r="nm"
ln="list"
72:
m="ativan" 205:1 205:1
do="0.5 mg" 205:2 205:3
mo="p.o." 205:4 205:4
f="t.i.d." 205:5 205:5
du="nm"
r="nm"
ln="list"
73:
m="metolazone" 206:1 206:1
do="2.5 mg" 206:2 206:3
mo="p.o." 206:4 206:4
f="daily as needed" 206:5 206:7
du="nm"
r="fluid retention" 206:9 206:10
ln="list"
74:
m="multivitamin" 208:1 208:1
do="one tablet" 208:2 208:3
mo="p.o." 208:4 208:4
f="daily." 208:5 208:5
du="nm"
r="nm"
ln="list"
75:
m="torsemide" 209:1 209:1
do="100 mg" 209:2 209:3
mo="p.o." 209:4 209:4
f="q.a.m." 209:5 209:5
du="nm"
r="nm"
ln="list"
76:
m="torsemide" 209:1 209:1
do="50 mg" 209:7 209:8
mo="p.o." 209:9 209:9
f="q.p.m." 209:10 209:10
du="nm"
r="nm"
ln="list"
77:
m="vitamin b12." 210:1 210:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
78:
m="iron." 211:1 211:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
79:
m="procrit" 212:1 212:1
do="40 , 000 units" 212:2 212:5
mo="subcutaneously" 212:6 212:6
f="every other week." 212:7 212:9
du="nm"
r="nm"
ln="list"
