1:
m="amiodarone" 17:0 17:0
do="200 mg" 17:1 17:2
mo="po" 17:3 17:3
f="bid" 17:4 17:4
du="nm"
r="nm"
ln="list"
2:
m="ecasa" 18:0 18:0
do="325 mg" 18:1 18:2
mo="po" 18:3 18:3
f="qd" 18:4 18:4
du="nm"
r="nm"
ln="list"
3:
m="isosorbide dinitrate" 19:0 19:1
do="30 mg" 19:2 19:3
mo="po" 19:4 19:4
f="tid" 19:5 19:5
du="nm"
r="nm"
ln="list"
4:
m="lopressor ( metoprolol tartrate )" 20:0 20:4
do="50 mg" 20:5 20:6
mo="po" 20:7 20:7
f="bid" 20:8 20:8
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin 1/150 ( 0.4 mg )" 23:0 23:5
do="1 tab" 23:6 23:7
mo="sl" 23:8 23:8
f="q5min" 23:9 23:9
du="x 3" 23:10 23:11
r="chest pain" 24:1 24:2
ln="list"
6:
m="nitroglycerin 1/150 ( 0.4 mg )" 23:0 23:5
do="1 tab" 23:6 23:7
mo="sl" 23:8 23:8
f="q5min...prn" 23:9 23:9,24:0 24:0
du="x 3" 23:10 23:11
r="chest pain" 24:1 24:2
ln="list"
7:
m="keflex ( cephalexin )" 25:0 25:3
do="500 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qid" 25:7 25:7
du="nm"
r="chronic osteomyelitis right foot" 26:2 26:5
ln="list"
8:
m="altace ( ramipril )" 27:0 27:3
do="1.25 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qd" 27:7 27:7
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 29:3 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="ramipril" 30:0 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride" 31:3 31:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="ramipril" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="plavix ( clopidogrel )" 33:0 33:3
do="75 mg" 33:4 33:5
mo="po" 33:6 33:6
f="qd" 33:7 33:7
du="nm"
r="nm"
ln="list"
14:
m="nexium ( esomeprazole )" 34:0 34:3
do="20 mg" 34:4 34:5
mo="po" 34:6 34:6
f="qd" 34:7 34:7
du="nm"
r="nm"
ln="list"
15:
m="ntg" 57:9 57:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nitro" 60:7 60:7
do="nm"
mo="sl" 60:6 60:6
f="nm"
du="x 2-&gt;bp" 60:8 60:9
r="nm"
ln="narrative"
17:
m="ntg" 61:0 61:0
do="nm"
mo="sl" 60:14 60:14
f="nm"
du="x2-&gt;" 61:1 61:1
r="nm"
ln="narrative"
18:
m="ntg" 62:7 62:7
do="nm"
mo="sl" 62:6 62:6
f="nm"
du="nm"
r="cp" 62:0 62:0
ln="narrative"
19:
m="keflex" 68:9 68:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic osteomyelitis" 68:4 68:5
ln="narrative"
20:
m="amiodarone" 70:5 70:5
do="200" 70:6 70:6
mo="nm"
f="bid" 70:7 70:7
du="nm"
r="nm"
ln="list"
21:
m="lopressor" 70:9 70:9
do="50" 70:10 70:10
mo="nm"
f="bid" 70:11 70:11
du="nm"
r="nm"
ln="list"
22:
m="meds:asa" 70:2 70:2
do="325" 70:3 70:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="imdur" 71:0 71:0
do="60" 71:1 71:1
mo="nm"
f="bid" 71:2 71:2
du="nm"
r="nm"
ln="list"
24:
m="kcl" 71:17 71:17
do="40" 72:0 72:0
mo="nm"
f="qd" 72:1 72:1
du="nm"
r="nm"
ln="list"
25:
m="keflex" 71:9 71:9
do="500" 71:10 71:10
mo="nm"
f="q4" 71:11 71:11
du="nm"
r="nm"
ln="list"
26:
m="lasix" 71:13 71:13
do="60" 71:14 71:14
mo="nm"
f="bid" 71:15 71:15
du="nm"
r="nm"
ln="list"
27:
m="plavix" 71:4 71:4
do="75" 71:5 71:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="protonix" 71:7 71:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="ativan" 72:15 72:15
do="5 mg" 73:0 73:1
mo="nm"
f="prn" 73:2 73:2
du="nm"
r="nm"
ln="list"
30:
m="metformin" 72:3 72:3
do="500" 72:4 72:4
mo="nm"
f="bid" 72:5 72:5
du="nm"
r="nm"
ln="list"
31:
m="micronase" 72:7 72:7
do="10" 72:8 72:8
mo="nm"
f="bid" 72:9 72:9
du="nm"
r="nm"
ln="list"
32:
m="tylenol c codeine" 72:11 72:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="antianginal therapy" 91:3 91:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="nitro" 94:5 94:5
do="nm"
mo="sl" 94:4 94:4
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="asa" 95:2 95:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="plavix" 95:4 95:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="nitrate" 96:0 96:0
do="nm"
mo="oral" 95:6 95:6
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="bblocker." 98:6 98:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="nitrate." 98:0 98:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="agents." 99:7 99:7
do="nm"
mo="oral" 99:6 99:6
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="amiodarone." 99:0 99:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="ivf" 100:6 100:6
do="100 cc/h." 100:7 100:8
mo="nm"
f="nm"
du="nm"
r="elevated bun/cr." 100:2 100:3
ln="narrative"
43:
m="keflex." 101:6 101:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic osteomyletis." 101:3 101:4
ln="narrative"
44:
m="ppi" 102:12 102:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="gerd." 103:0 103:0
ln="narrative"
45:
m="hep." 103:6 103:6
do="nm"
mo="sc" 103:5 103:5
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="ppi" 103:3 103:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="coumadin" 106:1 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation." 106:7 106:8
ln="narrative"
