1:
m="nitroglycerin." 18:2 18:2
do="nm"
mo="sublingual" 18:1 18:1
f="nm"
du="nm"
r="substernal chest pain" 16:10 17:0
ln="narrative"
2:
m="aspirin" 38:12 38:12
do="325 mg" 39:0 39:1
mo="p.o." 39:2 39:2
f="daily" 39:3 39:3
du="nm"
r="nm"
ln="list"
3:
m="lopressor" 38:0 38:0
do="50 mg" 38:1 38:2
mo="p.o." 38:3 38:3
f="q.i.d." 38:4 38:4
du="nm"
r="nm"
ln="list"
4:
m="valsartan" 38:6 38:6
do="160 mg" 38:7 38:8
mo="p.o." 38:9 38:9
f="daily" 38:10 38:10
du="nm"
r="nm"
ln="list"
5:
m="atorvastatin" 39:5 39:5
do="80 mg" 39:6 39:7
mo="p.o." 39:8 39:8
f="daily" 39:9 39:9
du="nm"
r="nm"
ln="list"
6:
m="b12" 39:11 39:11
do="100 mcg" 39:12 39:13
mo="p.o." 40:0 40:0
f="daily " 40:1 40:1
du="nm"
r="nm"
ln="list"
7:
m="colace" 40:3 40:3
do="100 mg" 40:4 40:5
mo="p.o." 40:6 40:6
f="b.i.d." 40:7 40:7
du="nm"
r="nm"
ln="list"
8:
m="folate" 40:9 40:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="levoxyl" 40:11 40:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="nexium" 40:13 40:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lantus" 41:0 41:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="novolog insulin" 41:3 41:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="plavix" 75:8 75:8
do="150 mg" 75:5 75:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="plavix" 75:8 75:8
do="a second dose" 76:4 76:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="aspirin" 77:8 77:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="heparin" 77:0 77:0
do="500 units" 77:1 77:2
mo="nm"
f="nm"
du="for 48 hours" 77:3 77:5
r="nm"
ln="narrative"
17:
m="packed red blood cells." 79:7 79:10
do="a unit" 79:4 79:5
mo="transfusion" 79:2 79:2
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="neosynephrine" 80:1 80:1
do="nm"
mo="nm"
f="nm"
du="transiently" 80:2 80:2
r="nm"
ln="narrative"
19:
m="aspirin" 83:5 83:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="lopressor" 83:7 83:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="oxygen" 84:9 84:9
do="2 liters" 84:6 84:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="plavix." 84:0 84:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="lasix" 87:0 87:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="insulin" 89:3 89:3
do="nm"
mo="IV" 89:2 89:2
f="nm"
du="nm"
r="blood sugar control" 88:5 88:7
ln="narrative"
25:
m="insulin" 89:6 89:6
do="nm"
mo="subcutaneous" 89:5 89:5
f="nm"
du="nm"
r="blood sugar control" 88:5 88:7
ln="narrative"
26:
m="levofloxacin" 92:0 92:0
do="nm"
mo="nm"
f="nm"
du="for five days" 92:5 92:7
r="a preoperative urinary tract infection" 90:7 91:2
ln="narrative"
27:
m="oxygen" 100:3 100:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="atenolol" 104:7 104:7
do="75 mg" 104:8 104:9
mo="p.o." 104:10 104:10
f="daily" 105:0 105:0
du="nm"
r="nm"
ln="list"
29:
m="enteric-coated aspirin" 104:0 104:1
do="325 mg" 104:2 104:3
mo="p.o." 104:4 104:4
f="daily" 104:5 104:5
du="nm"
r="nm"
ln="list"
30:
m="colace" 105:2 105:2
do="100 mg" 105:3 105:4
mo="p.o." 105:5 105:5
f="t.i.d." 105:6 105:6
du="nm"
r="nm"
ln="list"
31:
m="oxycodone" 105:8 105:8
do="5 mg to 10 mg" 105:9 105:13
mo="p.o." 105:14 105:14
f="q.6h. p.r.n." 106:0 106:1
du="nm"
r="pain" 106:2 106:2
ln="list"
32:
m="lantus" 106:10 106:10
do="38 units" 106:11 106:12
mo="subcutaneously" 107:0 107:0
f="at bedtime" 107:1 107:2
du="nm"
r="nm"
ln="list"
33:
m="plavix" 106:4 106:4
do="75 mg" 106:5 106:6
mo="p.o." 106:7 106:7
f="daily" 106:8 106:8
du="nm"
r="nm"
ln="list"
34:
m="novolog" 107:4 107:4
do="18 units" 107:5 107:6
mo="subcutaneous" 107:7 107:7
f="q.a.m." 107:8 107:8
du="nm"
r="nm"
ln="list"
35:
m="novolog" 108:0 108:0
do="12 units" 108:1 108:2
mo="subcutaneously" 108:3 108:3
f="with lunch and supper" 108:4 108:7
du="nm"
r="nm"
ln="list"
36:
m="atorvastatin" 109:0 109:0
do="80 mg" 109:1 109:2
mo="p.o." 109:3 109:3
f="daily." 109:4 109:4
du="nm"
r="nm"
ln="list"
