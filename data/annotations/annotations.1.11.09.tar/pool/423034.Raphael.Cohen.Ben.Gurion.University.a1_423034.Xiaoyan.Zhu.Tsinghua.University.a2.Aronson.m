1:
m="aspirin" 19:3 19:3
do="325 mg" 19:4 19:5
mo="p.o." 19:6 19:6
f="q d " 19:7 19:8
du="nm"
r="nm"
ln="list"
2:
m="pravachol" 19:10 19:10
do="60 mg" 19:11 19:12
mo="p.o." 20:0 20:0
f="q d" 20:1 20:2
du="nm"
r="nm"
ln="list"
3:
m="metoprolol" 20:4 20:4
do="60 mg" 20:5 20:6
mo="p.o." 20:7 20:7
f="b.i.d." 20:8 20:8
du="nm"
r="nm"
ln="list"
4:
m="glucophage" 21:6 21:6
do="1000 mg" 21:7 21:8
mo="p.o." 21:9 21:9
f="b.i.d." 21:10 21:10
du="nm"
r="nm"
ln="list"
5:
m="glyburide" 21:0 21:0
do="10 mg" 21:1 21:2
mo="p.o." 21:3 21:3
f="b.i.d." 21:4 21:4
du="nm"
r="nm"
ln="list"
6:
m="vasotec" 22:0 22:0
do="20 mg" 22:1 22:2
mo="p.o." 22:3 22:3
f="q d " 22:4 22:5
du="nm"
r="nm"
ln="list"
7:
m="vitamin b multivitamin" 22:7 22:9
do="one tablet" 22:10 22:11
mo="p.o." 22:12 22:12
f="q d " 22:13 22:14
du="nm"
r="nm"
ln="list"
8:
m="plavix" 23:1 23:1
do="75 mg" 23:2 23:3
mo="p.o." 23:4 23:4
f="q d." 23:5 23:6
du="nm"
r="nm"
ln="list"
9:
m="triple antibiotics" 41:4 41:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="pca" 47:6 47:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 47:8 47:8
ln="narrative"
11:
m="pain medications." 49:8 49:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="her pain" 49:2 49:3
ln="narrative"
12:
m="beta blockers." 51:3 51:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="ancef" 56:10 56:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="erythema" 55:7 55:7
ln="narrative"
14:
m="enteric coated aspirin" 65:2 65:4
do="325 mg" 65:5 65:6
mo="p.o." 65:7 65:7
f="q d" 65:8 65:9
du="nm"
r="nm"
ln="list"
15:
m="atenolol" 66:0 66:0
do="50 mg" 66:1 66:2
mo="p.o." 66:3 66:3
f="q d " 66:4 66:5
du="nm"
r="nm"
ln="list"
16:
m="atenolol" 66:7 66:7
do="50 mg" 66:8 66:9
mo="p.o." 67:0 67:0
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="glyburide" 67:10 67:10
do="10 mg" 67:11 67:12
mo="p.o." 67:13 67:13
f="b.i.d." 67:14 67:14
du="nm"
r="nm"
ln="list"
18:
m="vasotec" 67:3 67:3
do="20 mg" 67:4 67:5
mo="p.o." 67:6 67:6
f="q d" 67:7 67:8
du="nm"
r="nm"
ln="list"
19:
m="percocet" 68:0 68:0
do="one to two tablets" 68:1 68:4
mo="p.o." 68:5 68:5
f="q 4 h p.r.n." 68:6 68:9
du="nm"
r="pain" 68:10 68:10
ln="list"
20:
m="vitamin b" 68:12 68:13
do="100 mg" 68:14 69:0
mo="p.o." 69:1 69:1
f="b.i.d." 69:2 69:2
du="nm"
r="nm"
ln="list"
21:
m="multivitamin" 69:4 69:4
do="one tablet" 69:5 69:6
mo="p.o." 69:7 69:7
f="q d " 69:8 69:9
du="nm"
r="nm"
ln="list"
22:
m="pravachol" 69:11 69:11
do="60 mg" 69:12 69:13
mo="p.o." 70:0 70:0
f="q h.s." 70:1 70:2
du="nm"
r="nm"
ln="list"
23:
m="glucophage" 70:4 70:4
do="1000 mg" 70:5 70:6
mo="p.o." 70:7 70:7
f="t.i.d." 70:8 70:8
du="x 7 days." 71:1 71:3
r="nm"
ln="list"
24:
m="keflex" 70:10 70:10
do="500 mg" 70:11 70:12
mo="p.o." 70:13 70:13
f="q.i.d." 71:0 71:0
du="x 7 days" 71:1 71:3
r="nm"
ln="list"
