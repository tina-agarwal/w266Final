1:
m="nitroglycerin" 14:2 14:2
do="nm"
mo="nm"
f="nm"
du="during such an episode" 14:5 14:8
r="shortness of breath" 12:9 13:1
ln="narrative"
2:
m="allopurinol" 38:7 38:7
do="300 mg" 38:8 38:9
mo="nm"
f="daily" 39:0 39:0
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 38:2 38:2
do="25 mg" 38:3 38:4
mo="nm"
f="daily" 38:5 38:5
du="nm"
r="nm"
ln="list"
4:
m="flomax" 39:3 39:3
do="0.8 mg" 39:4 39:5
mo="nm"
f="daily." 39:6 39:6
du="nm"
r="nm"
ln="list"
5:
m="vasopressin" 69:3 69:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="dopamine" 70:6 70:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="oliguria" 70:8 70:8
ln="narrative"
7:
m="dopamine" 72:9 72:9
do="2 mcg" 73:0 73:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="dopamine" 74:8 74:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="aspirin" 81:2 81:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="sick sinus." 81:7 81:8
ln="narrative"
10:
m="oxygen" 85:7 85:7
do="2 liters" 85:4 85:5
mo="nasal cannula" 86:0 86:1
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="dopamine" 88:6 88:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="creatinine" 88:4 88:4
ln="narrative"
12:
m="lasix" 89:6 89:6
do="nm"
mo="p.o." 89:5 89:5
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="aspirin." 91:3 91:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 91:1 91:1
ln="narrative"
14:
m="antibiotics" 92:1 92:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="troponin" 98:8 98:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="argatroban" 106:9 106:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="upper extremity dvt" 106:1 106:3
ln="narrative"
17:
m="argatroban" 110:0 110:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="mucomyst" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="argatroban" 119:2 119:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="argatroban" 123:3 123:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="packed red blood cells" 125:2 125:5
do="2 units" 125:0 125:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="argatroban" 131:6 131:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="propofol" 132:0 132:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="argatroban." 135:5 135:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="argatroban" 139:2 139:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="sodium" 142:8 142:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="argatroban" 143:8 143:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="PTT" 144:3 144:3
ln="narrative"
28:
m="ceftazidime" 148:8 148:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="sputum culture" 148:3 148:4
ln="narrative"
29:
m="packed red blood cells" 150:2 150:5
do="2 units" 150:0 150:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="argatroban" 151:8 151:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="argatroban" 164:5 164:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="flagyl" 164:2 164:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="fluconazole" 164:0 164:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="packed red blood cells" 165:7 165:10
do="3 units" 165:4 165:5
mo="nm"
f="nm"
du="nm"
r="profuse GI bleeding" 165:0 165:2
ln="narrative"
35:
m="argatroban" 167:2 167:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="vasopressin" 167:8 167:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="dopamine." 168:0 168:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="dopamine" 168:12 168:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="vasopressin" 168:10 168:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="argatroban" 179:0 179:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="lasix" 188:4 188:4
do="nm"
mo="drip" 188:5 188:5
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="argatroban" 198:2 198:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="lasix" 198:8 198:8
do="nm"
mo="iv" 198:7 198:7
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="argatroban" 200:3 200:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="argatroban" 201:7 201:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="lopressor" 201:10 201:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="argatroban" 203:4 203:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="ptt" 203:9 203:9
ln="narrative"
48:
m="argatroban" 204:11 204:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="argatroban" 206:0 206:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="argatroban" 210:4 210:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="argatroban" 213:3 213:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="triple antibiotic" 215:10 216:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="sputum/blood culture" 216:3 216:4
ln="narrative"
53:
m="argatroban" 221:4 221:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="flomax" 222:0 222:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="urinary retention" 222:4 222:5
ln="narrative"
55:
m="flomax" 224:4 224:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
56:
m="argatroban" 225:2 225:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="hit" 225:4 225:4
ln="narrative"
57:
m="coumadin" 225:0 225:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="hit" 225:4 225:4
ln="narrative"
58:
m="argatroban" 226:1 226:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="argatroban" 234:12 234:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="hit" 235:3 235:3
ln="narrative"
60:
m="coumadin" 235:1 235:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="hit" 235:3 235:3
ln="narrative"
61:
m="argatroban" 237:11 237:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="coumadin" 238:0 238:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="argatroban" 245:6 245:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="levofloxacin" 246:7 246:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="ec bacteremia" 246:9 246:10
ln="narrative"
65:
m="linezolid" 247:5 247:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="pseudomonas pneumonia." 247:7 247:8
ln="narrative"
66:
m="packed red blood cells" 251:12 252:1
do="2 unit" 251:8 251:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
67:
m="argatroban" 253:6 253:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="coumadin." 254:1 254:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="argatroban" 264:2 264:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="neurontin" 268:1 268:1
do="low-dose" 268:0 268:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="argatroban." 274:2 274:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="argatroban" 278:0 278:0
do="0.1" 278:4 278:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="argatroban" 278:0 278:0
do="0.2" 278:6 278:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
74:
m="coumadin" 278:10 278:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="lasix" 284:0 284:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="reduced urine output." 284:2 284:4
ln="narrative"
76:
m="linezolid" 287:2 287:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="ec bacteremia" 287:4 287:5
ln="narrative"
77:
m="levofloxacin" 289:7 289:7
do="nm"
mo="nm"
f="nm"
du="1/29/05 through 10/29/05" 289:8 290:0
r="nm"
ln="narrative"
78:
m="levofloxacin" 289:7 289:7
do="nm"
mo="nm"
f="nm"
du="8/4/05 through 3/18/06" 290:2 290:4
r="nm"
ln="narrative"
79:
m="argatroban" 293:6 293:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
80:
m="coumadin" 294:3 294:3
do="titrating" 294:2 294:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="linezolid" 302:3 302:3
do="nm"
mo="nm"
f="nm"
du="21 day course" 301:10 302:1
r="ec bacteremia" 302:5 302:6
ln="narrative"
82:
m="levofloxacin" 305:0 305:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
83:
m="lasix" 306:6 306:6
do="low-dose" 306:5 306:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
84:
m="argatroban" 307:0 307:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
85:
m="linezolid" 314:0 314:0
do="nm"
mo="nm"
f="nm"
du="21 day course" 313:8 313:10
r="ec bacteremia." 314:2 314:3
ln="narrative"
86:
m="argatroban" 317:2 317:2
do="nm"
mo="drip" 317:3 317:3
f="nm"
du="nm"
r="hit" 317:5 317:5
ln="narrative"
87:
m="linezolid" 318:8 318:8
do="nm"
mo="nm"
f="nm"
du="three more days" 318:4 318:6
r="ec bacteremia." 318:10 319:0
ln="narrative"
88:
m="argatroban" 320:0 320:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="hit" 320:2 320:2
ln="narrative"
89:
m="lasix" 321:6 321:6
do="20 mg" 321:3 321:4
mo="iv" 321:5 321:5
f="nm"
du="nm"
r="increased labored breathing" 321:8 321:10
ln="narrative"
90:
m="lasix" 321:6 321:6
do="20 mg" 321:3 321:4
mo="iv" 321:5 321:5
f="nm"
du="nm"
r="increased labored breathing" 321:8 321:11
ln="narrative"
91:
m="argatroban." 325:12 325:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
92:
m="argatroban" 326:9 326:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
93:
m="osmolite" 331:1 331:1
do="80 cc" 331:6 331:7
mo="p.o." 332:1 332:1
f="nm"
du="nm"
r="nm"
ln="narrative"
94:
m="tylenol" 352:2 352:2
do="325-650 mg" 352:3 352:4
mo="nm"
f="q.4h. p.r.n." 352:6 352:7
du="nm"
r="pain" 353:0 353:0
ln="list"
95:
m="atenolol" 353:2 353:2
do="12.5 mg" 353:3 353:4
mo="nm"
f="daily" 353:5 353:5
du="nm"
r="nm"
ln="list"
96:
m="dulcolax" 353:7 353:7
do="10 mg" 353:8 353:9
mo="pr" 353:10 353:10
f="daily p.r.n." 353:11 353:12
du="nm"
r="constipation" 354:0 354:0
ln="list"
97:
m="chloraseptic spray" 354:2 354:3
do="one spray" 354:4 354:5
mo="nm"
f="q.2h. p.r.n." 354:6 354:7
du="nm"
r="throat pain" 355:2 355:3
ln="list"
98:
m="colace" 355:9 355:9
do="100 mg" 355:10 355:11
mo="nm"
f="t.i.d. p.r.n." 355:12 356:0
du="nm"
r="constipation" 356:1 356:1
ln="list"
99:
m="ferrous sulfate" 356:3 356:4
do="300 mg" 356:5 356:6
mo="nm"
f="t.i.d." 356:8 356:8
du="nm"
r="nm"
ln="list"
100:
m="lasix" 356:10 356:10
do="40 mg" 356:11 357:0
mo="nm"
f="b.i.d." 357:2 357:2
du="nm"
r="nm"
ln="list"
101:
m="gentamicin sulfate" 357:4 357:5
do="two drops" 357:6 357:7
mo="ou" 357:8 357:8
f="q.8h." 357:9 357:9
du="nm"
r="nm"
ln="list"
102:
m="regular insulin" 357:11 358:0
do="sliding scale" 358:1 358:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
103:
m="regular insulin" 358:4 358:5
do="8 units" 358:6 358:7
mo="subq" 358:8 358:8
f="q.6h." 358:9 358:9
du="nm"
r="nm"
ln="list"
104:
m="milk of magnesia" 359:10 360:0
do="30 ml" 360:1 360:2
mo="nm"
f="daily p.r.n." 360:3 360:4
du="nm"
r="constipation" 360:5 360:5
ln="list"
105:
m="nystatin suspension" 360:7 360:8
do="1 million units" 360:9 361:1
mo="nm"
f="q.i.d." 361:2 361:2
du="nm"
r="nm"
ln="list"
106:
m="multivitamin therapeutic with minerals" 361:7 362:1
do="15 ml" 362:2 362:3
mo="nm"
f="daily" 362:5 362:5
du="nm"
r="nm"
ln="list"
107:
m="simvastatin" 362:7 362:7
do="20 mg" 362:8 362:9
mo="nm"
f="q.h.s." 362:11 362:11
du="nm"
r="nm"
ln="list"
108:
m="atrovent nebulizers" 363:0 363:1
do="0.5 mg" 363:2 363:3
mo="nm"
f="q.i.d." 363:4 363:4
du="nm"
r="nm"
ln="list"
109:
m="neurontin" 363:6 363:6
do="100 mg" 363:7 363:8
mo="nm"
f="t.i.d." 363:9 363:9
du="nm"
r="nm"
ln="list"
110:
m="ambien" 364:0 364:0
do="10 mg" 364:1 364:2
mo="nm"
f="q.h.s. p.r.n." 364:3 364:4
du="nm"
r="insomnia" 364:5 364:5
ln="list"
111:
m="k-dur" 364:7 364:7
do="20 meq" 364:8 364:9
mo="nm"
f="b.i.d." 364:11 364:11
du="nm"
r="nm"
ln="list"
112:
m="flomax" 365:0 365:0
do="0.8 mg" 365:1 365:2
mo="nm"
f="daily" 365:3 365:3
du="nm"
r="nm"
ln="list"
113:
m="miconazole nitrate 2% powder" 365:5 365:8
do="nm"
mo="topical" 365:9 365:9
f="b.i.d." 365:10 365:10
du="nm"
r="nm"
ln="list"
114:
m="coumadin" 366:5 366:5
do="variable dosage" 366:7 366:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
115:
m="nexium" 366:0 366:0
do="40 mg" 366:1 366:2
mo="nm"
f="daily" 366:3 366:3
du="nm"
r="nm"
ln="list"
116:
m="prochlorperazine" 367:6 367:6
do="20 mg" 367:7 367:8
mo="pr" 367:9 367:9
f="q.12h. p.r.n." 367:10 368:0
du="nm"
r="emesis." 368:1 368:1
ln="list"
