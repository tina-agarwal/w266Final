1:
m="hydrochlorothiazide." 19:0 19:0
do="nm"
mo="nm"
f="nm"
du="2 weeks" 18:4 18:5
r="nm"
ln="narrative"
2:
m="percocet" 20:2 20:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="his left hip pain" 20:5 20:8
ln="narrative"
3:
m="calcium" 31:8 31:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hyperkalemia" 31:0 31:1
ln="narrative"
4:
m="gluconate" 32:0 32:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hyperkalemia" 31:0 31:1
ln="narrative"
5:
m="insulin" 32:2 32:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hyperkalemia" 31:0 31:1
ln="narrative"
6:
m="kayexalate" 32:4 32:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hyperkalemia" 31:0 31:1
ln="narrative"
7:
m="normal saline." 34:11 35:0
do="60 cc" 34:8 34:9
mo="nm"
f="nm"
du="nm"
r="his acute renal failure" 33:8 34:0
ln="narrative"
