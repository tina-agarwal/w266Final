1:
m="aspirin" 25:3 25:3
do="nm"
mo="nm"
f="daily" 25:4 25:4
du="nm"
r="nm"
ln="list"
2:
m="lasix" 25:6 25:6
do="80 mg" 25:7 25:8
mo="p.o." 25:9 25:9
f="q day" 25:10 25:11
du="nm"
r="nm"
ln="list"
3:
m="toprol xl" 26:7 26:8
do="50 mg" 27:0 27:1
mo="p.o." 27:2 27:2
f="q day" 27:3 27:4
du="nm"
r="nm"
ln="list"
4:
m="zaroxolyn" 26:0 26:0
do="2.5 mg" 26:1 26:2
mo="p.o." 26:3 26:3
f="q day" 26:4 26:5
du="nm"
r="nm"
ln="list"
5:
m="actos" 27:10 27:10
do="45" 27:11 27:11
mo="nm"
f="q p.m" 27:12 27:13
du="nm"
r="nm"
ln="list"
6:
m="avapro" 27:15 27:15
do="300 mg" 27:16 28:0
mo="p.o." 28:1 28:1
f="q day" 28:2 28:3
du="nm"
r="nm"
ln="list"
7:
m="insulin" 27:6 27:6
do="70/30" 27:7 27:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="insulin 70/30" 27:6 27:7
do="65/45" 27:8 27:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="lipitor" 28:5 28:5
do="10 mg" 28:6 28:7
mo="p.o." 28:8 28:8
f="q.h.s." 28:9 28:9
du="nm"
r="nm"
ln="list"
10:
m="nitroglycerin" 28:12 28:12
do="nm"
mo="sublingual" 28:11 28:11
f="p.r.n.." 29:0 29:0
du="nm"
r="nm"
ln="list"
11:
m="lasix" 43:2 43:2
do="200 mg" 43:3 43:4
mo="iv" 43:6 43:6
f="b.i.d." 43:5 43:5
du="nm"
r="nm"
ln="narrative"
12:
m="zaroxolyn." 43:10 43:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="dopamine" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="dopamine" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="renal perfusion" 57:4 57:5
ln="narrative"
15:
m="lasix" 58:9 58:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="aspirin" 77:3 77:3
do="325 mg" 77:4 77:5
mo="p.o." 77:6 77:6
f="q day" 77:7 77:8
du="nm"
r="nm"
ln="list"
17:
m="lasix" 77:10 77:10
do="80 mg" 77:11 77:12
mo="p.o." 78:0 78:0
f="q day" 78:1 78:2
du="nm"
r="nm"
ln="list"
18:
m="zocor" 78:4 78:4
do="20 mg" 78:5 78:6
mo="p.o." 78:7 78:7
f="q.h.s." 78:8 78:8
du="nm"
r="nm"
ln="list"
19:
m="insulin 70/30" 79:0 79:1
do="65 units" 79:2 79:3
mo="nm"
f="q a.m." 79:4 79:5
du="nm"
r="nm"
ln="list"
20:
m="insulin 70/30" 79:7 79:8
do="45 units" 79:9 79:10
mo="nm"
f="q p.m." 79:11 79:12
du="nm"
r="nm"
ln="list"
21:
m="levaquin" 80:8 80:8
do="250 mg" 80:9 80:10
mo="p.o." 80:11 80:11
f="q day" 80:12 80:13
du="7 days" 81:2 81:3
r="nm"
ln="list"
22:
m="toprol xl" 80:0 80:1
do="50 mg" 80:2 80:3
mo="p.o." 80:4 80:4
f="q day" 80:5 80:6
du="nm"
r="nm"
ln="list"
23:
m="actos" 81:5 81:5
do="45 mg" 81:6 81:7
mo="p.o." 81:8 81:8
f="q p.m." 81:9 81:10
du="nm"
r="nm"
ln="list"
