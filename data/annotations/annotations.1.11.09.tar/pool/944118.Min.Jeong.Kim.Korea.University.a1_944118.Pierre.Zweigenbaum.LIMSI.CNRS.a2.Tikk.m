1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="daily" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="lipitor ( atorvastatin )" 21:0 21:3
do="10 mg" 21:4 21:5
mo="po" 21:6 21:6
f="daily" 21:7 21:7
du="nm"
r="nm"
ln="list"
3:
m="glyburide" 22:0 22:0
do="2.5 mg" 22:1 22:2
mo="po" 22:3 22:3
f="daily" 22:4 22:4
du="x 60 doses" 22:5 22:7
r="nm"
ln="list"
4:
m="metformin" 23:0 23:0
do="500 mg" 23:1 23:2
mo="po" 23:3 23:3
f="bid" 23:4 23:4
du="nm"
r="nm"
ln="list"
5:
m="metformin" 48:11 48:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="acyclovir" 54:0 54:0
do="nm"
mo="nm"
f="nm"
du="this week" 54:1 54:2
r="small rash" 53:5 53:86
ln="narrative"
7:
m="insulin" 64:8 64:8
do="sliding scale" 64:6 64:7
mo="nm"
f="nm"
du="nm"
r="blood sugar" 65:5 65:6
ln="narrative"
8:
m="glyburide" 76:4 76:4
do="low-dose" 76:3 76:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="metformin" 76:6 76:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperglycemia" 76:9 76:9
ln="narrative"
10:
m="aspirin" 78:1 78:1
do="325 mg" 78:7 78:8
mo="nm"
f="qd." 78:9 78:9
du="nm"
r="nm"
ln="narrative"
11:
m="aspirin" 78:1 78:1
do="81 mg" 78:4 78:5
mo="nm"
f="qd." 78:9 78:9
du="nm"
r="nm"
ln="narrative"
12:
m="glyburide" 80:10 80:10
do="nm"
mo="nm"
f="once a day" 81:0 81:2
du="nm"
r="blood sugars" 80:6 80:7
ln="narrative"
13:
m="metformin" 81:6 81:6
do="nm"
mo="nm"
f="twice a day." 81:7 81:9
du="nm"
r="nm"
ln="narrative"
