1:
m="ecasa ( aspirin enteric coated )" 17:0 17:5
do="325 mg" 17:6 17:7
mo="po" 17:8 17:8
f="qd" 17:9 17:9
du="nm"
r="nm"
ln="list"
2:
m="atenolol" 18:0 18:0
do="50 mg" 18:1 18:2
mo="po" 18:3 18:3
f="bid" 18:4 18:4
du="nm"
r="nm"
ln="list"
3:
m="glyburide" 19:0 19:0
do="10 mg" 19:1 19:2
mo="po" 19:3 19:3
f="bid" 19:4 19:4
du="nm"
r="nm"
ln="list"
4:
m="levothyroxine sodium" 20:0 20:1
do="75 mcg" 20:2 20:3
mo="po" 20:4 20:4
f="qd" 20:5 20:5
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin 1/150 ( 0.4 mg )" 21:0 21:5
do="1 tab" 21:6 21:7
mo="sl" 21:8 21:8
f="q5min...prn" 21:9 21:9,22:0 22:0
du="x 2 doses" 21:10 21:12
r="chest pain" 22:1 22:2
ln="list"
6:
m="plavix ( clopidogrel )" 23:0 23:3
do="75 mg" 23:4 23:5
mo="po" 23:6 23:6
f="qd" 23:7 23:7
du="nm"
r="nm"
ln="list"
7:
m="lipitor ( atorvastatin )" 24:0 24:3
do="80 mg" 24:4 24:5
mo="po" 24:6 24:6
f="qhs" 24:7 24:7
du="nm"
r="nm"
ln="list"
8:
m="lasix ( furosemide )" 26:0 26:3
do="80 mg" 26:4 26:5
mo="po" 26:6 26:6
f="qd" 26:7 26:7
du="nm"
r="nm"
ln="list"
9:
m="glucophage ( metformin )" 27:0 27:3
do="500 mg" 27:4 27:5
mo="po" 27:6 27:6
f="bid" 27:7 27:7
du="nm"
r="nm"
ln="list"
10:
m="benicar" 28:0 28:0
do="20 mg" 28:1 28:2
mo="po" 28:3 28:3
f="qd" 28:4 28:4
du="nm"
r="nm"
ln="list"
11:
m="asa" 62:3 62:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="atenolol" 62:5 62:5
do="50" 62:6 62:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="benicar" 62:8 62:8
do="20" 62:9 62:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="lipitor" 62:11 62:11
do="20" 63:0 63:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="glyburide" 63:2 63:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="metformin" 96:4 96:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="antidepressants" 100:4 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="nicotine patch" 100:6 100:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
