1:
m="acetylsalicylic acid" 19:0 19:1
do="325 mg" 19:2 19:3
mo="po" 19:4 19:4
f="bid" 19:5 19:5
du="nm"
r="costochondritis" 21:4 21:4
ln="list"
2:
m="colace ( docusate sodium )" 23:0 23:4
do="100 mg" 23:5 23:6
mo="po" 23:7 23:7
f="bid" 23:8 23:8
du="nm"
r="nm"
ln="list"
3:
m="enalapril maleate" 24:0 24:1
do="5 mg" 24:2 24:3
mo="po" 24:4 24:4
f="qd" 24:5 24:5
du="nm"
r="nm"
ln="list"
4:
m="zocor ( simvastatin )" 25:0 25:3
do="20 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qhs" 25:7 25:7
du="nm"
r="nm"
ln="list"
5:
m="insulin 70/30 ( human )" 28:0 28:4
do="60 units" 28:8 28:9
mo="sc" 28:11 28:11
f="qpm" 28:10 28:10
du="nm"
r="nm"
ln="list"
6:
m="insulin 70/30 ( human )" 28:0 28:4
do="60 units" 29:3 29:4
mo="nm"
f="qpm" 29:5 29:5
du="nm"
r="nm"
ln="list"
7:
m="insulin 70/30 ( human )" 28:0 28:4
do="80 units" 28:5 28:6
mo="nm"
f="qam;" 28:7 28:7
du="nm"
r="nm"
ln="list"
8:
m="insulin 70/30 ( human )" 28:0 28:4
do="80 units" 29:0 29:1
mo="sc" 28:11 28:11
f="qam " 29:2 29:2
du="nm"
r="nm"
ln="list"
9:
m="plavix ( clopidogrel )" 31:0 31:3
do="75 mg" 31:4 31:5
mo="po" 31:6 31:6
f="qd" 31:7 31:7
du="nm"
r="nm"
ln="list"
10:
m="psyllium" 32:0 32:0
do="2 tsp" 32:1 32:2
mo="po" 32:3 32:3
f="qd" 32:4 32:4
du="nm"
r="nm"
ln="list"
11:
m="toprol xl ( metoprolol ( sust. rel. ) )" 33:0 33:8
do="25 mg" 33:9 33:10
mo="po" 33:11 33:11
f="qd" 33:12 33:12
du="nm"
r="nm"
ln="list"
12:
m="lasix ( furosemide )" 36:0 36:3
do="20 mg" 36:4 36:5
mo="po" 36:6 36:6
f="qd" 36:7 36:7
du="nm"
r="nm"
ln="list"
13:
m="famotidine" 37:0 37:0
do="20 mg" 37:1 37:2
mo="po" 37:3 37:3
f="bid" 37:4 37:4
du="nm"
r="nm"
ln="list"
14:
m="adenosine" 57:0 57:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="ntg" 66:0 66:0
do="2" 65:13 65:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="20/enalapril" 68:4 68:4
do="5/pepcid" 68:5 68:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="20/toprol xl" 68:6 68:7
do="25/asa" 68:8 68:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="25/asa" 68:8 68:8
do="325/insulin" 69:0 69:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="5/pepcid" 68:5 68:5
do="20/toprol" 68:6 68:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="75/lasix" 68:3 68:3
do="20/enalapril" 68:4 68:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="plavix" 68:2 68:2
do="75/lasix" 68:3 68:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="325/insulin 70/30/" 69:0 69:1
do="60 units" 69:5 69:6
mo="nm"
f="pm/zocor" 69:7 69:7
du="nm"
r="nm"
ln="list"
23:
m="325/insulin 70/30/" 69:0 69:1
do="80units" 69:2 69:2
mo="nm"
f="am" 69:3 69:3
du="nm"
r="nm"
ln="list"
24:
m="pm/zocor" 69:7 69:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="adenosine" 71:9 71:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="enalapril/lasix/toprol/zocor." 72:5 72:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
