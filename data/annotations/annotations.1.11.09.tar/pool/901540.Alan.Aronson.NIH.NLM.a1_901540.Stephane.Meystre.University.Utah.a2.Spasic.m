1:
m="diuretics" 24:6 24:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="moderate mr" 23:5 23:6
ln="narrative"
2:
m="diuretics" 24:6 24:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe tr" 23:8 23:9
ln="narrative"
3:
m="dobutamine" 24:1 24:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="moderate mr" 23:5 23:6
ln="narrative"
4:
m="dobutamine" 24:1 24:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe tr" 23:8 23:9
ln="narrative"
5:
m="seretide" 24:3 24:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="moderate mr" 23:5 23:6
ln="narrative"
6:
m="seretide" 24:3 24:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="severe tr" 23:8 23:9
ln="narrative"
7:
m="ace inhibitor." 26:2 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="diuretics" 27:10 27:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="fluid retention" 27:7 27:8
ln="narrative"
9:
m="diuretics" 28:10 28:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="digoxin" 36:0 36:0
do="0.125 mg" 36:1 36:2
mo="nm"
f="q.o.d." 36:3 36:3
du="nm"
r="nm"
ln="list"
11:
m="hydralazine" 36:10 36:10
do="25 mg" 36:11 36:12
mo="nm"
f="t.i.d." 37:0 37:0
du="nm"
r="nm"
ln="list"
12:
m="imdur" 36:5 36:5
do="30 mg" 36:6 36:7
mo="nm"
f="q.d." 36:8 36:8
du="nm"
r="nm"
ln="list"
13:
m="carvedilol" 37:12 37:12
do="3.125 mg" 38:0 38:1
mo="nm"
f="b.i.d." 38:2 38:2
du="nm"
r="nm"
ln="list"
14:
m="coumadin" 37:7 37:7
do="1 mg" 37:8 37:9
mo="nm"
f="q.d." 37:10 37:10
du="nm"
r="nm"
ln="list"
15:
m="torsemide" 37:2 37:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="allopurinol" 38:4 38:4
do="100 mg" 38:5 38:6
mo="nm"
f="q.d." 38:7 38:7
du="nm"
r="nm"
ln="list"
17:
m="glucophage" 38:9 38:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="glyburide." 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="diuril" 73:4 73:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="diuretics" 74:10 74:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="dobutamine" 81:2 81:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="amiodarone" 82:4 82:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="dobutamine" 83:2 83:2
do="low dose" 83:0 83:1
mo="nm"
f="nm"
du="nm"
r="cardiac output." 83:6 83:7
ln="narrative"
24:
m="diuretics." 88:2 88:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="ionotropes" 88:0 88:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="diuretic" 89:9 89:9
do="maximal...doses" 89:8 90:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ionotropes." 90:2 90:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="dobutamine" 91:10 91:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="enhance renal perfusion" 92:5 92:7
ln="narrative"
29:
m="lasix" 92:9 92:9
do="80 mg" 93:2 93:3
mo="nm"
f="per hour." 93:4 93:5
du="nm"
r="nm"
ln="narrative"
30:
m="lasix" 92:9 92:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="dobutamine" 94:5 94:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="dobutamine" 97:0 97:0
do="between 1 and 2.5 mcg/kg/minute" 97:1 97:5
mo="nm"
f="nm"
du="nm"
r="cardiac output" 98:0 98:1
ln="narrative"
33:
m="ace inhibitors" 114:10 115:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="digoxin" 114:8 114:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
35:
m="dobutamine" 115:6 115:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="amiodarone" 119:5 119:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="dobutamine" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic af" 118:2 118:3
ln="narrative"
38:
m="dobutamine" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="occasional ectopy" 118:5 118:6
ln="narrative"
39:
m="dobutamine" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="vt" 118:8 118:8
ln="narrative"
40:
m="ceftazidime" 122:6 122:6
do="nm"
mo="nm"
f="nm"
du="six-week course" 122:3 122:4
r="complicated osteomyelitis" 123:5 123:6
ln="narrative"
41:
m="vancomycin" 122:8 122:8
do="nm"
mo="nm"
f="nm"
du="six-week course" 122:3 122:4
r="complicated osteomyelitis" 123:5 123:6
ln="narrative"
42:
m="diflucan" 123:3 123:3
do="nm"
mo="nm"
f="nm"
du="six-week course" 122:3 122:4
r="complicated osteomyelitis" 123:5 123:6
ln="narrative"
43:
m="flagyl" 123:0 123:0
do="nm"
mo="nm"
f="nm"
du="six-week course" 122:3 122:4
r="complicated osteomyelitis" 123:5 123:6
ln="narrative"
44:
m="ace inhibitors" 128:1 128:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="diuretics" 129:0 129:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="zyprexa" 144:8 144:8
do="low dose" 144:5 144:6
mo="nm"
f="in the evening." 144:9 145:0
du="nm"
r="nm"
ln="narrative"
47:
m="hydrocortisone." 148:4 148:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="hydrocortisone" 148:4 148:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="hydrocortisone" 150:6 150:6
do="maintenance doses" 150:3 150:4
mo="nm"
f="nm"
du="nm"
r="hypotension" 149:5 149:5
ln="narrative"
50:
m="hydrocortisone." 150:6 150:6
do="maintenance doses" 150:3 150:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="hypoglycemic" 152:6 152:6
do="nm"
mo="oral" 152:5 152:5
f="nm"
du="nm"
r="diabetes." 152:1 152:1
ln="narrative"
52:
m="insulin" 154:1 154:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes." 152:1 152:1
ln="narrative"
53:
m="lantus" 154:7 154:7
do="standing doses" 154:4 154:5
mo="nm"
f="nm"
du="nm"
r="diabetes." 152:1 152:1
ln="narrative"
54:
m="lispro" 154:10 154:10
do="sliding scale" 155:0 155:1
mo="nm"
f="nm"
du="nm"
r="diabetes." 152:1 152:1
ln="narrative"
55:
m="tpn" 156:7 156:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="quite severe malnutrition." 156:9 157:0
ln="narrative"
56:
m="dobutamine" 164:9 164:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
