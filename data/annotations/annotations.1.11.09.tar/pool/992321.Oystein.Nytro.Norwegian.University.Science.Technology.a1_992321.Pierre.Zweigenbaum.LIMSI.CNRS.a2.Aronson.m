1:
m="fluticasone propionate/salmeterol 250/50" 19:1 19:3
do="1 puff" 19:4 19:5
mo="inh" 19:6 19:6
f="bid" 19:7 19:7
du="nm"
r="nm"
ln="list"
2:
m="albuterol nebulizer" 20:1 20:2
do="2.5 mg" 20:3 20:4
mo="neb" 20:5 20:5
f="q4h" 20:6 20:6
du="nm"
r="nm"
ln="list"
3:
m="artificial tears" 21:1 21:2
do="2 drop" 21:3 21:4
mo="od" 21:5 21:5
f="tid" 21:6 21:6
du="nm"
r="nm"
ln="list"
4:
m="loratadine" 22:1 22:1
do="10 mg" 22:2 22:3
mo="po" 22:4 22:4
f="qd" 22:5 22:5
du="nm"
r="nm"
ln="list"
5:
m="hydrochlorothiazide" 23:1 23:1
do="25 mg" 23:2 23:3
mo="po" 23:4 23:4
f="qd" 23:5 23:5
du="nm"
r="nm"
ln="list"
6:
m="albuterol inhaler" 24:1 24:2
do="2 puff" 24:3 24:4
mo="inh" 24:5 24:5
f="qid" 24:6 24:6
du="nm"
r="nm"
ln="list"
7:
m="acetylsalicylic acid" 26:0 26:1
do="81 mg" 26:2 26:3
mo="po" 26:4 26:4
f="daily" 26:5 26:5
du="nm"
r="nm"
ln="list"
8:
m="albuterol inhaler" 27:0 27:1
do="2 puff" 27:2 27:3
mo="inh" 27:4 27:4
f="qid prn" 27:5 27:6
du="nm"
r="shortness of breath" 27:7 27:9
ln="list"
9:
m="albuterol nebulizer" 28:0 28:1
do="2.5 mg" 28:2 28:3
mo="neb" 28:4 28:4
f="q2h prn" 28:5 29:0
du="nm"
r="shortness of breath" 29:1 29:3
ln="list"
10:
m="albuterol nebulizer" 28:0 28:1
do="2.5 mg" 28:2 28:3
mo="neb" 28:4 28:4
f="q2h prn" 28:5 29:0
du="nm"
r="wheezing" 29:5 29:5
ln="list"
11:
m="atenolol" 30:0 30:0
do="50 mg" 30:1 30:2
mo="po" 30:3 30:3
f="daily" 30:4 30:4
du="nm"
r="nm"
ln="list"
12:
m="advair diskus 500/50 ( fluticasone propionate/... )" 31:0 31:6
do="1 puff" 32:0 32:1
mo="inh" 32:2 32:2
f="bid" 32:3 32:3
du="nm"
r="nm"
ln="list"
13:
m="hydrochlorothiazide" 33:0 33:0
do="25 mg" 33:1 33:2
mo="po" 33:3 33:3
f="daily" 33:4 33:4
du="nm"
r="nm"
ln="list"
14:
m="miconazole nitrate 2% powder" 34:0 34:3
do="nm"
mo="topical tp" 34:4 34:5
f="daily" 34:6 34:6
du="nm"
r="nm"
ln="list"
15:
m="nebulizer treatments." 63:5 63:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="cough" 63:1 63:1
ln="narrative"
16:
m="albuterol" 67:14 67:14
do="nm"
mo="neb" 68:0 68:0
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="asa" 67:10 67:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="labetalol" 67:8 67:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="nexium" 67:12 67:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="nitro" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="zofran" 69:0 69:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="emesis" 68:3 68:3
ln="narrative"
22:
m="hctz" 76:0 76:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="incarcerated htn" 75:1 75:2
ln="narrative"
23:
m="asa" 98:3 98:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="beta blocker" 98:6 98:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="statin" 100:0 100:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="statin" 101:5 101:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="hctz" 103:7 103:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn control" 103:1 103:2
ln="narrative"
28:
m="lopressor" 103:9 103:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="htn control" 103:1 103:2
ln="narrative"
29:
m="atenolol" 104:12 104:12
do="50mg" 104:13 104:13
mo="nm"
f="daily" 105:0 105:0
du="nm"
r="nm"
ln="narrative"
30:
m="hctz" 104:8 104:8
do="25mg" 104:9 104:9
mo="nm"
f="daily" 104:10 104:10
du="nm"
r="nm"
ln="narrative"
31:
m="advair" 108:6 108:6
do="500/50" 109:0 109:0
mo="nm"
f="bid" 109:1 109:1
du="nm"
r="a restrictive ventilatory defect from obesity." 108:0 108:5
ln="narrative"
32:
m="advair" 108:6 108:6
do="500/50" 109:0 109:0
mo="nm"
f="bid" 109:1 109:1
du="nm"
r="very mild asthma exacerbation" 107:7 107:10
ln="narrative"
33:
m="advair" 108:6 108:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="nebs atc" 109:5 109:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="very mild asthma exacerbation" 107:7 107:10
ln="narrative"
35:
m="prednisone" 109:8 109:8
do="60mg" 109:9 109:9
mo="nm"
f="qd" 109:10 109:10
du="x 3 doses" 109:11 109:13
r="very mild asthma exacerbation" 107:7 107:10
ln="narrative"
36:
m="prednisone" 109:8 109:8
do="60mg" 109:9 109:9
mo="nm"
f="qd x 3 doses" 109:10 109:13
du="nm"
r="nm"
ln="narrative"
37:
m="lovenox" 117:2 117:2
do="nm"
mo="nm"
f="bid" 117:3 117:3
du="nm"
r="weight" 117:6 117:6
ln="narrative"
38:
m="atenolol" 118:9 118:9
do="50mg" 118:10 118:10
mo="nm"
f="daily" 118:11 118:11
du="nm"
r="your blood pressure." 118:13 119:1
ln="narrative"
39:
m="hydrochlorothiazide" 118:5 118:5
do="25mg" 118:6 118:6
mo="nm"
f="daily" 118:7 118:7
du="nm"
r="your blood pressure." 118:13 119:1
ln="narrative"
40:
m="aspirin" 119:6 119:6
do="81mg" 119:7 119:7
mo="nm"
f="daily." 119:8 119:8
du="nm"
r="nm"
ln="list"
41:
m="statin" 131:3 131:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
