1:
m="penicillin" 32:9 32:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="nifedipine." 40:6 40:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="intermittent hypertension" 39:9 40:0
ln="narrative"
3:
m="captopril" 42:8 42:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hypertension" 43:3 43:4
ln="narrative"
4:
m="nifedipine" 42:6 42:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="his hypertension" 43:3 43:4
ln="narrative"
5:
m="cefotetan" 44:0 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="presumed aspiration pneumonia" 44:2 44:4
ln="narrative"
6:
m="antibiotics" 51:1 51:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="his presumed aspiration pneumonia" 51:3 51:6
ln="narrative"
7:
m="kefzol" 62:2 62:2
do="500mg" 62:3 62:3
mo="nm"
f="q.i.d." 62:4 62:4
du="for 3 days" 62:5 62:7
r="nm"
ln="list"
8:
m="lisinopril" 62:10 62:10
do="10mg" 62:11 62:11
mo="p.o." 63:0 63:0
f="q day." 63:1 63:2
du="nm"
r="nm"
ln="list"
