1:
m="mycophenolate mofetil" 19:1 19:2
do="1000 mg" 19:3 19:4
mo="po" 19:5 19:5
f="bid" 19:6 19:6
du="nm"
r="nm"
ln="list"
2:
m="oxybutynin chloride xl" 20:1 20:3
do="10 mg" 20:4 20:5
mo="po" 20:6 20:6
f="qd" 20:7 20:7
du="nm"
r="nm"
ln="list"
3:
m="insulin glargine" 21:1 21:2
do="20 units" 21:3 21:4
mo="sc" 21:5 21:5
f="qam" 21:6 21:6
du="nm"
r="nm"
ln="list"
4:
m="furosemide" 22:1 22:1
do="nm"
mo="po" 22:2 22:2
f="qd" 22:3 22:3
du="nm"
r="nm"
ln="list"
5:
m="clopidogrel" 23:1 23:1
do="75 mg" 23:2 23:3
mo="po" 23:4 23:4
f="qd" 23:5 23:5
du="nm"
r="nm"
ln="list"
6:
m="pravastatin" 24:1 24:1
do="40 mg" 24:2 24:3
mo="po" 24:4 24:4
f="qhs" 24:5 24:5
du="nm"
r="nm"
ln="list"
7:
m="prednisone" 25:1 25:1
do="5 mg" 25:2 25:3
mo="po" 25:4 25:4
f="qd" 25:5 25:5
du="nm"
r="nm"
ln="list"
8:
m="cyclosporine ( sandimmune )" 26:1 26:4
do="75 mg" 26:5 26:6
mo="po" 26:7 26:7
f="bid" 26:8 26:8
du="nm"
r="nm"
ln="list"
9:
m="metoprolol succinate extended release" 27:1 27:4
do="50 mg" 27:5 27:6
mo="po" 27:7 27:7
f="qd" 27:8 27:8
du="nm"
r="nm"
ln="list"
10:
m="fenofibrate ( tricor )" 28:1 28:4
do="48 mg" 28:5 28:6
mo="po" 28:7 28:7
f="qd" 28:8 28:8
du="nm"
r="nm"
ln="list"
11:
m="enteric coated asa" 30:0 30:2
do="325 mg" 30:3 30:4
mo="po" 30:5 30:5
f="daily" 30:6 30:6
du="nm"
r="nm"
ln="list"
12:
m="plavix ( clopidogrel )" 31:0 31:3
do="75 mg" 31:4 31:5
mo="po" 31:6 31:6
f="daily" 31:7 31:7
du="nm"
r="nm"
ln="list"
13:
m="cyclosporine ( sandimmune )" 33:0 33:3
do="75 mg" 33:4 33:5
mo="po" 33:6 33:6
f="bid" 33:7 33:7
du="nm"
r="nm"
ln="list"
14:
m="tricor" 37:18 37:18
do="nm"
mo="po" 37:19 37:19
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="cyclosporine" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="fenofibrate , micronized" 39:0 39:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="micronized" 39:2 39:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="home meds" 40:1 40:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="pravastatin sodium" 42:3 42:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="cyclosporine" 43:0 43:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="home meds" 43:5 43:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="tricor ( fenofibrate ( tricor ) )" 44:0 44:6
do="48 mg" 44:7 44:8
mo="po" 44:9 44:9
f="daily" 44:10 44:10
du="nm"
r="nm"
ln="list"
23:
m="pravastatin sodium" 46:3 46:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
24:
m="fenofibrate , micronized" 47:0 47:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="cyclosporine" 48:3 48:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
26:
m="fenofibrate , micronized" 49:0 49:2
do="nm"
mo="nm"
f="nm"
du="number of doses required ( approximate ): 4" 50:3 50:10
r="nm"
ln="list"
27:
m="lasix ( furosemide )" 51:0 51:3
do="40 mg" 51:4 51:5
mo="po" 51:6 51:6
f="daily" 51:7 51:7
du="nm"
r="nm"
ln="list"
28:
m="insulin glargine" 52:0 52:1
do="20 units" 52:2 52:3
mo="sc" 52:4 52:4
f="daily" 52:5 52:5
du="nm"
r="nm"
ln="list"
29:
m="toprol xl ( metoprolol succinate extended release )" 53:0 53:7
do="50 mg" 54:0 54:1
mo="po" 54:2 54:2
f="daily" 54:3 54:3
du="number of doses required (approximate): 3" 56:0 56:7
r="nm"
ln="list"
30:
m="cellcept ( mycophenolate mofetil )" 57:0 57:4
do="1 , 000 mg" 57:5 57:8
mo="po" 57:9 57:9
f="bid" 57:10 57:10
du="nm"
r="nm"
ln="list"
31:
m="tng 0.4 mg ( nitroglycerin 1/150 ( 0.4 mg ) )" 61:0 61:10
do="1 tab" 62:0 62:1
mo="sl" 62:2 62:2
f="q5min x 3 doses prn" 62:3 62:7
du="nm"
r="chest pain" 62:8 62:9
ln="list"
32:
m="ditropan xl ( oxybutynin chloride xl )" 63:0 63:6
do="3 doses" 62:5 62:6
mo="nm"
f="prn" 62:7 62:7
du="number of doses required (approximate): 3" 64:0 64:7
r="nm"
ln="list"
33:
m="pravachol ( pravastatin )" 65:0 65:3
do="40 mg" 65:4 65:5
mo="po" 65:6 65:6
f="bedtime" 65:7 65:7
du="nm"
r="nm"
ln="list"
34:
m="tricor" 68:18 68:18
do="nm"
mo="po" 68:19 68:19
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="pravastatin sodium" 69:3 69:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="fenofibrate , micronized" 70:0 70:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="home meds" 71:1 71:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="cyclosporine ( sandimmune )" 73:3 73:6
do="nm"
mo="po" 73:7 73:7
f="nm"
du="nm"
r="nm"
ln="list"
39:
m="pravastatin sodium" 75:3 75:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="cyclosporine" 76:0 76:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="home meds" 76:5 76:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="pravachol" 79:3 79:3
do="nm"
mo="po" 79:4 79:4
f="nm"
du="nm"
r="nm"
ln="list"
43:
m="prednisolone sodium phosphate 5mg/5ml" 82:0 82:3
do="5 mg" 82:4 82:5
mo="po" 82:6 82:6
f="daily" 82:7 82:7
du="nm"
r="nm"
ln="list"
44:
m="cellcept" 110:1 110:1
do="1000 mg" 110:2 110:3
mo="p.o." 110:4 110:4
f="b.i.d." 110:5 110:5
du="nm"
r="nm"
ln="list"
45:
m="prednisone" 110:7 110:7
do="5 mg" 110:8 110:9
mo="nm"
f="daily" 111:0 111:0
du="nm"
r="nm"
ln="list"
46:
m="cyclosporine" 111:2 111:2
do="75mg" 111:3 111:4
mo="p.o." 111:5 111:5
f="b.i.d." 111:6 111:6
du="nm"
r="nm"
ln="list"
47:
m="toprol-xl" 111:8 111:8
do="50 mg" 111:9 111:10
mo="nm"
f="daily" 111:11 111:11
du="nm"
r="nm"
ln="list"
48:
m="tricor" 111:13 111:13
do="nm"
mo="nm"
f="once daily" 112:0 112:1
du="nm"
r="nm"
ln="list"
49:
m="lasix" 112:13 112:13
do="40 mg" 112:15 112:16
mo="nm"
f="daily" 113:0 113:0
du="nm"
r="nm"
ln="list"
50:
m="plavix" 112:8 112:8
do="75 mg" 112:9 112:10
mo="nm"
f="daily" 112:11 112:11
du="nm"
r="nm"
ln="list"
51:
m="pravachol" 112:3 112:3
do="40 mg" 112:4 112:5
mo="nm"
f="daily" 112:6 112:6
du="nm"
r="nm"
ln="list"
52:
m="aspirin" 113:4 113:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
53:
m="ditropan" 113:6 113:6
do="10 mg" 113:7 113:8
mo="nm"
f="daily" 113:9 113:9
du="nm"
r="nm"
ln="list"
54:
m="insulin" 113:2 113:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
55:
m="vitamins." 114:0 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
56:
m="asa" 146:9 146:9
do="325" 146:10 146:10
mo="nm"
f="daily" 146:11 146:11
du="nm"
r="nm"
ln="narrative"
57:
m="plavix" 147:0 147:0
do="75" 147:1 147:1
mo="nm"
f="daily" 147:2 147:2
du="for minimum of 12 months" 147:3 147:7
r="nm"
ln="narrative"
58:
m="tng" 148:8 148:8
do="nm"
mo="sl" 148:7 148:7
f="prn" 148:9 148:9
du="nm"
r="chest pain" 148:10 149:0
ln="narrative"
59:
m="lasix" 152:12 152:12
do="40." 152:13 152:13
mo="nm"
f="nm"
du="nm"
r="bp" 152:1 152:1
ln="narrative"
60:
m="toprol xl" 152:8 152:9
do="50" 152:10 152:10
mo="nm"
f="nm"
du="nm"
r="bp" 152:1 152:1
ln="narrative"
61:
m="pravachol" 153:3 153:3
do="40" 153:4 153:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="tricor" 153:6 153:6
do="48." 153:7 153:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="insulin" 158:7 158:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="aspirin" 164:5 164:5
do="nm"
mo="nm"
f="nm"
du="for life" 164:6 164:7
r="nm"
ln="narrative"
65:
m="aspirin" 165:13 165:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="plavix" 165:3 165:3
do="nm"
mo="nm"
f="nm"
du="for a minimum of 1 year-" 165:4 165:9
r="nm"
ln="narrative"
67:
m="plavix" 166:0 166:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
68:
m="other medications" 167:1 167:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
