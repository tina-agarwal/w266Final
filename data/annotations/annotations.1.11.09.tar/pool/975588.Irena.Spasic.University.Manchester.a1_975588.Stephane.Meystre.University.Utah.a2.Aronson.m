1:
m="ecasa (aspirin enteric coated)" 14:0 14:5
do="81 mg" 14:6 14:7
mo="po" 14:8 14:8
f="3x/week m-w-f" 14:9 14:10
du="nm"
r="nm"
ln="list"
2:
m="ecasa" 17:3 17:3
do="nm"
mo="po" 17:4 17:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 20:0 20:0
do="1.25 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
4:
m="potassium chloride" 23:3 23:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lisinopril" 24:0 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="plavix (clopidogrel)" 25:0 25:3
do="75 mg" 25:4 25:5
mo="po" 25:6 25:6
f="qd" 25:7 25:7
du="nm"
r="nm"
ln="list"
7:
m="atenolol" 26:0 26:0
do="50 mg" 26:1 26:2
mo="po" 26:3 26:3
f="qd" 26:4 26:4
du="nm"
r="nm"
ln="list"
8:
m="lipitor (atorvastatin)" 27:0 27:3
do="40 mg" 27:4 27:5
mo="po" 27:6 27:6
f="qd" 27:7 27:7
du="nm"
r="nm"
ln="list"
9:
m="glyburide" 28:0 28:0
do="1.25 mg" 28:1 28:2
mo="po" 28:3 28:3
f="qd" 28:4 28:4
du="nm"
r="nm"
ln="list"
10:
m="oxycodone" 72:6 72:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 72:1 72:1
ln="narrative"
