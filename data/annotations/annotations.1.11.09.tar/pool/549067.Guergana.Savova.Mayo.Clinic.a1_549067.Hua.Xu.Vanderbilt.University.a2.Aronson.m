1:
m="coumadin" 13:7 13:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 13:4 13:5
ln="narrative"
2:
m="avandia" 19:0 19:0
do="4 mg" 19:1 19:2
mo="nm"
f="b.i.d." 19:3 19:3
du="nm"
r="nm"
ln="list"
3:
m="hytrin" 19:10 19:10
do="one" 19:11 19:11
mo="nm"
f="q.h.s." 19:12 19:12
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 19:5 19:5
do="20 mg" 19:6 19:7
mo="nm"
f="b.i.d." 19:8 19:8
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 20:10 20:10
do="50 mg" 20:11 20:12
mo="nm"
f="b.i.d." 20:13 20:13
du="nm"
r="nm"
ln="list"
6:
m="lasix" 20:0 20:0
do="80 mg" 20:1 20:2
mo="nm"
f="x1" 20:3 20:3
du="nm"
r="nm"
ln="list"
7:
m="spironolactone" 20:5 20:5
do="25 mg" 20:6 20:7
mo="nm"
f="x3" 20:8 20:8
du="nm"
r="nm"
ln="list"
8:
m="bextra" 21:7 21:7
do="10 mg" 21:8 21:9
mo="nm"
f="x1" 21:10 21:10
du="nm"
r="nm"
ln="list"
9:
m="flovent" 21:5 21:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="lipitor" 21:0 21:0
do="10 mg" 21:1 21:2
mo="nm"
f="x1" 21:3 21:3
du="nm"
r="nm"
ln="list"
11:
m="nexium" 21:12 21:12
do="20 mg" 21:13 21:14
mo="nm"
f="x1" 21:15 21:15
du="nm"
r="nm"
ln="list"
12:
m="baby aspirin" 22:10 22:11
do="81 mg" 22:12 22:13
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="coumadin" 22:5 22:5
do="5 mg" 22:6 22:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="humulin" 22:0 22:0
do="22 units" 22:1 22:2
mo="nm"
f="q.a.m." 22:3 22:3
du="nm"
r="nm"
ln="list"
15:
m="coumadin" 43:6 43:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="baby aspirin" 44:10 44:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="oxygen" 50:0 50:0
do="2 liters" 50:1 50:2
mo="nasal cannula" 50:3 50:4
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="atenolol" 52:7 52:7
do="50 mg" 52:8 52:9
mo="nm"
f="b.i.d." 52:10 52:10
du="nm"
r="nm"
ln="narrative"
19:
m="lasix" 58:5 58:5
do="80 mg" 58:6 58:7
mo="nm"
f="x1" 58:8 58:8
du="nm"
r="nm"
ln="narrative"
20:
m="spironolactone" 58:10 58:10
do="25 mg" 58:11 58:12
mo="nm"
f="b.i.d." 59:0 59:0
du="nm"
r="nm"
ln="narrative"
21:
m="coumadin" 62:2 62:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="baby aspirin" 63:9 63:10
do="81 mg" 63:13 64:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="coumadin" 63:2 63:2
do="2.5 mg" 63:3 63:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="heparin" 64:6 64:6
do="nm"
mo="subcutaneous" 64:5 64:5
f="b.i.d." 64:7 64:7
du="nm"
r="dvt" 65:1 65:1
ln="narrative"
25:
m="potassium" 68:4 68:4
do="20 mg" 68:1 68:2
mo="p.o." 68:3 68:3
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="flovent" 70:8 70:8
do="220" 71:0 71:0
mo="inh" 71:2 71:2
f="x2" 71:3 71:3
du="nm"
r="nm"
ln="list"
27:
m="heparin" 71:12 71:12
do="5000 units" 71:13 72:0
mo="subcutaneous" 71:11 71:11
f="b.i.d." 72:1 72:1
du="nm"
r="nm"
ln="list"
28:
m="pepcid" 71:5 71:5
do="20 mg" 71:7 71:8
mo="p.o." 71:6 71:6
f="b.i.d." 71:9 71:9
du="nm"
r="nm"
ln="list"
29:
m="atenolol" 72:3 72:3
do="50" 72:4 72:4
mo="nm"
f="x2" 72:5 72:5
du="nm"
r="nm"
ln="list"
30:
m="seroquel" 72:9 72:9
do="25 mg" 72:10 72:11
mo="p.o." 72:13 72:13
f="x1" 72:12 72:12
du="nm"
r="nm"
ln="list"
31:
m="insulin" 73:0 73:0
do="scale" 73:1 73:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="lasix" 73:3 73:3
do="80 mg" 73:4 73:5
mo="p.o." 73:6 73:6
f="q.d." 73:7 73:7
du="nm"
r="nm"
ln="list"
33:
m="spironolactone" 73:9 73:9
do="25 mg" 73:10 73:11
mo="nm"
f="b.i.d." 74:0 74:0
du="nm"
r="nm"
ln="list"
34:
m="baby aspirin" 74:7 74:8
do="80 mg" 74:9 74:10
mo="p.o." 74:11 74:11
f="p.r.n." 74:12 74:12
du="nm"
r="nm"
ln="list"
35:
m="simvastatin" 74:2 74:2
do="10 mg" 74:3 74:4
mo="nm"
f="x1" 74:5 74:5
du="nm"
r="nm"
ln="list"
36:
m="albuterol" 75:2 75:2
do="2.5 mg" 75:4 75:5
mo="nm"
f="q.12h." 75:6 75:6
du="nm"
r="nm"
ln="list"
37:
m="zofran" 75:11 75:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nausea" 75:13 75:13
ln="list"
38:
m="humulin" 79:6 79:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="glucose control" 79:9 79:10
ln="narrative"
39:
m="coumadin" 81:1 81:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 80:7 80:7
ln="narrative"
