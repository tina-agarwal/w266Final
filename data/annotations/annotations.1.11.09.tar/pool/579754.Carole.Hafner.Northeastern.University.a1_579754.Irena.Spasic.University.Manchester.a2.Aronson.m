1:
m="aspirin" 26:6 26:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="atenolol." 26:8 26:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="iron supplementation" 36:3 36:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="iron supplements" 37:11 37:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="prednisone" 43:10 43:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="ventolin inhalers" 44:2 44:3
do="nm"
mo="nm"
f="p.r.n." 44:4 44:4
du="nm"
r="nm"
ln="narrative"
7:
m="linsinopril" 51:6 51:6
do="5 mg" 51:7 51:8
mo="nm"
f="q.d.;" 51:9 51:9
du="nm"
r="nm"
ln="list"
8:
m="pravachol" 52:0 52:0
do="20 mg" 52:1 52:2
mo="nm"
f="q.h.s.;" 52:3 52:3
du="nm"
r="nm"
ln="list"
9:
m="aspirin" 53:0 53:0
do="325 mg" 53:1 53:2
mo="nm"
f="q. day;" 53:3 53:4
du="nm"
r="nm"
ln="list"
10:
m="atenolol" 53:5 53:5
do="0.5 mg" 53:6 53:7
mo="nm"
f="b.i.d.;" 53:8 53:8
du="nm"
r="nm"
ln="list"
11:
m="dilantin" 53:9 53:9
do="200 mg" 53:10 53:11
mo="nm"
f="b.i.d.;" 54:0 54:0
du="nm"
r="nm"
ln="list"
12:
m="ferrous gluconate" 54:4 54:5
do="325 mg" 54:6 54:7
mo="nm"
f="t.i.d." 54:8 54:8
du="nm"
r="nm"
ln="list"
13:
m="ventolin inhaler" 54:1 54:2
do="nm"
mo="nm"
f="p.r.n.;" 54:3 54:3
du="nm"
r="nm"
ln="list"
14:
m="aspirin" 91:3 91:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="atenolol" 91:8 91:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="linsinopril" 91:5 91:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="nitrol paste." 91:1 91:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="packed red cells" 93:10 93:12
do="one unit" 93:7 93:8
mo="nm"
f="nm"
du="nm"
r="her ischemia" 93:0 93:1
ln="narrative"
19:
m="albuterol inhale" 95:3 95:4
do="nm"
mo="nm"
f="p.r.n." 95:7 95:7
du="nm"
r="nm"
ln="narrative"
20:
m="nebulizers" 95:6 95:6
do="nm"
mo="nm"
f="p.r.n." 95:7 95:7
du="nm"
r="nm"
ln="narrative"
21:
m="morphine" 102:10 102:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="nitroglycerin" 103:4 103:4
do="nm"
mo="drip" 103:5 103:5
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="ticlid" 127:8 127:8
do="250 mg" 127:9 127:10
mo="p.o." 128:0 128:0
f="b.i.d.;" 128:1 128:1
du="nm"
r="nm"
ln="narrative"
24:
m="albuterol inhaler" 128:2 128:3
do="2 puffs" 128:4 128:5
mo="nm"
f="q.i.d. as needed" 128:6 128:8
du="nm"
r="shortness of breath;" 129:0 129:2
ln="narrative"
25:
m="enteric-coated aspirin" 129:3 129:4
do="325 mg" 129:5 129:6
mo="p.o." 129:7 129:7
f="q.d.;" 129:8 129:8
du="nm"
r="nm"
ln="narrative"
26:
m="atenolol" 130:0 130:0
do="37.5 mg" 130:1 130:2
mo="p.o." 130:3 130:3
f="b.i.d." 130:4 130:4
du="nm"
r="nm"
ln="narrative"
27:
m="nitroglycerin 1/150" 130:5 130:6
do="one tablet" 130:8 131:0
mo="sublingual" 130:7 130:7
f="q. 5 minutes times three" 131:1 131:5
du="nm"
r="chest pain;" 131:7 131:8
ln="narrative"
28:
m="dilantin" 131:10 131:10
do="200 mg" 131:11 131:12
mo="p.o." 132:0 132:0
f="b.i.d." 132:1 132:1
du="nm"
r="nm"
ln="narrative"
