1:
m="nitroglycerin" 46:9 46:9
do="one" 46:7 46:7
mo="sublingual" 46:8 46:8
f="nm"
du="nm"
r="pain" 47:3 47:3
ln="narrative"
2:
m="nitroglycerin" 48:0 48:0
do="one" 47:10 47:10
mo="sublingual" 47:11 47:11
f="nm"
du="nm"
r="pain" 49:0 49:0
ln="narrative"
3:
m="coumadin" 72:7 72:7
do="5 milligrams" 73:0 73:1
mo="nm"
f="q.d." 73:2 73:2
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 73:4 73:4
do="25 milligrams" 73:5 73:6
mo="nm"
f="q.d." 73:7 73:7
du="nm"
r="nm"
ln="list"
5:
m="mitozalone" 73:9 73:9
do="5 milligrams" 74:0 74:1
mo="nm"
f="q.d." 74:2 74:2
du="nm"
r="nm"
ln="list"
6:
m="atorvastatin" 74:9 74:9
do="20 milligrams" 75:0 75:1
mo="nm"
f="q.h.s." 75:2 75:2
du="nm"
r="nm"
ln="list"
7:
m="lasix" 74:4 74:4
do="160 milligrams" 74:5 74:6
mo="nm"
f="q.d." 74:7 74:7
du="nm"
r="nm"
ln="list"
8:
m="k-dur" 75:4 75:4
do="60 meq" 75:5 75:6
mo="nm"
f="q.d." 75:7 75:7
du="nm"
r="nm"
ln="list"
9:
m="rezulin" 75:9 75:9
do="400" 75:10 75:10
mo="nm"
f="q.d." 75:11 75:11
du="nm"
r="nm"
ln="list"
10:
m="nph" 76:1 76:1
do="10" 76:5 76:5
mo="nm"
f="q.p.m." 76:6 76:6
du="nm"
r="nm"
ln="list"
11:
m="nph" 76:1 76:1
do="34" 76:2 76:2
mo="nm"
f="q.a.m." 76:3 76:3
du="nm"
r="nm"
ln="list"
12:
m="regular insulin" 76:8 76:9
do="4" 76:10 76:10
mo="nm"
f="q.p.m." 76:11 76:11
du="nm"
r="nm"
ln="list"
13:
m="colchicine" 77:4 77:4
do="0.6 milligrams" 77:5 77:6
mo="nm"
f="p.r.n." 77:7 77:7
du="nm"
r="nm"
ln="list"
14:
m="finasteride" 77:0 77:0
do="5" 77:1 77:1
mo="nm"
f="q.d." 77:2 77:2
du="nm"
r="nm"
ln="list"
15:
m="aspirin" 78:0 78:0
do="81 milligrams" 78:1 78:2
mo="nm"
f="q.d." 78:3 78:3
du="nm"
r="nm"
ln="list"
16:
m="restoril" 78:5 78:5
do="30 milligrams" 78:6 78:7
mo="nm"
f="p.r.n." 78:8 78:8
du="nm"
r="nm"
ln="list"
17:
m="aspirin" 123:10 123:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="plavix" 123:5 123:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="coumadin" 124:2 124:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="heparin" 124:7 124:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="tng" 125:0 125:0
do="nm"
mo="intravenous" 124:9 124:9
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="atenolol" 127:9 127:9
do="25 milligrams" 127:10 128:0
mo="nm"
f="q.d." 128:1 128:1
du="nm"
r="nm"
ln="narrative"
23:
m="cozaar" 128:6 128:6
do="25 milligrams" 128:7 128:8
mo="nm"
f="q.d." 128:9 128:9
du="nm"
r="nm"
ln="narrative"
24:
m="amlodipine" 134:4 134:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="lasix" 135:5 135:5
do="160 milligrams" 135:6 135:7
mo="nm"
f="q.a.m" 135:8 135:8
du="nm"
r="nm"
ln="narrative"
26:
m="mitozalone" 136:0 136:0
do="5" 136:1 136:1
mo="nm"
f="q.d." 136:2 136:2
du="nm"
r="nm"
ln="narrative"
27:
m="lasix" 141:0 141:0
do="100 milligrams" 141:1 141:2
mo="intravenous" 141:3 141:3
f="p.r.n." 141:4 141:4
du="nm"
r="nm"
ln="narrative"
28:
m="lasix" 141:0 141:0
do="160 milligrams" 142:2 142:3
mo="nm"
f="q.a.m." 142:4 142:4
du="nm"
r="nm"
ln="narrative"
29:
m="normal saline ... fluids" 142:10 142:11,143:1 143:1
do="nm"
mo="intravenous" 143:0 143:0
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="k-dur" 148:2 148:2
do="60 meq" 148:4 148:5
mo="nm"
f="q.d." 148:6 148:6
du="nm"
r="nm"
ln="narrative"
31:
m="k-dur" 150:8 150:8
do="his outpatient dose" 150:4 150:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="magnesium" 152:3 152:3
do="a standing dose" 151:10 152:1
mo="nm"
f="nm"
du="nm"
r="his magnesium" 152:5 152:6
ln="narrative"
33:
m="nph 30/10" 158:10 159:0
do="4 regular" 159:2 159:3
mo="nm"
f="q.p.m." 159:4 159:4
du="nm"
r="diabetes:" 158:1 158:1
ln="narrative"
34:
m="nph 30/10" 158:10 159:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes:" 158:1 158:1
ln="narrative"
35:
m="rezulin" 159:7 159:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="finasteride" 161:7 161:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="benign prostatic hypertrophy" 161:9 162:1
ln="narrative"
37:
m="ciprofloxacin" 164:3 164:3
do="500 milligrams" 164:4 164:5
mo="nm"
f="b.i.d." 164:6 164:6
du="for thirty days." 164:7 165:1
r="chronic prostatitis." 163:4 163:5
ln="narrative"
38:
m="ciprofloxacin" 165:8 165:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="levofloxacin" 166:3 166:3
do="500 milligrams" 166:4 166:5
mo="nm"
f="q.d." 166:6 166:6
du="nm"
r="nm"
ln="narrative"
40:
m="colchicine" 173:0 173:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="prednisone" 173:11 173:11
do="40 milligrams" 174:3 174:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="cozaar" 181:2 181:2
do="25 milligrams" 181:3 181:4
mo="nm"
f="q.d." 181:5 181:5
du="nm"
r="nm"
ln="list"
43:
m="restoril" 181:7 181:7
do="30 milligrams" 181:8 182:0
mo="nm"
f="q.d. q.h.s. p.r.n." 182:1 182:3
du="nm"
r="nm"
ln="list"
44:
m="nitroglycerin" 182:5 182:5
do="0.4 milligrams" 182:6 182:7
mo="sublingual" 183:4 183:4
f="p.r.n....times three q.5 minutes." 183:0 183:0,183:8 183:11
du="nm"
r="chest pain" 183:1 183:2
ln="list"
45:
m="nph" 184:7 184:7
do="10 units" 184:11 184:12
mo="nm"
f="q.p.m." 185:0 185:0
du="nm"
r="nm"
ln="list"
46:
m="nph" 184:7 184:7
do="34 units" 184:8 184:9
mo="nm"
f="q.a.m." 184:10 184:10
du="nm"
r="nm"
ln="list"
47:
m="regular insulin" 184:1 184:2
do="4 units" 184:3 184:4
mo="nm"
f="q.p.m." 184:5 184:5
du="nm"
r="nm"
ln="list"
48:
m="aspirin" 185:7 185:7
do="81 milligrams" 185:8 185:9
mo="nm"
f="q.d." 186:0 186:0
du="nm"
r="nm"
ln="list"
49:
m="rezulin" 185:2 185:2
do="400 milligrams" 185:3 185:4
mo="nm"
f="q.d." 185:5 185:5
du="nm"
r="nm"
ln="list"
50:
m="clopidogrel" 186:7 186:7
do="75 milligrams" 186:8 186:9
mo="nm"
f="q.d." 187:0 187:0
du="nm"
r="nm"
ln="list"
51:
m="coumadin" 186:2 186:2
do="5 milligrams" 186:3 186:4
mo="nm"
f="q.d." 186:5 186:5
du="nm"
r="nm"
ln="list"
52:
m="colchicine" 187:8 187:8
do="0.6 milligrams" 187:9 188:0
mo="nm"
f="p.r.n." 188:1 188:1
du="nm"
r="nm"
ln="list"
53:
m="magnesium oxide" 187:2 187:3
do="280 milligrams" 187:4 187:5
mo="nm"
f="q.d." 187:6 187:6
du="nm"
r="nm"
ln="list"
54:
m="k-dur" 188:3 188:3
do="60 meq" 188:4 188:5
mo="nm"
f="q.d." 188:6 188:6
du="nm"
r="nm"
ln="list"
55:
m="lasix" 188:8 188:8
do="160 milligrams" 188:9 189:0
mo="nm"
f="q.d." 189:1 189:1
du="nm"
r="nm"
ln="list"
56:
m="atenolol" 189:8 189:8
do="25 milligrams" 190:0 190:1
mo="nm"
f="q.d." 190:2 190:2
du="nm"
r="nm"
ln="list"
57:
m="mitozalone" 189:3 189:3
do="5 milligrams" 189:4 189:5
mo="nm"
f="q.d." 189:6 189:6
du="nm"
r="nm"
ln="list"
58:
m="atorvastatin" 190:4 190:4
do="20 milligrams" 190:5 190:6
mo="nm"
f="q.h.s." 190:7 190:7
du="nm"
r="nm"
ln="list"
59:
m="ciprofloxacin" 191:5 191:5
do="500 milligrams" 191:6 191:7
mo="nm"
f="b.i.d." 192:0 192:0
du="nm"
r="nm"
ln="list"
60:
m="finasteride" 191:0 191:0
do="5 milligrams" 191:1 191:2
mo="nm"
f="q.d." 191:3 191:3
du="nm"
r="nm"
ln="list"
