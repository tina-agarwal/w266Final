1:
m="amlodipine" 38:7 38:7
do="10 mg" 38:8 38:9
mo="p.o." 38:10 38:10
f="daily" 38:11 38:11
du="nm"
r="nm"
ln="list"
2:
m="labetalol" 38:0 38:0
do="100 mg" 38:2 38:3
mo="p.o." 38:4 38:4
f="t.i.d." 38:5 38:5
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 39:0 39:0
do="20 mg" 39:2 39:3
mo="p.o." 39:4 39:4
f="day" 39:5 39:5
du="nm"
r="nm"
ln="list"
4:
m="phoslo" 39:13 39:13
do="1334 mg" 39:14 40:0
mo="p.o." 40:1 40:1
f="a.c." 40:2 40:2
du="nm"
r="nm"
ln="list"
5:
m="zocor" 39:7 39:7
do="40 mg" 39:8 39:9
mo="p.o." 39:10 39:10
f="daily" 39:11 39:11
du="nm"
r="nm"
ln="list"
6:
m="gentamicin" 103:7 103:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
7:
m="rifampin" 103:4 103:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="vancomycin" 103:2 103:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="gentamicin" 104:9 104:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="rifampin" 105:8 105:8
do="nm"
mo="nm"
f="nm"
du="until 1/3/04." 105:9 106:0
r="nm"
ln="narrative"
11:
m="vancomycin" 105:6 105:6
do="nm"
mo="nm"
f="nm"
du="until 1/3/04." 105:9 106:0
r="nm"
ln="narrative"
12:
m="rifampin" 106:2 106:2
do="nm"
mo="orally" 106:6 106:6
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="vancomycin" 106:9 106:9
do="nm"
mo="nm"
f="three times a week" 107:4 107:7
du="nm"
r="nm"
ln="narrative"
14:
m="labetalol" 111:7 111:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="labetalol" 120:0 120:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="aspirin" 124:9 124:9
do="325 mg" 125:0 125:1
mo="p.o." 125:2 125:2
f="daily" 125:3 125:3
du="nm"
r="nm"
ln="list"
17:
m="hydralazine" 125:5 125:5
do="100 mg" 125:6 125:7
mo="p.o." 125:8 125:8
f="q.i.d." 125:9 125:9
du="nm"
r="nm"
ln="list"
18:
m="labetalol100" 125:11 125:11
do="nm"
mo="p.o." 126:1 126:1
f="t.i.d." 126:2 126:2
du="nm"
r="nm"
ln="list"
19:
m="lisinopril" 126:4 126:4
do="40 mg" 126:5 126:6
mo="p.o." 126:7 126:7
f="b.i.d." 126:8 126:8
du="nm"
r="nm"
ln="list"
20:
m="oxycodone" 126:10 126:10
do="5 mg" 126:11 126:12
mo="p.o." 126:13 126:13
f="6 hours p.r.n." 127:0 127:2
du="nm"
r="pain" 127:3 127:3
ln="list"
21:
m="rifampin" 127:5 127:5
do="300 mg" 127:6 127:7
mo="p.o." 127:8 127:8
f="q.8h." 127:9 127:9
du="nm"
r="nm"
ln="list"
22:
m="vancomycin" 127:11 127:11
do="nm"
mo="nm"
f="nm"
du="until 5/14/05" 128:6 128:7
r="nm"
ln="list"
23:
m="zocor" 128:9 128:9
do="40 mg" 128:10 129:0
mo="p.o." 129:1 129:1
f="q.h.s." 129:2 129:2
du="nm"
r="nm"
ln="list"
24:
m="losartan" 129:4 129:4
do="100 mg" 129:5 129:6
mo="p.o." 129:7 129:7
f="daily" 129:8 129:8
du="nm"
r="nm"
ln="list"
