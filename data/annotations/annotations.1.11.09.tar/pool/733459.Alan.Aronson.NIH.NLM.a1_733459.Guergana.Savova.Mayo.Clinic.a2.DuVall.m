1:
m="analgesic" 23:3 23:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="clonazepam" 24:0 24:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="imuran" 34:6 34:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="iron sulfate" 34:10 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="phoslo" 34:8 34:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="vitamin c" 34:3 34:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="aranesp" 35:6 35:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="coumadin" 35:4 35:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="deltasone" 35:2 35:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="dilaudid" 35:8 35:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 35:10 35:10
ln="list"
11:
m="ambien" 36:9 36:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="sleep" 36:11 36:11
ln="list"
12:
m="lactulose" 36:0 36:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="reglan" 36:2 36:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="sarna" 36:4 36:4
do="nm"
mo="topical" 36:5 36:5
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="senokot" 36:7 36:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="celexa" 37:5 37:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="cyclosporine" 37:3 37:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="lasix" 37:8 37:8
do="80 mg" 37:9 37:10
mo="nm"
f="once per day" 37:11 38:0
du="nm"
r="nm"
ln="list"
19:
m="miconazole powder" 37:0 37:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="torsemide" 59:0 59:0
do="nm"
mo="iv" 58:6 58:6
f="nm"
du="nm"
r="her heart failure" 57:9 58:0
ln="narrative"
21:
m="torsemide" 59:0 59:0
do="nm"
mo="oral" 58:10 58:10
f="nm"
du="nm"
r="her heart failure" 57:9 58:0
ln="narrative"
22:
m="torsemide" 59:7 59:7
do="200 mg" 59:8 59:9
mo="p.o." 60:0 60:0
f="twice per day." 60:1 60:3
du="nm"
r="her heart failure" 57:9 58:0
ln="narrative"
23:
m="torsemide" 62:0 62:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="levofloxacin" 64:7 64:7
do="nm"
mo="nm"
f="nm"
du="a five-day course" 64:3 64:5
r="recurrent uti" 65:0 65:1
ln="narrative"
25:
m="ancef" 65:9 65:9
do="nm"
mo="nm"
f="nm"
du="a two-day course" 65:5 65:7
r="her cellulitis" 65:11 65:12
ln="narrative"
26:
m="levofloxacin" 67:4 67:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="her urinary tract infection" 66:5 66:8
ln="narrative"
27:
m="bactrim" 68:0 68:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="her urinary tract infection" 66:5 66:8
ln="narrative"
28:
m="bactrim" 76:7 76:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="her uti" 76:9 77:0
ln="narrative"
29:
m="antibiotic." 78:8 78:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="antibiotic" 79:2 79:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="iron" 81:2 81:2
do="nm"
mo="nm"
f="three times per day" 81:8 81:11
du="nm"
r="her chronic anemia" 80:4 80:6
ln="narrative"
32:
m="darbepoetin" 82:1 82:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="her chronic anemia" 80:4 80:6
ln="narrative"
33:
m="folate" 82:3 82:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="packed red blood cells" 83:8 84:0
do="two units" 83:5 83:6
mo="nm"
f="nm"
du="nm"
r="her chronic anemia" 82:10 83:1
ln="narrative"
35:
m="packed red blood cells" 83:8 84:0
do="two...units" 84:7 84:7,84:9 84:9
mo="nm"
f="nm"
du="nm"
r="her chronic anemia" 82:10 83:1
ln="narrative"
36:
m="oxygen." 91:5 91:5
do="three liters" 91:2 91:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
37:
m="imuran" 94:10 94:10
do="25 mg" 94:11 95:0
mo="nm"
f="daily" 95:1 95:1
du="nm"
r="nm"
ln="list"
38:
m="vitamin c" 94:2 94:3
do="500 mg" 94:4 94:5
mo="nm"
f="twice per day" 94:6 94:8
du="nm"
r="nm"
ln="list"
39:
m="clonazepam" 95:11 95:11
do="0.25 mg" 95:12 95:13
mo="nm"
f="twice per day" 96:0 96:2
du="nm"
r="nm"
ln="list"
40:
m="phoslo" 95:3 95:3
do="667 mg" 95:4 95:5
mo="nm"
f="three times per day" 95:6 95:9
du="nm"
r="nm"
ln="list"
41:
m="colace" 96:10 96:10
do="100 mg" 96:11 96:12
mo="nm"
f="twice daily" 97:0 97:1
du="nm"
r="nm"
ln="list"
42:
m="cyclosporine" 96:4 96:4
do="50 mg" 96:5 96:6
mo="nm"
f="twice daily" 96:7 96:8
du="nm"
r="nm"
ln="list"
43:
m="folate" 97:12 97:12
do="1 mg" 97:13 97:14
mo="nm"
f="daily " 98:0 98:0
du="nm"
r="nm"
ln="list"
44:
m="iron sulfate" 97:3 97:4
do="325 mg" 97:5 97:6
mo="nm"
f="three times per day" 97:7 97:10
du="nm"
r="nm"
ln="list"
45:
m="dilaudid" 98:2 98:2
do="2 mg" 98:3 98:4
mo="nm"
f="every six hours as needed" 98:5 98:9
du="nm"
r="pain" 98:11 98:11
ln="list"
46:
m="insulin nph" 100:0 100:1
do="14 units" 100:2 100:3
mo="nm"
f="every evening" 100:4 100:5
du="nm"
r="nm"
ln="list"
47:
m="insulin nph" 100:7 100:8
do="46 units" 100:9 100:10
mo="nm"
f="every morning" 100:11 101:0
du="nm"
r="nm"
ln="list"
48:
m="lactulose" 101:2 101:2
do="30 ml" 101:3 101:4
mo="nm"
f="four times per day as needed" 101:5 101:10
du="nm"
r="constipation" 102:0 102:0
ln="list"
49:
m="prednisone" 102:2 102:2
do="5 mg" 102:3 102:4
mo="nm"
f="every morning" 102:5 102:6
du="nm"
r="nm"
ln="list"
50:
m="sarna" 102:8 102:8
do="nm"
mo="topical" 102:9 102:9
f="every day" 102:10 103:0
du="nm"
r="nm"
ln="list"
51:
m="coumadin" 103:9 103:9
do="2.5 mg" 103:10 103:11
mo="nm"
f="daily " 104:0 104:0
du="nm"
r="nm"
ln="list"
52:
m="multivitamin" 103:6 103:6
do="nm"
mo="nm"
f="daily" 103:7 103:7
du="nm"
r="nm"
ln="list"
53:
m="ambien" 104:14 104:14
do="5 mg" 104:15 104:16
mo="nm"
f="before bed as needed" 105:0 105:3
du="nm"
r="insomnia" 105:5 105:5
ln="list"
54:
m="zinc sulfate" 104:8 104:9
do="220 mg" 104:10 104:11
mo="nm"
f="daily" 104:12 104:12
du="nm"
r="nm"
ln="list"
55:
m="torsemide" 105:7 105:7
do="200 mg" 105:8 105:9
mo="by mouth" 105:10 105:11
f="two times per day" 105:12 106:2
du="nm"
r="nm"
ln="list"
56:
m="fosamax" 106:4 106:4
do="70 mg" 106:5 106:6
mo="nm"
f="once per week" 106:7 106:9
du="nm"
r="nm"
ln="list"
57:
m="miconazole nitrate 2% powder" 106:11 107:0
do="nm"
mo="topical" 107:1 107:1
f="two times per day...as needed" 107:2 107:5,107:10 108:0
du="nm"
r="nm"
ln="list"
58:
m="advair diskus 250/50" 108:2 108:4
do="one puff" 108:5 108:6
mo="inhaled" 108:7 108:7
f="twice per day" 108:8 108:10
du="nm"
r="nm"
ln="list"
59:
m="duoneb" 109:7 109:7
do="3/0.5 mg" 109:8 109:9
mo="inhaled" 109:10 109:10
f="every six hours as needed" 109:11 110:3
du="nm"
r="shortness of breath" 110:5 110:7
ln="list"
60:
m="esomeprazole" 109:0 109:0
do="20 mg" 109:1 109:2
mo="nm"
f="once per day" 109:3 109:5
du="nm"
r="nm"
ln="list"
61:
m="aranesp" 110:9 110:9
do="50 mcg" 110:10 110:11
mo="subcutaneously" 111:0 111:0
f="once per week" 111:1 111:3
du="nm"
r="nm"
ln="list"
62:
m="novolog" 111:5 111:5
do="sliding scale" 111:6 111:7
mo="nm"
f="before meals" 111:8 111:9
du="nm"
r="nm"
ln="list"
63:
m="lexapro" 112:0 112:0
do="20 mg" 112:1 112:2
mo="nm"
f="once per day" 112:3 112:5
du="nm"
r="nm"
ln="list"
64:
m="maalox" 112:7 112:7
do="one to two tablets" 112:8 112:11
mo="nm"
f="every six hours as needed" 112:12 113:2
du="nm"
r="upset stomach" 113:4 113:5
ln="list"
65:
m="lipitor" 113:8 113:8
do="20 mg" 113:9 113:10
mo="nm"
f="once per day." 113:11 114:0
du="nm"
r="nm"
ln="list"
66:
m="antibiotics" 119:2 119:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="urinary tract infection" 118:6 118:8
ln="narrative"
