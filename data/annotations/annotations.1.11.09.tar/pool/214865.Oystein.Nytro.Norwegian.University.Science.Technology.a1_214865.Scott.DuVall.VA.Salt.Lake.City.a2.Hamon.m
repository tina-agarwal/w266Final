1:
m="neoral" 37:3 37:3
do="150 mg" 37:4 37:5
mo="nm"
f="b.i.d." 37:6 37:6
du="nm"
r="nm"
ln="list"
2:
m="prednisone" 37:8 37:8
do="8 mg" 37:9 37:10
mo="nm"
f="daily" 38:0 38:0
du="nm"
r="nm"
ln="list"
3:
m="cellcept" 38:2 38:2
do="1500 mg" 38:3 38:4
mo="nm"
f="b.i.d." 38:5 38:5
du="nm"
r="nm"
ln="list"
4:
m="pravachol" 38:12 38:12
do="40 mg" 39:0 39:1
mo="nm"
f="daily" 39:2 39:2
du="nm"
r="nm"
ln="list"
5:
m="protonix" 38:7 38:7
do="20 mg" 38:8 38:9
mo="nm"
f="daily" 38:10 38:10
du="nm"
r="nm"
ln="list"
6:
m="diltiazem" 39:4 39:4
do="360 mg" 39:5 39:6
mo="nm"
f="daily" 39:7 39:7
du="nm"
r="nm"
ln="list"
7:
m="multivitamin" 39:9 39:9
do="one" 39:10 39:10
mo="nm"
f="daily" 39:11 39:11
du="nm"
r="nm"
ln="list"
8:
m="calcium" 40:6 40:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="magnesium oxide" 40:0 40:1
do="400 mg" 40:2 40:3
mo="nm"
f="daily" 40:4 40:4
du="nm"
r="nm"
ln="list"
10:
m="vitamin d" 40:8 40:9
do="1800 mg" 40:10 40:11
mo="nm"
f="daily" 41:0 41:0
du="nm"
r="nm"
ln="list"
11:
m="colace" 41:7 41:7
do="100 mg" 41:8 41:9
mo="nm"
f="daily" 41:10 41:10
du="nm"
r="nm"
ln="list"
12:
m="fosamax" 41:2 41:2
do="nm"
mo="nm"
f="weekly on mondays" 41:3 41:5
du="nm"
r="nm"
ln="list"
13:
m="zocor" 41:12 41:12
do="20 mg" 41:13 42:0
mo="nm"
f="daily" 42:1 42:1
du="nm"
r="nm"
ln="list"
14:
m="dulcolax" 42:3 42:3
do="10 mg" 42:4 42:5
mo="nm"
f="as needed" 42:6 42:7
du="nm"
r="constipation" 42:9 42:9
ln="list"
15:
m="vitamin e" 42:11 42:12
do="400 units" 43:0 43:1
mo="nm"
f="daily" 43:2 43:2
du="nm"
r="nm"
ln="list"
16:
m="vitamin c" 43:5 43:6
do="500 mg" 43:7 43:8
mo="nm"
f="b.i.d." 43:9 43:9
du="nm"
r="nm"
ln="list"
17:
m="aspirin" 84:8 84:8
do="325 mg" 84:9 84:10
mo="nm"
f="daily" 84:11 84:11
du="for four weeks" 85:0 85:2
r="nm"
ln="narrative"
18:
m="oxycodone" 87:2 87:2
do="nm"
mo="nm"
f="as needed" 87:3 87:4
du="nm"
r="nm"
ln="narrative"
19:
m="immunosuppressive medications." 90:4 90:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="fondaparinux" 95:5 95:5
do="nm"
mo="nm"
f="daily prior to the procedure" 95:6 96:2
du="nm"
r="heparin-induced thrombocytopenia." 94:7 95:0
ln="narrative"
21:
m="aspirin" 96:7 96:7
do="nm"
mo="nm"
f="nm"
du="for four weeks postprocedure." 96:8 97:0
r="nm"
ln="narrative"
22:
m="packed red blood cells" 98:9 99:0
do="2 units" 98:6 98:7
mo="nm"
f="nm"
du="nm"
r="hematocrit" 99:8 99:8
ln="narrative"
23:
m="packed red blood cells" 100:6 100:9
do="2 units" 100:3 100:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="tylenol" 106:2 106:2
do="650 mg" 106:3 106:4
mo="nm"
f="every four hours as needed" 106:5 106:9
du="nm"
r="pain" 107:1 107:1
ln="list"
25:
m="aspirin" 107:3 107:3
do="325 mg" 107:4 107:5
mo="nm"
f="daily" 107:6 107:6
du="for four weeks" 107:7 107:9
r="nm"
ln="list"
26:
m="dulcolax" 108:5 108:5
do="10 mg" 108:7 108:8
mo="p.r." 108:6 108:6
f="as needed" 108:9 108:10
du="nm"
r="constipation" 109:0 109:0
ln="list"
27:
m="fosamax" 108:0 108:0
do="70 mg" 108:1 108:2
mo="nm"
f="weekly" 108:3 108:3
du="nm"
r="nm"
ln="list"
28:
m="caltrate plus d" 109:2 109:4
do="one tablet" 109:5 109:6
mo="nm"
f="daily" 109:7 109:7
du="nm"
r="nm"
ln="list"
29:
m="neoral ( cyclosporine )" 109:9 110:2
do="150 mg" 110:3 110:4
mo="nm"
f="b.i.d." 110:5 110:5
du="nm"
r="nm"
ln="list"
30:
m="diltiazem extended release" 110:7 110:9
do="360 mg" 110:10 110:11
mo="nm"
f="daily" 111:0 111:0
du="nm"
r="nm"
ln="list"
31:
m="colace" 111:2 111:2
do="100 mg" 111:3 111:4
mo="nm"
f="b.i.d." 111:5 111:5
du="nm"
r="nm"
ln="list"
32:
m="magnesium oxide" 111:7 111:8
do="420 mg" 111:9 111:10
mo="nm"
f="daily" 111:11 111:11
du="nm"
r="nm"
ln="list"
33:
m="cellcept" 112:0 112:0
do="1500 mg" 112:1 112:2
mo="nm"
f="b.i.d." 112:3 112:3
du="nm"
r="nm"
ln="list"
34:
m="oxycodone" 112:5 112:5
do="5-10 mg" 112:6 112:7
mo="nm"
f="every six hours as needed" 112:8 113:0
du="nm"
r="pain" 113:2 113:2
ln="list"
35:
m="pravachol" 113:9 113:9
do="40 mg" 113:10 113:11
mo="nm"
f="daily" 113:12 113:12
du="nm"
r="nm"
ln="list"
36:
m="protonix" 113:4 113:4
do="40 mg" 113:5 113:6
mo="nm"
f="daily" 113:7 113:7
du="nm"
r="nm"
ln="list"
37:
m="multivitamin" 114:7 114:7
do="one tablet" 114:8 114:9
mo="nm"
f="daily." 114:10 114:10
du="nm"
r="nm"
ln="narrative"
38:
m="prednisone" 114:0 114:0
do="8 mg" 114:1 114:2
mo="nm"
f="every morning" 114:3 114:4
du="nm"
r="nm"
ln="list"
39:
m="home medication regimen." 115:7 116:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
40:
m="aspirin" 116:9 116:9
do="325 mg" 116:10 116:11
mo="nm"
f="nm"
du="for four weeks" 117:0 117:2
r="clot" 117:5 117:5
ln="narrative"
41:
m="oxycodone" 118:1 118:1
do="nm"
mo="nm"
f="as needed" 118:2 118:3
du="nm"
r="pain." 118:5 118:5
ln="narrative"
