1:
m="tpa" 13:3 13:3
do="nm"
mo="infusion" 13:4 13:4
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="glipizide" 28:1 28:1
do="5 mg" 28:2 28:3
mo="nm"
f="b.i.d." 28:4 28:4
du="nm"
r="nm"
ln="list"
3:
m="hydrochlorothiazide" 28:6 28:6
do="50 mg" 28:7 28:8
mo="nm"
f="q.d." 29:0 29:0
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 29:2 29:2
do="20 mg" 29:3 29:4
mo="nm"
f="q.d." 29:5 29:5
du="nm"
r="nm"
ln="list"
5:
m="simvastatin" 29:7 29:7
do="20 mg" 29:8 29:9
mo="nm"
f="q.d." 29:10 29:10
du="nm"
r="nm"
ln="list"
6:
m="amlodipine" 30:0 30:0
do="5 mg" 30:1 30:2
mo="nm"
f="q.d." 30:3 30:3
du="nm"
r="nm"
ln="list"
7:
m="imdur" 30:5 30:5
do="30 mg" 30:6 30:7
mo="nm"
f="q.d." 30:8 30:8
du="nm"
r="nm"
ln="list"
8:
m="toprol" 30:11 30:11
do="100 mg" 30:12 30:13
mo="nm"
f="q.d." 30:14 30:14
du="nm"
r="nm"
ln="list"
9:
m="enteric coated aspirin" 31:0 31:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="tpa" 35:2 35:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="aspirin" 73:4 73:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="coumadin" 73:11 73:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lopressor" 73:6 73:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="lopressor" 74:5 74:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="mildly tachycardic" 74:1 74:2
ln="narrative"
15:
m="flagyl" 76:9 76:9
do="nm"
mo="nm"
f="nm"
du="ten-day course" 76:6 76:7
r="his preoperative pneumonia." 77:2 77:4
ln="narrative"
16:
m="cefotaxime" 77:0 77:0
do="nm"
mo="nm"
f="nm"
du="ten-day course" 76:6 76:7
r="his preoperative pneumonia." 77:2 77:4
ln="narrative"
17:
m="coumadin" 86:3 86:3
do="4 mg" 86:4 86:5
mo="p.o." 86:6 86:6
f="q.hs" 86:7 86:7
du="nm"
r="inr" 87:1 87:1
ln="list"
18:
m="aspirin" 87:7 87:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="diltiazem" 87:9 87:9
do="30 mg" 87:10 88:0
mo="nm"
f="t.i.d." 88:1 88:1
du="nm"
r="nm"
ln="list"
20:
m="colace" 88:8 88:8
do="100 mg" 88:9 88:10
mo="nm"
f="t.i.d." 88:11 88:11
du="nm"
r="nm"
ln="list"
21:
m="nexium" 88:13 88:13
do="20 mg" 88:14 89:0
mo="nm"
f="q.d." 89:1 89:1
du="nm"
r="nm"
ln="list"
22:
m="simvastatin" 88:3 88:3
do="20 mg" 88:4 88:5
mo="nm"
f="q.d." 88:6 88:6
du="nm"
r="nm"
ln="list"
23:
m="glipizide" 89:6 89:6
do="5 mg" 89:7 89:8
mo="nm"
f="b.i.d." 89:9 89:9
du="nm"
r="nm"
ln="list"
24:
m="lasix" 89:11 89:11
do="40 mg" 89:12 89:13
mo="nm"
f="b.i.d." 90:0 90:0
du="nm"
r="nm"
ln="list"
25:
m="niferex-150" 89:3 89:3
do="nm"
mo="nm"
f="b.i.d." 89:4 89:4
du="nm"
r="nm"
ln="list"
26:
m="czi" 90:8 90:8
do="sliding scale" 90:9 90:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="lopressor" 90:3 90:3
do="50 mg" 90:4 90:5
mo="nm"
f="b.i.d." 90:6 90:6
du="nm"
r="nm"
ln="list"
