1:
m="albuterol inhaler" 19:0 19:1
do="2 puff" 19:2 19:3
mo="inh" 19:4 19:4
f="qid prn" 19:5 19:6
du="nm"
r="sob" 19:7 19:7
ln="list"
2:
m="ecasa ( aspirin enteric coated )" 20:0 20:5
do="325 mg" 20:6 20:7
mo="po" 20:8 20:8
f="qd" 20:9 20:9
du="nm"
r="nm"
ln="list"
3:
m="atenolol" 21:0 21:0
do="50 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 23:0 23:0
do="5 mg" 23:1 23:2
mo="po" 23:3 23:3
f="qd" 23:4 23:4
du="nm"
r="nm"
ln="list"
5:
m="nitroglycerin 1/150 ( 0.4 mg )" 24:0 24:5
do="1 tab" 24:6 24:7
mo="sl" 24:8 24:8
f="q5 min x3 prn" 24:9 25:0
du="nm"
r="chest pain" 25:1 25:2
ln="list"
6:
m="terbutaline ( terbutaline sulfate )" 27:0 27:4
do="5 mg" 27:5 27:6
mo="po" 27:7 27:7
f="qid" 27:8 27:8
du="nm"
r="nm"
ln="list"
7:
m="azmacort ( triamcinolone acetonide )" 28:0 28:4
do="2 puff" 28:5 28:6
mo="inh" 28:7 28:7
f="qid" 28:8 28:8
du="nm"
r="nm"
ln="list"
8:
m="keflex ( cephalexin )" 29:0 29:3
do="500 mg" 29:4 29:5
mo="po" 29:6 29:6
f="qid" 29:7 29:7
du="nm"
r="nm"
ln="list"
9:
m="imdur ( isosorbide mononit.( sr ) )" 30:0 30:6
do="30 mg" 30:7 30:8
mo="po" 30:9 30:9
f="qd" 30:10 30:10
du="nm"
r="nm"
ln="list"
10:
m="imdur" 64:10 64:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="lisinopril" 64:4 64:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="his sbp" 63:6 63:7
ln="narrative"
12:
m="cardiac regimen" 65:3 65:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
