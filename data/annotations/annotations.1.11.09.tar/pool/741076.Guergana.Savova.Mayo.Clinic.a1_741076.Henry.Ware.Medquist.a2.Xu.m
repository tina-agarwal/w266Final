1:
m="lasix" 26:12 26:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="nitrospray" 27:0 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="kayexalate" 28:13 28:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lasix" 28:6 28:6
do="80 mg" 28:2 28:3
mo="iv" 28:5 28:5
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="allopurinol" 39:4 39:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="aspirin" 39:0 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="glipizide" 39:8 39:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lipitor" 39:10 39:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="metoprolol" 39:2 39:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="valsartan" 39:6 39:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="nifedipine" 40:1 40:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="oxygen." 44:11 44:11
do="a couple of liters" 44:6 44:9
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="aspirin" 59:7 59:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="beta-blockers" 59:9 59:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="statin" 60:1 60:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="coronary artery disease" 60:3 60:5
ln="narrative"
16:
m="diuril" 61:10 61:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="lasix" 61:8 61:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="arb" 63:4 63:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="calcium channel blocker" 63:11 64:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="beta-blockers" 70:3 70:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="ventricular ectopy" 69:0 69:1
ln="narrative"
21:
m="diuril/lasix" 74:5 74:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="kayexalate" 76:4 76:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="arbs" 77:9 77:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="lasix" 77:1 77:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="lasix" 77:7 77:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="regular ... insulin" 84:8 84:8,85:0 85:0
do="sliding scale" 84:9 84:10
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="glipizide" 85:7 85:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="glipizide" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="allopurinol" 90:8 90:8
do="nm"
mo="nm"
f="q.72h." 91:0 91:0
du="nm"
r="nm"
ln="narrative"
30:
m="allopurinol" 90:8 90:8
do="nm"
mo="nm"
f="q.o.d." 91:2 91:2
du="nm"
r="nm"
ln="narrative"
31:
m="afrin" 97:4 97:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="epistaxis" 95:8 95:8
ln="narrative"
32:
m="nasal saline" 97:0 97:1
do="nm"
mo="sprays" 97:2 97:2
f="nm"
du="nm"
r="epistaxis" 95:8 95:8
ln="narrative"
33:
m="lasix" 100:2 100:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="coumadin" 104:3 104:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 105:0 105:1
ln="narrative"
35:
m="aspirin" 108:7 108:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="heparin" 109:2 109:2
do="nm"
mo="subcutaneous" 109:1 109:1
f="nm"
du="while in-house" 109:6 109:7
r="dvt prophylaxis" 109:4 109:5
ln="narrative"
37:
m="stool softeners" 111:2 111:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="constipation" 110:6 110:6
ln="narrative"
38:
m="ppi." 112:5 112:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
39:
m="lasix" 133:1 133:1
do="20 mg" 133:2 133:3
mo="p.o." 133:4 133:4
f="q.d." 133:5 133:5
du="nm"
r="nm"
ln="list"
40:
m="lipitor" 134:1 134:1
do="80 mg" 134:2 134:3
mo="p.o." 134:4 134:4
f="q.d." 134:5 134:5
du="nm"
r="nm"
ln="list"
41:
m="metoprolol sustained release" 135:1 135:3
do="100 mg" 135:4 135:5
mo="p.o." 135:6 135:6
f="b.i.d." 135:7 135:7
du="nm"
r="nm"
ln="list"
42:
m="colace" 136:1 136:1
do="100 mg" 136:2 136:3
mo="p.o." 136:4 136:4
f="b.i.d. p.r.n" 136:5 136:6
du="nm"
r="constipation" 136:8 136:8
ln="list"
43:
m="allopurinol" 137:1 137:1
do="100 mg" 137:2 137:3
mo="p.o." 137:4 137:4
f="q.72h." 137:5 137:5
du="nm"
r="nm"
ln="list"
44:
m="aspirin" 138:1 138:1
do="325 mg" 138:2 138:3
mo="p.o." 138:4 138:4
f="q.d." 138:5 138:5
du="nm"
r="nm"
ln="list"
45:
m="valsartan" 139:1 139:1
do="160 mg" 139:2 139:3
mo="p.o." 139:4 139:4
f="q.d." 139:5 139:5
du="nm"
r="nm"
ln="list"
