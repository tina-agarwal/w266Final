1:
m="acetylsalicylic acid" 14:0 14:1
do="81 mg" 14:2 14:3
mo="po " 14:4 14:4
f="qd " 14:5 14:5
du="nm"
r="nm"
ln="list"
2:
m="lisinopril" 15:0 15:0
do="10 mg" 15:1 15:2
mo="po" 15:3 15:3
f="qd" 15:4 15:4
du="nm"
r="nm"
ln="list"
3:
m="kcl slow release" 19:3 19:5
do="nm"
mo="po" 19:6 19:6
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 24:3 24:3
do="nm"
mo="po" 24:4 24:4
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="toprol xl ( metoprolol succinate extended release )" 28:0 28:7
do="100 mg" 29:0 29:1
mo="po" 29:2 29:2
f="bid" 29:3 29:3
du="nm"
r="nm"
ln="list"
6:
m="lantus ( insulin glargine )" 37:0 37:4
do="19 units" 37:5 37:6
mo="sc " 37:8 37:8
f="qam " 37:7 37:7
du="nm"
r="nm"
ln="list"
7:
m="lantus ( insulin glargine )" 37:0 37:4
do="19 units" 37:5 37:6
mo="sc" 37:8 37:8
f="qam" 37:7 37:7
du="nm"
r="nm"
ln="list"
8:
m="warfarin sodium" 40:0 40:1
do="5 mg" 40:2 40:3
mo="po" 40:4 40:4
f="qpm...20:00" 40:5 40:5,41:3 41:3
du="nm"
r="nm"
ln="list"
9:
m="rosiglitazone" 48:0 48:0
do="2 mg" 48:1 48:2
mo="po" 48:3 48:3
f="qd" 48:4 48:4
du="nm"
r="nm"
ln="list"
10:
m="furosemide" 49:0 49:0
do="20 mg" 49:1 49:2
mo="po" 49:3 49:3
f="bid...prn" 49:4 49:4,50:0 50:0
du="nm"
r="edema" 50:2 50:2
ln="list"
11:
m="simvastatin" 53:0 53:0
do="10 mg" 53:1 53:2
mo="po" 53:3 53:3
f="qhs" 53:4 53:4
du="nm"
r="nm"
ln="list"
12:
m="home medication" 58:6 58:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="cefpodoxime proxetil" 60:0 60:1
do="200 mg" 60:2 60:3
mo="po" 60:4 60:4
f="bid...with meals" 60:5 60:5,62:4 62:5
du="x 16 doses" 60:6 60:8
r="nm"
ln="list"
14:
m="cefpodoxime proxetil" 64:3 64:4
do="nm"
mo="po" 64:5 64:5
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="cefalosporins" 68:1 68:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="digoxin" 69:0 69:0
do="0.125 mg" 69:1 69:2
mo="po" 69:3 69:3
f="qod" 69:4 69:4
du="nm"
r="nm"
ln="list"
17:
m="adenosine-mibi" 87:2 87:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="levofloxacin." 93:5 93:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="digoxin" 95:7 95:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="adenosine" 100:4 100:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="levofloxacin" 101:6 101:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="ceftriaxone" 102:0 102:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="vancomycin" 104:8 104:8
do="nm"
mo="nm"
f="nm"
du="2 doses" 104:5 104:6
r="potential staph infection." 104:11 105:0
ln="narrative"
24:
m="antibiotics" 106:1 106:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="antibiotics" 110:4 110:4
do="nm"
mo="nm"
f="nm"
du="8days" 110:9 110:9
r="nm"
ln="narrative"
26:
m="digoxin" 111:7 111:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lasix" 111:12 111:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="cardiac medications" 119:6 119:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="better rate control" 119:9 120:0
ln="narrative"
29:
m="coreg( carvedelol )" 120:5 120:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="norvasc( amilodipine )" 121:0 121:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="toprol xl( metoprolol xl )" 122:0 122:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 122:12 123:0
ln="narrative"
32:
m="digoxin" 123:2 123:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="heart rate control" 123:7 123:9
ln="narrative"
