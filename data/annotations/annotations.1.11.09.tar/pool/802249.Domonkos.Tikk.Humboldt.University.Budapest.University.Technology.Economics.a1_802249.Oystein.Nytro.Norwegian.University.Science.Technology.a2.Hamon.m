1:
m="nifedipine" 15:9 15:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="her blood pressure" 15:1 15:3
ln="narrative"
2:
m="cardizem" 17:11 17:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 17:1 17:1
ln="narrative"
3:
m="nitroglycerin" 19:0 19:0
do="nm"
mo="nm"
f="nm"
du="times two." 19:1 19:2
r="pain" 18:5 18:5
ln="narrative"
4:
m="nitrospray" 21:4 21:4
do="two" 21:3 21:3
mo="nm"
f="nm"
du="nm"
r="blood pressure" 21:6 21:7
ln="narrative"
5:
m="atropine" 24:3 24:3
do="0.5 mg" 24:0 24:1
mo="nm"
f="nm"
du="times one" 24:4 24:5
r="blood pressure" 23:5 23:6
ln="narrative"
6:
m="atropine" 28:9 28:9
do="0.5 mg" 28:10 29:0
mo="nm"
f="nm"
du="times one." 29:1 29:2
r="systolic blood pressure" 27:9 28:0
ln="narrative"
7:
m="intravenous fluids" 28:6 28:7
do="nm"
mo="intravenous" 28:6 28:6
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="glucotrol" 37:0 37:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 36:7 36:8
ln="narrative"
9:
m="nifedipine" 41:5 41:5
do="10 mg" 41:6 41:7
mo="p.o." 41:8 41:8
f="p.r.n." 41:9 41:9
du="nm"
r="elevated blood pressure" 42:0 42:2
ln="list"
10:
m="lasix" 42:5 42:5
do="20 mg" 42:6 43:0
mo="p.o." 43:1 43:1
f="q. day." 43:2 43:3
du="nm"
r="nm"
ln="list"
11:
m="cardizem" 43:14 43:14
do="300 mg" 43:15 44:0
mo="p.o." 44:1 44:1
f="q. day." 44:2 44:3
du="nm"
r="nm"
ln="list"
12:
m="glucotrol" 43:6 43:6
do="15 mg" 43:7 43:8
mo="p.o." 43:9 43:9
f="q. day." 43:10 43:11
du="nm"
r="nm"
ln="list"
13:
m="colace" 44:14 44:14
do="100 mg" 44:15 45:0
mo="p.o." 45:1 45:1
f="b.i.d." 45:2 45:2
du="nm"
r="nm"
ln="list"
14:
m="coumadin" 44:6 44:6
do="3.75 mg" 44:7 44:8
mo="p.o." 44:9 44:9
f="q. day." 44:10 44:11
du="nm"
r="nm"
ln="list"
15:
m="iron" 45:5 45:5
do="325 mg" 45:6 45:7
mo="p.o." 45:8 45:8
f="q. day." 45:9 45:10
du="nm"
r="nm"
ln="list"
16:
m="heparin" 83:8 83:8
do="nm"
mo="nm"
f="nm"
du="overnight" 83:9 83:9
r="stenosis" 83:5 83:5
ln="narrative"
17:
m="ace inhibitor" 86:8 86:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="aspirin" 86:0 86:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="beta blocker" 86:2 86:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="isordil" 86:5 86:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="aspirin" 87:5 87:5
do="325 mg" 87:6 87:7
mo="p.o." 87:8 87:8
f="q. day." 87:9 87:10
du="nm"
r="nm"
ln="list"
22:
m="atenolol" 88:0 88:0
do="50 mg" 88:1 88:2
mo="p.o." 88:3 88:3
f="q. day." 88:4 88:5
du="nm"
r="nm"
ln="list"
23:
m="lisinopril" 89:0 89:0
do="10 mg" 89:1 89:2
mo="p.o." 89:3 89:3
f="q. day." 89:4 89:5
du="nm"
r="nm"
ln="list"
24:
m="pravachol" 89:8 89:8
do="20 mg" 89:9 89:10
mo="p.o." 89:11 89:11
f="q. day." 89:12 89:13
du="nm"
r="nm"
ln="list"
25:
m="glucotrol xl" 90:0 90:1
do="15 mg" 90:2 90:3
mo="p.o." 90:4 90:4
f="q. am." 90:5 90:6
du="nm"
r="nm"
ln="list"
26:
m="lasix" 90:9 90:9
do="20 mg" 90:10 90:11
mo="p.o." 90:12 90:12
f="q. day." 90:13 90:14
du="nm"
r="nm"
ln="list"
27:
m="nitroglycerin tablets" 91:0 91:1
do="nm"
mo="sublingual" 91:2 91:2
f="p.r.n." 91:3 91:3
du="nm"
r="chest pain." 91:4 91:5
ln="list"
