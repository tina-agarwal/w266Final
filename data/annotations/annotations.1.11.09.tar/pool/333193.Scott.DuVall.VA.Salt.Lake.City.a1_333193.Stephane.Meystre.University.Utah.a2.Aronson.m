1:
m="trazodone" 28:1 28:1
do="50 mg" 28:2 28:3
mo="nm"
f="nightly." 28:4 28:4
du="nm"
r="nm"
ln="list"
2:
m="celexa" 29:1 29:1
do="20 mg" 29:2 29:3
mo="nm"
f="daily." 29:4 29:4
du="nm"
r="nm"
ln="list"
3:
m="lactulose" 30:1 30:1
do="30 mg" 30:2 30:3
mo="nm"
f="q.a.m." 30:4 30:4
du="nm"
r="nm"
ln="list"
4:
m="fibercon" 31:1 31:1
do="one tablet." 31:2 31:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="hydrochlorothiazide" 32:1 32:1
do="25 mg" 32:2 32:3
mo="nm"
f="daily." 32:4 32:4
du="nm"
r="nm"
ln="list"
6:
m="mvi" 33:1 33:1
do="nm"
mo="nm"
f="daily." 33:2 33:2
du="nm"
r="nm"
ln="list"
7:
m="synthroid" 34:1 34:1
do="25 mcg" 34:2 34:3
mo="nm"
f="daily." 34:4 34:4
du="nm"
r="nm"
ln="list"
8:
m="colace" 35:1 35:1
do="100 mg" 35:2 35:3
mo="nm"
f="b.i.d." 35:4 35:4
du="nm"
r="nm"
ln="list"
9:
m="novolin" 36:1 36:1
do="30 units" 36:2 36:3
mo="nm"
f="q.a.m." 36:4 36:4
du="nm"
r="nm"
ln="list"
10:
m="novolin" 36:1 36:1
do="7 units" 36:6 36:7
mo="nm"
f="q.p.m." 36:8 36:8
du="nm"
r="nm"
ln="list"
11:
m="novolin" 37:1 37:1
do="sliding scale." 37:2 37:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="hydrochlorothiazide" 38:1 38:1
do="25 mg" 38:2 38:3
mo="nm"
f="daily." 38:4 38:4
du="nm"
r="nm"
ln="list"
13:
m="zyprexa" 39:1 39:1
do="2.5 mg" 39:2 39:3
mo="nm"
f="nightly." 39:4 39:4
du="nm"
r="nm"
ln="list"
14:
m="oral pain medications." 57:7 58:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="the pain" 57:1 57:2
ln="narrative"
15:
m="ancef" 60:8 60:8
do="nm"
mo="nm"
f="nm"
du="perioperative" 60:7 60:7
r="nm"
ln="narrative"
16:
m="linezolid" 61:6 61:6
do="nm"
mo="p.o." 61:5 61:5
f="nm"
du="one week" 61:2 61:3
r="nm"
ln="narrative"
17:
m="tylenol elixir" 69:1 69:2
do="1000 mg" 69:3 69:4
mo="p.o." 69:5 69:5
f="q.6h. p.r.n." 69:6 69:7
du="nm"
r="pain." 69:8 69:8
ln="list"
18:
m="citalopram" 70:1 70:1
do="20 mg" 70:2 70:3
mo="p.o." 70:4 70:4
f="daily." 70:5 70:5
du="nm"
r="nm"
ln="list"
19:
m="colace" 71:1 71:1
do="100 mg" 71:2 71:3
mo="p.o." 71:4 71:4
f="b.i.d." 71:5 71:5
du="nm"
r="nm"
ln="list"
20:
m="hydrochlorothiazide" 72:1 72:1
do="25 mg" 72:2 72:3
mo="p.o." 72:4 72:4
f="daily." 72:5 72:5
du="nm"
r="nm"
ln="list"
21:
m="novolog" 73:1 73:1
do="sliding scale." 73:2 73:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="lantus" 75:1 75:1
do="20 units" 75:2 75:3
mo="subcutaneously" 75:4 75:4
f="q.a.m." 75:5 75:5
du="nm"
r="nm"
ln="list"
23:
m="lactulose" 76:1 76:1
do="30 ml" 76:2 76:3
mo="p.o." 76:4 76:4
f="daily p.r.n." 76:5 76:6
du="nm"
r="constipation." 76:7 76:7
ln="list"
24:
m="synthroid" 77:1 77:1
do="25 mcg" 77:2 77:3
mo="p.o." 77:4 77:4
f="daily." 77:5 77:5
du="nm"
r="nm"
ln="list"
25:
m="linezolid" 78:1 78:1
do="600 mg" 78:2 78:3
mo="p.o." 78:4 78:4
f="q.12h." 78:5 78:5
du="x10 doses" 78:6 78:7
r="nm"
ln="list"
26:
m="zyprexa" 80:1 80:1
do="2.5 mg" 80:2 80:3
mo="p.o." 80:4 80:4
f="q.p.m." 80:5 80:5
du="nm"
r="nm"
ln="list"
