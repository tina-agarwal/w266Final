1:
m="tylenol ( acetaminophen )" 16:0 16:3
do="1 , 000 mg" 16:4 16:7
mo="po" 16:8 16:8
f="q6h" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="keflex ( cephalexin )" 17:0 17:3
do="500 mg" 17:4 17:5
mo="po" 17:6 17:6
f="qid" 17:7 17:7
du="nm"
r="nm"
ln="list"
3:
m="colace ( docusate sodium )" 18:0 18:4
do="100 mg" 18:5 18:6
mo="po" 18:7 18:7
f="bid" 18:8 18:8
du="nm"
r="nm"
ln="list"
4:
m="pepcid ( famotidine )" 19:0 19:3
do="20 mg" 19:4 19:5
mo="po" 19:6 19:6
f="bid" 19:7 19:7
du="nm"
r="nm"
ln="list"
5:
m="dilaudid ( hydromorphone hcl )" 20:0 20:4
do="2-4 mg" 20:5 20:6
mo="po" 20:7 20:7
f="q4h prn" 20:8 20:9
du="nm"
r="pain" 20:10 20:10
ln="list"
6:
m="dilaudid" 23:3 23:3
do="nm"
mo="po" 23:4 23:4
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="insulin regular human" 26:0 26:2
do="sliding scale...low scale" 27:0 27:1,27:7 27:8
mo="( subcutaneously ) sc" 27:2 27:5
f="q4h" 27:6 27:6
du="nm"
r="nm"
ln="list"
8:
m="insulin" 30:5 30:5
do="1 units" 32:7 32:8
mo="subcutaneously" 32:9 32:9
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="insulin" 30:5 30:5
do="2 units" 33:7 33:8
mo="subcutaneously" 33:9 33:9
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="insulin" 30:5 30:5
do="3 units" 34:7 34:8
mo="subcutaneously" 34:9 34:9
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="insulin" 30:5 30:5
do="4 units" 35:7 35:8
mo="subcutaneously" 35:9 35:9
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="insulin" 30:5 30:5
do="5 units" 36:7 36:8
mo="subcutaneously" 36:9 36:9
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="insulin" 39:1 39:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="levothyroxine sodium" 40:0 40:1
do="75 mcg" 40:2 40:3
mo="po" 40:4 40:4
f="daily" 40:5 40:5
du="nm"
r="nm"
ln="list"
15:
m="maalox-tablets quick dissolve/chewable" 41:0 41:2
do="1-2 tab" 41:3 41:4
mo="po" 41:5 41:5
f="q6h prn" 41:6 42:0
du="nm"
r="upset stomach" 42:1 42:2
ln="list"
16:
m="milk of magnesia ( magnesium hydroxide )" 43:0 43:6
do="30 milliliters" 44:0 44:1
mo="po" 44:2 44:2
f="daily prn" 44:3 44:4
du="nm"
r="constipation" 44:5 44:5
ln="list"
17:
m="metoclopramide hcl" 45:0 45:1
do="10 mg" 45:2 45:3
mo="iv" 45:4 45:4
f="q8h prn" 45:5 45:6
du="nm"
r="nausea" 45:7 45:7
ln="list"
18:
m="quinapril" 46:0 46:0
do="20 mg" 46:1 46:2
mo="po" 46:3 46:3
f="daily" 46:4 46:4
du="number of doses required ( approximate ): 5" 47:0 47:7
r="nm"
ln="list"
19:
m="simethicone" 48:0 48:0
do="40 mg" 48:1 48:2
mo="po" 48:3 48:3
f="qid prn" 48:4 48:5
du="nm"
r="other: gas" 48:9 48:9
ln="list"
20:
m="simethicone" 48:0 48:0
do="40 mg" 48:1 48:2
mo="po" 48:3 48:3
f="qid prn" 48:4 48:5
du="nm"
r="upset stomach" 48:6 48:7
ln="list"
21:
m="styker pain pump ( bupivacaine 0.5% )" 49:0 49:6
do="400 milliliters...4ml/hr" 50:0 50:1,50:7 50:7
mo="iv" 50:2 50:2
f="q24h" 50:3 50:3
du="nm"
r="nm"
ln="list"
22:
m="antibiotics" 85:2 85:2
do="nm"
mo="nm"
f="nm"
du="as long as you have drain/s in place." 85:3 85:10
r="nm"
ln="narrative"
