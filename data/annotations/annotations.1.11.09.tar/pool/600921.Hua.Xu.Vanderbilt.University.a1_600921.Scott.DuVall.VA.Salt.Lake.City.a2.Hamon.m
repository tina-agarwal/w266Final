1:
m="dilantin" 14:5 14:5
do="nm"
mo="nm"
f="nm"
du="for less than a year." 14:6 14:10
r="nm"
ln="narrative"
2:
m="nitroglycerin tablet" 20:4 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="isordil" 29:4 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lopressor" 29:6 29:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nitroglycerin" 33:7 33:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest pain" 33:2 33:3
ln="narrative"
6:
m="micronase" 35:1 35:1
do="a stable dose" 34:10 34:12
mo="nm"
f="nm"
du="for the last couple of years." 35:2 35:7
r="nm"
ln="narrative"
7:
m="micronase." 55:9 55:9
do="a stable dose" 55:5 55:7
mo="nm"
f="nm"
du="nm"
r="adult onset diabetes" 54:10 55:0
ln="narrative"
8:
m="aspirin" 63:5 63:5
do="one tablet" 63:6 63:7
mo="nm"
f="q d" 63:8 63:9
du="nm"
r="nm"
ln="list"
9:
m="betaxolol eye drops" 64:13 64:15
do="nm"
mo="to each eye" 65:1 65:3
f="bid" 65:0 65:0
du="nm"
r="nm"
ln="list"
10:
m="micronase" 64:6 64:6
do="5 mg" 64:7 64:8
mo="po" 64:9 64:9
f="q d" 64:10 64:11
du="nm"
r="nm"
ln="list"
11:
m="questran" 64:0 64:0
do="one pack" 64:1 64:2
mo="nm"
f="q d" 64:3 64:4
du="nm"
r="nm"
ln="list"
12:
m="pilocarpine eye drops" 65:5 65:7
do="nm"
mo="to each eye" 65:9 65:11
f="tid" 65:8 65:8
du="nm"
r="nm"
ln="list"
13:
m="vitamin b12" 66:10 67:0
do="nm"
mo="injections" 67:1 67:1
f="monthly" 66:9 66:9
du="nm"
r="nm"
ln="list"
14:
m="nitroglycerin" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="chest pain." 67:7 67:8
ln="list"
15:
m="glaucoma eyedrops." 84:5 84:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="micronase" 103:1 103:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="d50." 113:7 113:7
do="1 amp" 113:4 113:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="nitro paste" 113:1 113:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="aspirin" 132:0 132:0
do="one tablet" 132:1 132:2
mo="po" 132:3 132:3
f="q d" 132:4 132:5
du="nm"
r="nm"
ln="list"
20:
m="pilocarpine eye drops" 132:14 133:1
do="nm"
mo="per eye" 133:3 133:4
f="tid" 133:2 133:2
du="nm"
r="nm"
ln="list"
21:
m="questran" 132:7 132:7
do="one package" 132:8 132:9
mo="po" 132:10 132:10
f="q d" 132:11 132:12
du="nm"
r="nm"
ln="list"
22:
m="betaxolol eye drops" 133:6 133:8
do="nm"
mo="per eye" 133:10 133:11
f="bid" 133:9 133:9
du="nm"
r="nm"
ln="list"
23:
m="nitroglycerin" 134:7 134:7
do="nm"
mo="sublingual" 134:6 134:6
f="prn" 134:8 134:8
du="nm"
r="chest pain" 134:9 134:10
ln="list"
24:
m="naprosyn" 135:0 135:0
do="375 mg" 135:1 135:2
mo="nm"
f="tid prn." 135:3 135:4
du="nm"
r="nm"
ln="list"
