1:
m="glyburide" 70:1 70:1
do="100 mg" 70:2 70:3
mo="p.o." 70:4 70:4
f="b.i.d." 70:5 70:5
du="nm"
r="nm"
ln="list"
2:
m="metformin" 71:1 71:1
do="500 mg" 71:2 71:3
mo="p.o." 71:4 71:4
f="b.i.d." 71:5 71:5
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 72:1 72:1
do="81 mg" 72:2 72:3
mo="p.o." 72:4 72:4
f="q. day" 72:5 72:6
du="nm"
r="nm"
ln="list"
4:
m="zocor" 73:1 73:1
do="80 mg" 73:2 73:3
mo="p.o." 73:4 73:4
f="q. day" 73:5 73:6
du="nm"
r="nm"
ln="list"
5:
m="plavix" 74:1 74:1
do="75 mg" 74:2 74:3
mo="p.o." 74:4 74:4
f="q. day" 74:5 74:6
du="nm"
r="nm"
ln="list"
6:
m="prilosec" 75:1 75:1
do="20 mg" 75:2 75:3
mo="p.o." 75:4 75:4
f="q. day" 75:5 75:6
du="nm"
r="nm"
ln="list"
7:
m="isosorbide dinitrate" 76:1 76:2
do="40 mg" 76:3 76:4
mo="p.o." 76:5 76:5
f="t.i.d." 76:6 76:6
du="nm"
r="nm"
ln="list"
8:
m="atenolol" 77:1 77:1
do="100 mg" 77:2 77:3
mo="p.o." 77:4 77:4
f="q. day" 77:5 77:6
du="nm"
r="nm"
ln="list"
9:
m="dilaudid" 194:7 194:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 193:10 193:10
ln="narrative"
10:
m="oxycodone" 195:0 195:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="pain" 193:10 193:10
ln="narrative"
11:
m="zocor" 216:7 216:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypercholesterolemia:" 216:1 216:1
ln="narrative"
12:
m="lovenox" 218:7 218:7
do="40 mg" 218:8 218:9
mo="sub-q." 219:0 219:0
f="q. day" 219:1 219:2
du="nm"
r="prophylaxis against dvts" 219:5 219:7
ln="narrative"
13:
m="aspirin" 220:0 220:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="secondary cardiac and neurological prophylaxis" 220:4 221:0
ln="narrative"
14:
m="plavix" 220:2 220:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="secondary cardiac and neurological prophylaxis" 220:4 221:0
ln="narrative"
15:
m="lovenox" 221:2 221:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="metformin" 224:1 224:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="glyburide" 225:8 225:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="insulin" 226:2 226:2
do="sliding scale" 226:0 226:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="tylenol" 235:1 235:1
do="650 mg" 235:2 235:3
mo="p.o." 235:4 235:4
f="q.4h. p.r.n." 235:5 235:6
du="nm"
r="pain" 235:7 235:7
ln="list"
20:
m="aspirin" 236:1 236:1
do="81 mg" 236:2 236:3
mo="p.o." 236:4 236:4
f="q. day" 236:5 236:6
du="nm"
r="nm"
ln="list"
21:
m="atenolol" 237:1 237:1
do="100 mg" 237:2 237:3
mo="p.o." 237:4 237:4
f="q. day" 237:5 237:6
du="nm"
r="nm"
ln="list"
22:
m="colace" 238:1 238:1
do="100 mg" 238:2 238:3
mo="p.o." 238:4 238:4
f="b.i.d." 238:5 238:5
du="nm"
r="nm"
ln="list"
23:
m="glyburide" 239:1 239:1
do="5 mg" 239:2 239:3
mo="p.o." 239:4 239:4
f="b.i.d." 239:5 239:5
du="nm"
r="nm"
ln="list"
24:
m="dilaudid" 240:1 240:1
do="1-2 mg" 240:2 240:3
mo="iv" 240:4 240:4
f="q.4h. p.r.n." 240:5 240:6
du="nm"
r="pain" 240:7 240:7
ln="list"
25:
m="isosorbide dinitrate" 241:1 241:2
do="40 mg" 241:3 241:4
mo="p.o." 241:5 241:5
f="t.i.d." 241:6 241:6
du="nm"
r="nm"
ln="list"
26:
m="ativan" 242:1 242:1
do="1-2 mg" 242:2 242:3
mo="iv" 242:4 242:4
f="p.r.n." 242:5 242:5
du="nm"
r="anxiety." 242:6 242:6
ln="list"
27:
m="oxycodone" 243:1 243:1
do="5-10 mg" 243:2 243:3
mo="p.o." 243:4 243:4
f="q.6h. p.r.n." 243:5 243:6
du="nm"
r="pain" 243:7 243:7
ln="list"
28:
m="senna tablets" 244:1 244:2
do="2" 244:3 244:3
mo="p.o." 244:4 244:4
f="b.i.d." 244:5 244:5
du="nm"
r="nm"
ln="list"
29:
m="keflex" 245:1 245:1
do="250 mg" 245:2 245:3
mo="p.o." 245:4 245:4
f="q.i.d." 245:5 245:5
du="x12 doses" 245:6 245:7
r="nm"
ln="list"
30:
m="keflex" 245:8 245:8
do="nm"
mo="nm"
f="nm"
du="completed on monday night" 246:0 246:3
r="nm"
ln="list"
31:
m="zocor" 247:1 247:1
do="80 mg" 247:2 247:3
mo="p.o." 247:4 247:4
f="q.h.s." 247:5 247:5
du="nm"
r="nm"
ln="list"
32:
m="ambien" 248:1 248:1
do="5 mg" 248:2 248:3
mo="p.o." 248:4 248:4
f="q.h.s." 248:5 248:5
du="nm"
r="nm"
ln="list"
33:
m="tessalon" 249:1 249:1
do="100 mg" 249:2 249:3
mo="p.o." 249:4 249:4
f="t.i.d. p.r.n." 249:5 249:6
du="nm"
r="cough" 249:7 249:7
ln="list"
34:
m="plavix" 250:1 250:1
do="75 mg" 250:2 250:3
mo="p.o." 250:4 250:4
f="q. day" 250:5 250:6
du="nm"
r="nm"
ln="list"
35:
m="novalog" 251:1 251:1
do="slides" 251:2 251:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="prilosec" 252:1 252:1
do="20 mg" 252:2 252:3
mo="p.o." 252:4 252:4
f="b.i.d." 252:5 252:5
du="nm"
r="nm"
ln="list"
37:
m="maalox" 253:1 253:1
do="1-2 tabs" 253:2 253:3
mo="p.o." 253:4 253:4
f="q.6h. p.r.n." 253:5 253:6
du="nm"
r="pain" 253:7 253:7
ln="list"
38:
m="levaquin" 262:7 262:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="mild urine infection" 262:0 262:2
ln="narrative"
39:
m="ancef" 280:4 280:4
do="1 gm" 280:5 280:6
mo="nm"
f="q.8h." 280:7 280:7
du="nm"
r="nm"
ln="narrative"
40:
m="ancef" 283:0 283:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
41:
m="ancef" 284:9 284:9
do="nm"
mo="iv" 284:8 284:8
f="q.8h." 285:0 285:0
du="for an additional 12 days" 285:1 285:5
r="nm"
ln="narrative"
