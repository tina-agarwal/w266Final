1:
m="levofloxacin" 17:0 17:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="left lower leg cellulitis" 17:8 18:1
ln="narrative"
2:
m="vancomycin" 17:2 17:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="left lower leg cellulitis" 17:8 18:1
ln="narrative"
3:
m="diltiazem" 25:8 25:8
do="30 mg" 25:9 25:10
mo="nm"
f="t.i.d." 26:0 26:0
du="nm"
r="nm"
ln="list"
4:
m="toprol" 25:3 25:3
do="25 mg" 25:4 25:5
mo="nm"
f="daily" 25:6 25:6
du="nm"
r="nm"
ln="list"
5:
m="aspirin" 26:2 26:2
do="325 mg" 26:3 26:4
mo="nm"
f="daily" 26:5 26:5
du="nm"
r="nm"
ln="list"
6:
m="atorvastatin" 26:12 26:12
do="40 mg" 26:13 27:0
mo="nm"
f="daily" 27:1 27:1
du="nm"
r="nm"
ln="list"
7:
m="lasix" 26:7 26:7
do="40 mg" 26:8 26:9
mo="nm"
f="daily" 26:10 26:10
du="nm"
r="nm"
ln="list"
8:
m="metformin" 27:13 27:13
do="500 mg" 27:14 28:0
mo="nm"
f="daily" 28:1 28:1
du="nm"
r="nm"
ln="list"
9:
m="tricor" 27:3 27:3
do="145 mg" 27:4 27:5
mo="nm"
f="daily" 27:6 27:6
du="nm"
r="nm"
ln="list"
10:
m="zetia" 27:8 27:8
do="10 mg" 27:9 27:10
mo="nm"
f="daily" 27:11 27:11
du="nm"
r="nm"
ln="list"
11:
m="potassium chloride slow release" 28:4 28:7
do="20 meq" 28:8 28:9
mo="nm"
f="daily" 28:10 28:10
du="nm"
r="nm"
ln="list"
12:
m="levofloxacin" 41:5 41:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="a left lower leg cellulitis" 40:7 41:0
ln="narrative"
13:
m="vancomycin" 41:7 41:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="a left lower leg cellulitis" 40:7 41:0
ln="narrative"
14:
m="vancomycin" 43:7 43:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="ancef" 44:5 44:5
do="1 gm" 44:6 44:7
mo="iv" 44:8 44:8
f="q.8h." 44:9 44:9
du="nm"
r="nm"
ln="narrative"
16:
m="levofloxacin" 44:0 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="augmentin" 50:5 50:5
do="875/125 mg" 50:6 50:7
mo="oral" 50:2 50:2
f="b.i.d." 50:8 50:8
du="for a total of 10 days" 50:9 51:0
r="nm"
ln="narrative"
18:
m="augmentin 875/125" 57:0 57:1
do="1 tab" 57:2 57:3
mo="nm"
f="b.i.d." 57:4 57:4
du="for 10 days" 57:5 57:7
r="nm"
ln="list"
19:
m="enteric-coated aspirin" 57:9 58:0
do="325 mg" 58:1 58:2
mo="nm"
f="daily" 58:3 58:3
du="nm"
r="nm"
ln="list"
20:
m="diltiazem" 58:10 58:10
do="30 mg" 58:11 58:12
mo="nm"
f="t.i.d." 59:0 59:0
du="nm"
r="nm"
ln="list"
21:
m="lipitor" 58:5 58:5
do="40 mg" 58:6 58:7
mo="nm"
f="daily" 58:8 58:8
du="nm"
r="nm"
ln="list"
22:
m="diflucan" 59:12 59:12
do="200 mg" 59:13 59:14
mo="nm"
f="daily" 60:0 60:0
du="for one dose" 60:1 60:3
r="a penile yeast infection" 60:5 60:8
ln="list"
23:
m="tricor" 59:7 59:7
do="145 mg" 59:8 59:9
mo="nm"
f="nightly" 59:10 59:10
du="nm"
r="nm"
ln="list"
24:
m="zetia" 59:2 59:2
do="10 mg" 59:3 59:4
mo="nm"
f="daily" 59:5 59:5
du="nm"
r="nm"
ln="list"
25:
m="metformin" 61:2 61:2
do="500 mg" 61:3 61:4
mo="nm"
f="q.p.m." 61:5 61:5
du="nm"
r="nm"
ln="list"
26:
m="toprol-xl" 61:7 61:7
do="25 mg" 61:8 61:9
mo="nm"
f="daily" 61:10 61:10
du="nm"
r="nm"
ln="list"
27:
m="oxycodone" 62:1 62:1
do="5-10 mg" 62:2 62:3
mo="nm"
f="q.4h. p.r.n." 62:4 62:5
du="nm"
r="pain" 62:6 62:6
ln="list"
