1:
m="prednisone" 39:3 39:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="micronase" 44:5 44:5
do="10 mg" 44:6 44:7
mo="po" 44:8 44:8
f="bid" 44:9 44:9
du="nm"
r="nm"
ln="list"
3:
m="persantine" 44:11 44:11
do="60 mg" 44:12 44:13
mo="po" 44:14 44:14
f="tid" 45:0 45:0
du="nm"
r="nm"
ln="list"
4:
m="aspirin" 45:2 45:2
do="one" 45:3 45:3
mo="po" 45:4 45:4
f="q d" 45:5 45:6
du="nm"
r="nm"
ln="list"
5:
m="atenolol" 45:16 45:16
do="50 mg" 45:17 45:18
mo="po" 46:0 46:0
f="q d." 46:1 46:2
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 45:8 45:8
do="5 mg" 45:9 45:10
mo="po" 45:11 45:11
f="q d" 45:12 45:13
du="nm"
r="nm"
ln="narrative"
7:
m="lasix" 114:7 114:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="beta blocker" 115:1 115:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="heparin" 117:3 117:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="coumadin." 118:0 118:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="captopril." 119:4 119:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's afterload reduction" 118:3 118:6
ln="narrative"
12:
m="captopril" 137:10 137:10
do="37.5 mg" 138:0 138:1
mo="po" 138:2 138:2
f="tid" 138:3 138:3
du="nm"
r="nm"
ln="list"
13:
m="lasix" 137:3 137:3
do="40 mg" 137:4 137:5
mo="po" 137:6 137:6
f="q d" 137:7 137:8
du="nm"
r="nm"
ln="list"
14:
m="coumadin" 138:12 138:12
do="5 mg" 138:13 138:14
mo="po" 139:0 139:0
f="q h.s." 139:1 139:2
du="nm"
r="nm"
ln="list"
15:
m="ecotrin" 138:5 138:5
do="325 mg" 138:6 138:7
mo="po" 138:8 138:8
f="q d" 138:9 138:10
du="nm"
r="nm"
ln="list"
16:
m="isordil" 139:12 139:12
do="10 mg" 139:13 139:14
mo="po " 139:15 139:15
f="tid with meals" 139:16 140:1
du="nm"
r="nm"
ln="list"
17:
m="magnesium oxide" 139:4 139:5
do="two tablets" 139:6 139:7
mo="po" 139:8 139:8
f="q d" 139:9 139:10
du="nm"
r="nm"
ln="list"
18:
m="micronase" 140:4 140:4
do="10 mg" 140:5 140:6
mo="po" 140:7 140:7
f="bid." 140:8 140:8
du="nm"
r="nm"
ln="list"
