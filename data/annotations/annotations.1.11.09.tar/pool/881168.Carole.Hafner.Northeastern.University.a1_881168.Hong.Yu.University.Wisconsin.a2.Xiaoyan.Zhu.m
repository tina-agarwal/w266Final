1:
m="tylenol (acetaminophen )" 19:0 19:3
do="650 mg" 19:4 19:5
mo="po" 19:6 19:6
f="q4h prn" 19:7 19:8
du="nm"
r="headache" 19:9 19:9
ln="list"
2:
m="albuterol nebulizer" 20:0 20:1
do="2.5 mg" 20:2 20:3
mo="neb" 20:4 20:4
f="q2h prn" 20:5 21:0
du="nm"
r="shortness of breath" 21:1 21:3
ln="list"
3:
m="ecasa ( aspirin enteric coated )" 22:0 22:5
do="325 mg" 22:6 22:7
mo="po" 22:8 22:8
f="qd" 22:9 22:9
du="nm"
r="nm"
ln="list"
4:
m="colace ( docusate sodium )" 23:0 23:4
do="100 mg" 23:5 23:6
mo="po" 23:7 23:7
f="bid" 23:8 23:8
du="nm"
r="nm"
ln="list"
5:
m="lasix ( furosemide )" 24:0 24:3
do="80 mg" 24:4 24:5
mo="po" 24:6 24:6
f="bid" 24:7 24:7
du="nm"
r="nm"
ln="list"
6:
m="insulin nph human" 27:0 27:2
do="110 units" 27:3 27:4
mo="sc" 27:5 27:5
f="qam" 27:6 27:6
du="nm"
r="nm"
ln="list"
7:
m="insulin nph human" 28:0 28:2
do="30 units" 28:3 28:4
mo="sc" 28:5 28:5
f="qpm" 28:6 28:6
du="nm"
r="nm"
ln="list"
8:
m="NTG 1/150 ( nitroglycerin 1/150 ( 0.4 mg ) )" 29:0 29:9
do="1 tab" 30:0 30:1
mo="sl" 30:2 30:2
f="q5min x 3 prn" 30:3 30:6
du="nm"
r="chest pain" 30:7 30:8
ln="list"
9:
m="verapamil sustained releas" 31:0 31:2
do="240 mg" 31:3 31:4
mo="po" 31:5 31:5
f="bid" 31:6 31:6
du="nm"
r="nm"
ln="list"
10:
m="flovent ( fluticasone propionate )" 34:0 34:4
do="220 mcg" 34:5 34:6
mo="inh" 34:7 34:7
f="bid" 34:8 34:8
du="nm"
r="nm"
ln="list"
11:
m="diovan ( valsartan )" 35:0 35:3
do="160 mg" 35:4 35:5
mo="po" 35:6 35:6
f="qd" 35:7 35:7
du="number of doses required ( approximate ): 5" 36:0 36:7
r="nm"
ln="list"
12:
m="vioxx ( rofecoxib )" 37:0 37:3
do="12.5 mg" 37:4 37:5
mo="po" 37:6 37:6
f="qd" 37:7 37:7
du="nm"
r="nm"
ln="list"
13:
m="duoneb ( albuterol and ipratropium nebulizer )" 39:0 39:6
do="3/0.5 mg" 40:0 40:1
mo="inh" 40:2 40:2
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lipitor ( atorvastatin )" 41:0 41:3
do="10 mg" 41:4 41:5
mo="po" 41:6 41:6
f="qd" 41:7 41:7
du="nm"
r="nm"
ln="list"
15:
m="prilosec ( omeprazole )" 42:0 42:3
do="20 mg" 42:4 42:5
mo="po" 42:6 42:6
f="qd" 42:7 42:7
du="nm"
r="nm"
ln="list"
16:
m="lasix" 71:2 71:2
do="80" 71:0 71:0
mo="iv" 71:1 71:1
f="nm"
du="nm"
r="fluid overload" 70:2 70:3
ln="narrative"
17:
m="asa" 81:8 81:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="ccb" 81:12 81:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="statin" 81:10 81:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="duonebs" 87:1 87:1
do="nm"
mo="nm"
f="qid" 88:0 88:0
du="nm"
r="asthma" 86:6 86:6
ln="narrative"
21:
m="albuterol" 88:3 88:3
do="nm"
mo="nm"
f="q2hr" 88:2 88:2
du="nm"
r="nm"
ln="narrative"
22:
m="insulin regimen" 93:6 93:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="riss." 93:9 93:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="heparin" 104:3 104:3
do="5000" 104:4 104:4
mo="sc" 104:5 104:5
f="tid" 104:6 104:6
du="nm"
r="dvt ppx" 104:8 104:9
ln="narrative"
25:
m="ppi" 104:12 104:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="lasix" 111:1 111:1
do="nm"
mo="nm"
f="twice a day ( in the morning and at night )" 111:3 111:13
du="until you see dr. nicoll" 110:5 110:9
r="nm"
ln="narrative"
27:
m="lasix" 117:9 117:9
do="nm"
mo="nm"
f="bid" 117:10 117:10
du="nm"
r="nm"
ln="narrative"
28:
m="lasix" 117:9 117:9
do="nm"
mo="nm"
f="qd" 118:1 118:1
du="nm"
r="nm"
ln="narrative"
