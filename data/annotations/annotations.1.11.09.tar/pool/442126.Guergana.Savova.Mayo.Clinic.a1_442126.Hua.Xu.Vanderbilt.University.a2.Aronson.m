1:
m="lopressor" 18:0 18:0
do="nm"
mo="iv" 17:9 17:9
f="nm"
du="nm"
r="the patient's blood pressure" 17:2 17:5
ln="narrative"
2:
m="insulin" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="type ii diabetes mellitus" 29:3 30:0
ln="narrative"
3:
m="aspirin" 50:1 50:1
do="325 mg" 50:2 50:3
mo="nm"
f="q.d." 50:4 50:4
du="nm"
r="nm"
ln="list"
4:
m="atenolol" 50:6 50:6
do="125 mg" 50:7 50:8
mo="p.o." 50:9 50:9
f="b.i.d." 50:10 50:10
du="nm"
r="nm"
ln="list"
5:
m="axid" 51:8 51:8
do="150 mg" 51:9 51:10
mo="p.o." 52:0 52:0
f="b.i.d." 52:1 52:1
du="nm"
r="nm"
ln="list"
6:
m="captopril" 51:0 51:0
do="100 mg" 51:1 51:2
mo="p.o." 51:3 51:3
f="t.i.d." 51:4 51:4
du="nm"
r="nm"
ln="list"
7:
m="colace" 51:6 51:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="amlodipine" 52:3 52:3
do="10 mg" 52:4 52:5
mo="p.o." 52:6 52:6
f="q.d." 52:7 52:7
du="nm"
r="nm"
ln="list"
9:
m="imdur" 52:9 52:9
do="120 mg" 52:10 52:11
mo="p.o." 52:12 52:12
f="b.i.d." 52:13 52:13
du="nm"
r="nm"
ln="list"
10:
m="insulin nph" 53:1 53:2
do="22 units" 53:3 53:4
mo="nm"
f="q.a.m." 53:5 53:5
du="nm"
r="nm"
ln="list"
11:
m="insulin ... regular" 53:1 53:1,53:7 53:7
do="10 units" 53:8 53:9
mo="nm"
f="q.a.m." 53:10 53:10
du="nm"
r="nm"
ln="list"
12:
m="diltiazem" 65:9 65:9
do="10 mg/hr." 66:1 66:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="lopressor" 65:7 65:7
do="nm"
mo="iv" 65:6 65:6
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="lopressor" 69:9 69:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension" 68:1 68:1
ln="narrative"
15:
m="captopril" 70:0 70:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension" 68:1 68:1
ln="narrative"
16:
m="amlodipine" 71:6 71:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="further blood pressure control" 71:8 72:1
ln="narrative"
17:
m="coumadin" 76:2 76:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="anticoagulation" 76:0 76:0
ln="narrative"
18:
m="atenolol" 87:3 87:3
do="125 mg" 87:4 87:5
mo="p.o." 87:6 87:6
f="b.i.d." 87:7 87:7
du="nm"
r="nm"
ln="list"
19:
m="captopril" 88:0 88:0
do="100 mg" 88:1 88:2
mo="p.o." 88:3 88:3
f="t.i.d." 88:4 88:4
du="nm"
r="nm"
ln="list"
20:
m="colace" 88:6 88:6
do="100 mg" 88:7 88:8
mo="p.o." 88:9 88:9
f="t.i.d." 89:0 89:0
du="nm"
r="nm"
ln="list"
21:
m="insulin ... nph" 89:8 89:8,89:11 89:11
do="22 units" 89:9 89:10
mo="subcu" 89:12 89:12
f="q.a.m." 89:13 89:13
du="nm"
r="nm"
ln="list"
22:
m="insulin ... regular" 89:8 89:8,90:3 90:3
do="10 units" 90:1 90:2
mo="subcu" 90:4 90:4
f="q.a.m." 90:5 90:5
du="nm"
r="nm"
ln="list"
23:
m="lasix" 89:2 89:2
do="40 mg" 89:3 89:4
mo="p.o." 89:5 89:5
f="q.d." 89:6 89:6
du="nm"
r="nm"
ln="list"
24:
m="czi regular insulin" 90:7 90:9
do="sliding scale" 90:10 91:0
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="percocet" 91:2 91:2
do="1 to 2 tablets" 91:3 91:6
mo="p.o." 91:7 91:7
f="q3 - 4h p.r.n." 91:8 91:11
du="nm"
r="pain" 91:12 91:12
ln="list"
26:
m="zantac" 91:14 91:14
do="150 mg" 91:15 92:0
mo="p.o." 92:1 92:1
f="b.i.d." 92:2 92:2
du="nm"
r="nm"
ln="list"
27:
m="amlodipine" 92:14 92:14
do="5 mg" 92:15 93:0
mo="p.o." 93:1 93:1
f="q.d." 93:2 93:2
du="nm"
r="nm"
ln="list"
28:
m="coumadin" 92:4 92:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
