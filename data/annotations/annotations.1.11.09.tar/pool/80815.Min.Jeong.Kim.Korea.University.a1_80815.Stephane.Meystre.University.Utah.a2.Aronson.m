1:
m="meropenem" 11:4 11:4
do="nm"
mo="nm"
f="nm"
du="for 14 days" 11:5 11:7
r="bacteremia with multi-resistant klebsiella pneumoniae" 10:3 11:0
ln="narrative"
2:
m="meropenem" 16:10 16:10
do="nm"
mo="nm"
f="nm"
du="14 days" 16:7 16:8
r="klebsiella" 16:3 16:3
ln="narrative"
3:
m="fluids" 26:6 26:6
do="2 liters" 26:2 26:3
mo="iv" 26:5 26:5
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="vancomycin." 28:0 28:0
do="nm"
mo="p.o" 27:9 27:9
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="drug-eluting stent" 35:1 35:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 40:1 40:1
do="81 mg" 40:2 40:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="coumadin" 40:9 40:9
do="5 mg" 40:10 40:11
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 40:13 40:13
do="0.125 mg" 40:14 40:15
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="plavix" 40:5 40:5
do="75 mg" 40:6 40:7
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="lasix" 41:0 41:0
do="49 mg" 41:1 41:2
mo="nm"
f="daily" 41:3 41:3
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 41:5 41:5
do="10 mg" 41:6 41:7
mo="nm"
f="daily" 41:8 41:8
du="nm"
r="nm"
ln="list"
12:
m="lopressor" 41:10 41:10
do="25 mg" 41:11 41:12
mo="nm"
f="b.i.d." 41:13 41:13
du="nm"
r="nm"
ln="list"
13:
m="zocor" 41:15 41:15
do="80 mg" 41:16 41:17
mo="nm"
f="daily" 42:0 42:0
du="nm"
r="nm"
ln="list"
14:
m="flomax" 42:2 42:2
do="0.4 mg" 42:3 42:4
mo="nm"
f="daily" 42:5 42:5
du="nm"
r="nm"
ln="list"
15:
m="flovent" 42:7 42:7
do="110 mcg" 42:8 42:9
mo="nm"
f="b.i.d." 42:10 42:10
du="nm"
r="nm"
ln="list"
16:
m="vancomycin." 82:7 82:7
do="nm"
mo="p.o." 82:6 82:6
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="lactobacillus" 87:0 87:0
do="nm"
mo="p.o." 87:1 87:1
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="vancomycin" 91:3 91:3
do="nm"
mo="p.o." 91:2 91:2
f="nm"
du="2-week course" 91:0 91:1
r="nm"
ln="narrative"
19:
m="aspirin" 93:7 93:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
20:
m="beta-blocker." 94:4 94:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="plavix" 94:0 94:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="statin" 94:2 94:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="gentle hydration therapy" 97:0 97:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertension" 97:9 97:9
ln="narrative"
24:
m="lasix" 99:2 99:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="extra fluid" 99:11 100:0
ln="narrative"
25:
m="lasix" 101:0 101:0
do="40 mg" 101:1 101:2
mo="p.o." 101:3 101:3
f="daily" 101:4 101:4
du="nm"
r="nm"
ln="narrative"
26:
m="lisinopril" 102:1 102:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="lisinopril" 103:9 103:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="coumadin" 110:3 110:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="coumadin" 112:1 112:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="coumadin" 113:5 113:5
do="nm"
mo="nm"
f="nm"
du="until inr fell below 3" 113:6 114:0
r="nm"
ln="narrative"
31:
m="coumadin" 114:3 114:3
do="6 mg" 114:6 114:7
mo="p.o." 114:8 114:8
f="daily" 114:9 114:9
du="nm"
r="nm"
ln="narrative"
32:
m="coumadin" 116:6 116:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="vancomycin" 128:4 128:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="aspirin" 130:3 130:3
do="81 mg" 130:4 130:5
mo="p.o." 130:6 130:6
f="daily" 130:7 130:7
du="nm"
r="nm"
ln="list"
35:
m="plavix" 130:9 130:9
do="75 mg" 131:0 131:1
mo="p.o." 131:2 131:2
f="daily" 131:3 131:3
du="nm"
r="nm"
ln="list"
36:
m="digoxin" 131:5 131:5
do="0.125 mg" 131:6 131:7
mo="p.o." 131:8 131:8
f="daily" 131:9 131:9
du="nm"
r="nm"
ln="list"
37:
m="nexium" 131:11 131:11
do="20 mg" 131:12 131:13
mo="p.o." 131:14 131:14
f="daily" 132:0 132:0
du="nm"
r="nm"
ln="list"
38:
m="flovent" 132:2 132:2
do="110 mcg" 132:3 132:4
mo="inhale" 132:5 132:5
f="b.i.d." 132:6 132:6
du="nm"
r="nm"
ln="list"
39:
m="lasix" 132:8 132:8
do="40 mg" 132:9 132:10
mo="p.o." 132:11 132:11
f="daily" 132:12 132:12
du="nm"
r="nm"
ln="list"
40:
m="lactobacillus" 133:0 133:0
do="2 tabs" 133:1 133:2
mo="p.o." 133:3 133:3
f="t.i.d." 133:4 133:4
du="nm"
r="nm"
ln="list"
41:
m="metoprolol" 133:6 133:6
do="25 mg" 133:7 133:8
mo="p.o." 133:9 133:9
f="b.i.d." 133:10 133:10
du="nm"
r="nm"
ln="list"
42:
m="flomax" 134:8 134:8
do="0.4 mg" 134:9 134:10
mo="p.o." 134:11 134:11
f="every evening" 134:12 135:0
du="nm"
r="nm"
ln="list"
43:
m="simvastatin" 134:0 134:0
do="80 mg" 134:1 134:2
mo="p.o." 134:3 134:3
f="at bed time" 134:4 134:6
du="nm"
r="nm"
ln="list"
44:
m="vancomycin" 135:2 135:2
do="250 mg" 135:3 135:4
mo="p.o." 135:5 135:5
f="every 6 hours" 135:6 135:8
du="x8 days" 135:9 135:10
r="nm"
ln="list"
45:
m="coumadin" 136:2 136:2
do="5 mg" 136:3 136:4
mo="p.o." 136:5 136:5
f="every evening." 136:6 136:7
du="nm"
r="nm"
ln="list"
