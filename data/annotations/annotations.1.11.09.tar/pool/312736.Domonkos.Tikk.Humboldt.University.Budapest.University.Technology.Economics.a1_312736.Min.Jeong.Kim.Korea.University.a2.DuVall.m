1:
m="lopressor" 20:8 20:8
do="50 mg" 20:9 20:10
mo="p.o." 21:0 21:0
f="b.i.d." 21:1 21:1
du="nm"
r="nm"
ln="list"
2:
m="simvastatin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="allopurinol" 21:4 21:4
do="300 mg" 21:5 21:6
mo="nm"
f="once a day." 21:7 22:1
du="nm"
r="nm"
ln="list"
4:
m="captopril" 22:13 22:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="lasix" 22:4 22:4
do="40 mg" 22:5 22:6
mo="nm"
f="three times a day." 22:7 22:10
du="nm"
r="nm"
ln="list"
6:
m="multivitamin" 23:4 23:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="potassium replacement" 23:0 23:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="enteric coated aspirin" 48:5 48:7
do="325 mg" 48:8 48:9
mo="p.o." 48:10 48:10
f="q. day." 49:0 49:1
du="nm"
r="nm"
ln="list"
9:
m="lithium" 49:4 49:4
do="300 mg" 49:5 49:6
mo="nm"
f="twice a day." 49:7 49:9
du="nm"
r="nm"
ln="list"
10:
m="potassium supplementation" 50:2 50:3
do="20 meq" 50:4 50:5
mo="nm"
f="once a day." 50:6 50:8
du="nm"
r="nm"
ln="list"
11:
m="pravachol" 50:11 50:11
do="40 mg" 50:12 51:0
mo="nm"
f="once a day." 51:1 51:3
du="nm"
r="nm"
ln="list"
12:
m="glyburide" 51:6 51:6
do="1.25 mg" 51:7 51:8
mo="nm"
f="twice a day." 51:9 51:11
du="nm"
r="nm"
ln="list"
13:
m="parnate" 51:14 51:14
do="10 mg" 51:15 52:0
mo="nm"
f="twice a day." 52:1 52:3
du="nm"
r="nm"
ln="list"
14:
m="lasix" 52:6 52:6
do="20 mg" 52:7 52:8
mo="nm"
f="once a day." 52:9 52:11
du="nm"
r="nm"
ln="list"
