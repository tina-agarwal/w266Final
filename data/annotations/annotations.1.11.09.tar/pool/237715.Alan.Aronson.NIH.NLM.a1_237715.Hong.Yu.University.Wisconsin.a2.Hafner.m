1:
m="diuretics" 13:0 13:0
do="nm"
mo="nm"
f="nm"
du="three days" 13:2 13:3
r="nm"
ln="narrative"
2:
m="lasix" 16:10 16:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary edema" 16:4 16:5
ln="narrative"
3:
m="nitroglycerin" 16:8 16:8
do="nm"
mo="iv" 16:7 16:7
f="nm"
du="nm"
r="pulmonary edema" 16:4 16:5
ln="narrative"
4:
m="aspirin" 17:0 17:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary edema" 16:4 16:5
ln="narrative"
5:
m="beta-blockers" 17:4 17:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary edema" 16:4 16:5
ln="narrative"
6:
m="heparin" 17:2 17:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="pulmonary edema" 16:4 16:5
ln="narrative"
7:
m="aspirin" 29:0 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="hydralazine" 29:2 29:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="lasix" 29:10 29:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="nitroglycerin" 29:4 29:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="norvasc" 29:8 29:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="quinine" 29:6 29:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="albuterol" 30:4 30:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="famotidine." 30:7 30:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 30:2 30:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="toprol" 30:0 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
