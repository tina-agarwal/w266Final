1:
m="lopressor" 37:1 37:1
do="25" 37:2 37:2
mo="orally" 37:3 37:3
f="every 6 hours." 37:4 37:6
du="nm"
r="nm"
ln="list"
2:
m="diltiazem" 38:1 38:1
do="125 mg" 38:2 38:3
mo="orally" 38:4 38:4
f="daily." 38:5 38:5
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 39:1 39:1
do="325 mg" 39:2 39:3
mo="orally" 39:4 39:4
f="daily." 39:5 39:5
du="nm"
r="nm"
ln="list"
4:
m="furosemide" 40:1 40:1
do="20 mg" 40:2 40:3
mo="orally" 40:4 40:4
f="daily." 40:5 40:5
du="nm"
r="nm"
ln="list"
5:
m="methylprednisolone" 41:1 41:1
do="30 mg" 41:2 41:3
mo="iv" 41:4 41:4
f="every 8 hours." 41:5 41:7
du="nm"
r="nm"
ln="list"
6:
m="atorvastatin" 42:1 42:1
do="80 mg" 42:2 42:3
mo="orally" 42:4 42:4
f="daily." 42:5 42:5
du="nm"
r="nm"
ln="list"
7:
m="allopurinol" 43:1 43:1
do="100 mg" 43:2 43:3
mo="orally" 43:4 43:4
f="daily." 43:5 43:5
du="nm"
r="nm"
ln="list"
8:
m="ativan" 44:1 44:1
do="0.5 mg" 44:2 44:3
mo="orally" 44:4 44:4
f="at bedtime." 44:5 44:6
du="nm"
r="nm"
ln="list"
9:
m="nexium" 45:1 45:1
do="20 mg" 45:2 45:3
mo="orally" 45:4 45:4
f="daily." 45:5 45:5
du="nm"
r="nm"
ln="list"
10:
m="proscar" 46:1 46:1
do="5 mg" 46:2 46:3
mo="orally" 46:4 46:4
f="every night." 46:5 46:6
du="nm"
r="nm"
ln="list"
11:
m="alcohol" 67:7 67:7
do="nm"
mo="drip" 67:8 67:8
f="nm"
du="nm"
r="alcohol use." 68:3 68:4
ln="narrative"
12:
m="haldol" 70:5 70:5
do="nm"
mo="nm"
f="p.r.n." 70:8 70:8
du="during the hospital course" 71:2 71:5
r="agitation" 71:1 71:1
ln="narrative"
13:
m="beta-blockers" 78:7 78:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="statins." 78:9 78:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
15:
m="fluid" 80:0 80:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotensive" 79:9 79:9
ln="narrative"
16:
m="vasopressor" 80:3 80:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotensive" 79:9 79:9
ln="narrative"
17:
m="insulin." 96:2 96:2
do="nm"
mo="subcu" 96:1 96:1
f="nm"
du="nm"
r="tight glycemic control" 94:2 94:4
ln="narrative"
18:
m="prednisone" 96:8 96:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="copd" 97:3 97:3
ln="narrative"
19:
m="prednisone" 96:8 96:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="his postop frequent bronchospastic events" 97:6 98:1
ln="narrative"
20:
m="aspirin" 99:7 99:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="incomplete coronary vascularization" 100:4 100:6
ln="narrative"
21:
m="plavix" 100:0 100:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="incomplete coronary vascularization" 100:4 100:6
ln="narrative"
22:
m="antibiotic" 108:0 108:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
23:
m="antibiotics" 109:6 109:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="pneumonias." 108:6 108:6
ln="narrative"
24:
m="tylenol suppository" 125:1 125:2
do="650 mg" 125:3 125:4
mo="nm"
f="every 6 hours." 125:5 125:7
du="nm"
r="nm"
ln="list"
25:
m="toradol" 126:1 126:1
do="10 mg" 126:3 126:4
mo="orally" 126:2 126:2
f="every 4 hours as needed" 126:5 126:9
du="nm"
r="pain" 126:11 126:11
ln="list"
26:
m="haldol liquid" 127:1 127:2
do="1 to 3 mg" 127:3 127:6
mo="orally" 127:7 127:7
f="every 4 hours as needed" 127:8 127:12
du="nm"
r="agitation." 128:0 128:0
ln="list"
27:
m="nexium" 129:1 129:1
do="20 mg" 129:2 129:3
mo="nm"
f="everyday." 129:4 129:4
du="nm"
r="nm"
ln="list"
28:
m="morphine liquid" 130:1 130:2
do="5 to 20 mg" 130:3 130:6
mo="orally" 130:7 130:7
f="every 2 hours as needed" 130:8 130:12
du="nm"
r="pain" 131:0 131:0
ln="list"
29:
m="morphine liquid" 130:1 130:2
do="5 to 20 mg" 130:3 130:6
mo="orally" 130:7 130:7
f="every 2 hours as needed" 130:8 130:12
du="nm"
r="shortness of breath" 131:3 131:5
ln="list"
