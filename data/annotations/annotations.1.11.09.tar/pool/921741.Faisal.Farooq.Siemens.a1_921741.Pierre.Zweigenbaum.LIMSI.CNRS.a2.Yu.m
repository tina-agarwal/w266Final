1:
m="aldactone" 35:0 35:0
do="25 mg" 35:1 35:2
mo="nm"
f="once a day" 35:3 35:5
du="nm"
r="nm"
ln="list"
2:
m="k-dur" 35:7 35:7
do="40 meq" 35:8 35:9
mo="nm"
f="once a day" 35:10 35:12
du="nm"
r="nm"
ln="list"
3:
m="lisinopril" 35:14 35:14
do="2.5 mg" 36:0 36:1
mo="nm"
f="once a day" 36:2 36:4
du="nm"
r="nm"
ln="list"
4:
m="digoxin" 36:14 36:14
do="0.125" 36:15 36:15
mo="nm"
f="once a day" 37:0 37:2
du="nm"
r="nm"
ln="list"
5:
m="isordil" 36:6 36:6
do="20 mg" 36:7 36:8
mo="nm"
f="three times a day" 36:9 36:12
du="nm"
r="nm"
ln="list"
6:
m="metolazone" 37:10 37:10
do="nm"
mo="nm"
f="p.r.n." 37:11 37:11
du="nm"
r="volume overload." 38:0 38:1
ln="list"
7:
m="torsemide" 37:4 37:4
do="200 mg" 37:5 37:6
mo="nm"
f="twice" 37:7 37:7
du="nm"
r="nm"
ln="list"
8:
m="torsemide" 54:2 54:2
do="200 mg" 54:3 54:4
mo="iv" 54:1 54:1
f="b.i.d." 54:5 54:5
du="nm"
r="nm"
ln="narrative"
9:
m="ace inhibitor" 56:8 56:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="blood pressures" 57:4 57:5
ln="narrative"
10:
m="isordil" 56:6 56:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="zaroxolyn" 56:0 56:0
do="nm"
mo="drip" 55:9 55:9
f="p.r.n." 56:1 56:1
du="nm"
r="nm"
ln="narrative"
12:
m="dopamine" 60:2 60:2
do="low-dose...2 mcg" 60:1 60:1,60:5 60:6
mo="drips" 60:3 60:3
f="per hour" 60:7 60:8
du="nm"
r="nm"
ln="narrative"
13:
m="lasix drip" 62:1 62:2
do="10 mg" 62:4 62:5
mo="nm"
f="an hour" 62:6 62:7
du="nm"
r="nm"
ln="narrative"
14:
m="lasix drip" 62:1 62:2
do="10 mg" 62:4 62:5
mo="nm"
f="nm"
du="an hour" 62:11 62:12
r="nm"
ln="narrative"
15:
m="lasix bolus." 63:1 63:2
do="200 mg" 62:14 62:15
mo="iv" 63:0 63:0
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="lasix drip" 63:8 63:9
do="20" 63:11 63:11
mo="nm"
f="an hour" 63:12 64:0
du="nm"
r="nm"
ln="narrative"
17:
m="dopamine" 64:2 64:2
do="2 mcg" 64:4 64:5
mo="nm"
f="per hour" 64:6 64:7
du="nm"
r="nm"
ln="narrative"
18:
m="dopamine" 81:7 81:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="lasix drip" 81:12 82:0
do="nm"
mo="nm"
f="nm"
du="for one more day." 82:1 82:4
r="nm"
ln="narrative"
20:
m="lasix" 82:9 82:9
do="nm"
mo="drip" 82:10 82:10
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="torsemide" 83:5 83:5
do="200" 83:6 83:6
mo="p.o." 83:8 83:8
f="b.i.d." 83:7 83:7
du="nm"
r="nm"
ln="narrative"
22:
m="isordil" 89:2 89:2
do="10 mg" 89:4 89:5
mo="nm"
f="t.i.d." 89:6 89:6
du="for the last 24 hours" 89:7 89:11
r="blood pressures" 90:1 90:2
ln="narrative"
23:
m="potassium" 90:10 90:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
24:
m="aldactone" 92:3 92:3
do="25 mg" 92:6 92:7
mo="nm"
f="b.i.d." 92:8 92:8
du="nm"
r="his potassium" 90:9 90:10
ln="narrative"
25:
m="aldactone" 92:3 92:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
26:
m="k-dur" 94:0 94:0
do="20 meq" 94:7 94:8
mo="nm"
f="a day." 94:9 94:10
du="nm"
r="nm"
ln="narrative"
27:
m="k-dur" 94:0 94:0
do="40 meq" 94:2 94:3
mo="nm"
f="a day" 94:4 94:5
du="nm"
r="nm"
ln="narrative"
28:
m="digoxin" 101:8 101:8
do="0.125 mg" 101:9 101:10
mo="nm"
f="once a day" 102:0 102:2
du="nm"
r="nm"
ln="list"
29:
m="aldactone" 102:9 102:9
do="25 mg" 102:10 102:11
mo="nm"
f="b.i.d." 102:12 102:12
du="nm"
r="nm"
ln="narrative"
30:
m="torsemide" 102:4 102:4
do="200 mg" 102:5 102:6
mo="nm"
f="b.i.d." 102:7 102:7
du="nm"
r="nm"
ln="list"
31:
m="folate" 103:12 103:12
do="5 mg" 103:13 104:0
mo="nm"
f="nm"
du="nm"
r="elevated homocystine" 104:8 104:9
ln="list"
32:
m="isordil" 103:0 103:0
do="10 mg" 103:1 103:2
mo="nm"
f="t.i.d." 103:3 103:3
du="nm"
r="nm"
ln="narrative"
33:
m="k-dur" 103:6 103:6
do="20 meq" 103:7 103:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="ambien" 105:3 105:3
do="nm"
mo="nm"
f="at night p.r.n." 105:4 105:6
du="nm"
r="insomnia." 105:8 105:8
ln="list"
