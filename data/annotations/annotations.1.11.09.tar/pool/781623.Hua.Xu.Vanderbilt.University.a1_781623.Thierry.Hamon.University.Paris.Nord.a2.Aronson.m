1:
m="benadryl ( diphenhydramine hcl )" 19:0 19:4
do="25 mg" 19:5 19:6
mo="po" 19:7 19:7
f="q6h prn" 19:8 19:9
du="nm"
r="itching" 19:10 19:10
ln="list"
2:
m="furosemide" 20:0 20:0
do="40 mg" 20:1 20:2
mo="po" 20:3 20:3
f="qd" 20:4 20:4
du="nm"
r="nm"
ln="list"
3:
m="glyburide" 21:0 21:0
do="2.5 mg" 21:1 21:2
mo="po" 21:3 21:3
f="qd" 21:4 21:4
du="nm"
r="nm"
ln="list"
4:
m="lisinopril" 22:0 22:0
do="10 mg" 22:1 22:2
mo="po" 22:3 22:3
f="qd" 22:4 22:4
du="nm"
r="nm"
ln="list"
5:
m="kcl slow release" 25:3 25:5
do="nm"
mo="po" 25:6 25:6
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 26:3 26:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="potassium chloride" 26:5 27:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="coumadin ( warfarin sodium )" 28:0 28:4
do="2.5 mg" 28:5 28:6
mo="po" 28:7 28:7
f="qpm" 28:8 28:8
du="nm"
r="nm"
ln="list"
9:
m="bactrim ds" 34:3 34:4
do="nm"
mo="po" 34:5 34:5
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="sulfamethoxazole" 35:4 35:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="warfarin" 35:2 35:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="simvastatin" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="warfarin" 38:5 38:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="simvastatin" 40:0 40:0
do="20 mg" 40:1 40:2
mo="po" 40:3 40:3
f="qhs" 40:4 40:4
du="nm"
r="nm"
ln="list"
15:
m="coumadin" 45:3 45:3
do="nm"
mo="po" 45:4 45:4
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="simvastatin" 46:3 46:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="warfarin" 46:5 46:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="simvastatin" 49:5 49:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="warfarin" 49:3 49:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="linezolid" 51:0 51:0
do="600 mg" 51:1 51:2
mo="po" 51:3 51:3
f="bid" 51:4 51:4
du="nm"
r="nm"
ln="list"
21:
m="linezolid" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="tramadol hcl" 56:2 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="coumadin" 90:3 90:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="chronic af" 89:9 89:10
ln="narrative"
24:
m="abx." 95:0 95:0
do="nm"
mo="iv" 94:6 94:6
f="nm"
du="nm"
r="nm"
ln="narrative"
25:
m="unasyn" 112:9 112:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetic foot ulcer" 111:5 111:7
ln="narrative"
26:
m="unasyn" 115:6 115:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="bactrim" 116:8 116:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
28:
m="linezolid" 116:0 116:0
do="nm"
mo="po" 115:10 115:10
f="nm"
du="nm"
r="nm"
ln="narrative"
29:
m="unasyn." 121:13 121:13
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
30:
m="benadry" 123:0 123:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
31:
m="unasyn" 123:3 123:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="glyburide" 127:5 127:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="dmii" 127:2 127:2
ln="narrative"
33:
m="riss" 127:10 127:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="dmii" 127:2 127:2
ln="narrative"
34:
m="coumadin." 128:11 128:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="af/sss" 128:2 128:2
ln="narrative"
35:
m="antibiotics" 140:2 140:2
do="nm"
mo="nm"
f="nm"
du="for 7 days" 140:3 140:5
r="nm"
ln="narrative"
