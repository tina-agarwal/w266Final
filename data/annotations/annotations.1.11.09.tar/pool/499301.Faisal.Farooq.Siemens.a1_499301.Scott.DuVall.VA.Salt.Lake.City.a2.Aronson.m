1:
m="azithromycin" 31:5 31:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="ceftriaxone" 31:3 31:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="flagyl" 31:7 31:7
do="nm"
mo="iv" 31:8 31:8
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lasix" 32:1 32:1
do="40 mg" 32:2 32:3
mo="iv" 32:4 32:4
f="nm"
du="x1." 32:5 32:5
r="nm"
ln="narrative"
5:
m="coumadin" 34:0 34:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="atrial fibrillation" 33:5 33:6
ln="narrative"
6:
m="renagel" 44:1 44:1
do="one tablet" 44:2 44:3
mo="nm"
f="with dinner" 44:4 44:5
du="nm"
r="nm"
ln="list"
7:
m="diovan" 45:1 45:1
do="120 mg" 45:2 45:3
mo="nm"
f="daily." 45:4 45:4
du="nm"
r="nm"
ln="list"
8:
m="procrit" 46:1 46:1
do="5000 units" 46:2 46:3
mo="subcutaneous" 46:4 46:4
f="q. week" 46:5 46:6
du="nm"
r="nm"
ln="list"
9:
m="norvasc" 47:1 47:1
do="5 mg" 47:2 47:3
mo="nm"
f="q.a.m." 47:4 47:4
du="nm"
r="nm"
ln="narrative"
10:
m="norvasc" 48:1 48:1
do="2.5 mg" 48:2 48:3
mo="nm"
f="q.p.m" 48:4 48:4
du="nm"
r="nm"
ln="list"
11:
m="imdur" 49:1 49:1
do="30 mg" 49:2 49:3
mo="nm"
f="twice daily." 49:4 49:5
du="nm"
r="nm"
ln="list"
12:
m="insulin." 50:6 50:6
do="sliding scale" 50:4 50:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="novolog" 50:1 50:1
do="4/4/5" 50:2 50:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lantus" 51:1 51:1
do="8 units" 51:2 51:3
mo="nm"
f="nightly" 51:4 51:4
du="nm"
r="nm"
ln="list"
15:
m="nexium" 52:1 52:1
do="40 mg" 52:2 52:3
mo="nm"
f="twice daily." 52:4 52:5
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 53:1 53:1
do="4 mg" 53:2 53:3
mo="p.o." 53:4 53:4
f="q.p.m" 53:5 53:5
du="nm"
r="nm"
ln="list"
17:
m="caltrate plus d" 54:1 54:3
do="one tab" 54:4 54:5
mo="nm"
f="twice daily." 54:6 54:7
du="nm"
r="nm"
ln="list"
18:
m="iron sulfate" 55:1 55:2
do="325 mg" 55:3 55:4
mo="nm"
f="twice daily." 55:5 55:6
du="nm"
r="nm"
ln="list"
19:
m="lasix" 56:1 56:1
do="40 mg" 56:7 56:8
mo="p.o." 56:9 56:9
f="q.p.m." 56:10 56:10
du="nm"
r="nm"
ln="list"
20:
m="lasix" 56:1 56:1
do="80 mg" 56:2 56:3
mo="p.o." 56:4 56:4
f="q.a.m." 56:5 56:5
du="nm"
r="nm"
ln="list"
21:
m="azithromycin" 105:2 105:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="aspiration pneumonia." 103:6 104:0
ln="narrative"
22:
m="ceftriaxone" 105:0 105:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="aspiration pneumonia." 103:6 104:0
ln="list"
23:
m="flagyl" 105:4 105:4
do="nm"
mo="iv" 105:5 105:5
f="nm"
du="nm"
r="aspiration pneumonia." 103:6 104:0
ln="narrative"
24:
m="cefpodoxime" 106:0 106:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="aspiration pneumonia." 103:6 104:0
ln="narrative"
25:
m="flagyl" 106:2 106:2
do="nm"
mo="p.o." 106:3 106:3
f="nm"
du="nm"
r="aspiration pneumonia." 103:6 104:0
ln="narrative"
26:
m="azithromycin" 108:6 108:6
do="nm"
mo="iv" 108:7 108:7
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ceftriaxone" 108:2 108:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="febrile" 107:1 107:1
ln="narrative"
28:
m="flagyl" 108:4 108:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="febrile" 107:1 107:1
ln="narrative"
29:
m="cefpodoxime" 111:8 111:8
do="nm"
mo="nm"
f="nm"
du="an additional six days" 111:3 111:6
r="nm"
ln="narrative"
30:
m="azithromycin" 112:2 112:2
do="nm"
mo="p.o." 112:3 112:3
f="nm"
du="an additional six days" 111:3 111:6
r="nm"
ln="list"
31:
m="flagyl" 112:0 112:0
do="nm"
mo="p.o." 112:3 112:3
f="nm"
du="an additional six days" 111:3 111:6
r="nm"
ln="narrative"
32:
m="lactobacillus" 113:6 113:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="a probiotic agent." 113:8 114:0
ln="narrative"
33:
m="lasix" 120:1 120:1
do="40 mg" 119:12 119:13
mo="iv" 120:0 120:0
f="nm"
du="nm"
r="pneumonia." 119:7 119:7
ln="narrative"
34:
m="procrit" 135:10 135:10
do="5000 units" 136:0 136:1
mo="subcutaneous injection" 136:2 136:3
f="weekly" 135:9 135:9
du="nm"
r="nm"
ln="narrative"
35:
m="iron supplementation" 137:6 137:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
36:
m="lasix" 149:8 149:8
do="40 mg" 151:3 151:4
mo="nm"
f="q.p.m." 151:5 151:5
du="nm"
r="gentle diuresis" 148:10 149:0
ln="narrative"
37:
m="lasix" 149:8 149:8
do="80 mg" 149:9 149:10
mo="p.o." 149:11 149:11
f="twice daily" 150:0 150:1
du="nm"
r="gentle diuresis" 148:10 149:0
ln="narrative"
38:
m="lasix" 149:8 149:8
do="80 mg" 150:13 151:0
mo="nm"
f="q.a.m." 151:1 151:1
du="nm"
r="gentle diuresis" 148:10 149:0
ln="narrative"
39:
m="norvasc" 158:9 158:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's blood pressure" 157:0 157:3
ln="narrative"
40:
m="valsartan" 158:7 158:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="the patient's blood pressure" 157:0 157:3
ln="narrative"
41:
m="imdur" 159:8 159:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="home regimen" 162:5 162:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="coumadin" 165:0 165:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
44:
m="antibiotic" 166:3 166:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="coumadin." 168:6 168:6
do="a reduced dose" 168:2 168:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="coumadin" 169:7 169:7
do="1 mg" 169:8 169:9
mo="nm"
f="nightly" 169:10 169:10
du="while still on antibiotics" 169:11 170:1
r="nm"
ln="narrative"
47:
m="antibiotics" 170:1 170:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="insulin" 184:4 184:4
do="sliding scale" 184:2 184:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
49:
m="lantus" 184:0 184:0
do="home dose" 183:8 183:9
mo="nm"
f="nm"
du="nm"
r="diabetes:" 183:1 183:1
ln="narrative"
50:
m="novolog insulin" 184:6 184:7
do="nm"
mo="nm"
f="q.a.c." 185:0 185:0
du="nm"
r="nm"
ln="narrative"
51:
m="lantus" 186:2 186:2
do="titrated up" 186:5 186:6
mo="nm"
f="nm"
du="nm"
r="glucose control" 186:9 187:0
ln="narrative"
52:
m="lantus" 188:6 188:6
do="8 units" 189:6 189:7
mo="subcu" 189:8 189:8
f="nightly." 189:9 189:9
du="nm"
r="nm"
ln="narrative"
53:
m="lantus" 188:6 188:6
do="increased doses" 188:3 188:4
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="insulin" 190:10 190:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
55:
m="lantus" 191:2 191:2
do="8 units" 191:3 191:4
mo="nm"
f="nightly " 191:5 191:5
du="nm"
r="nm"
ln="list"
56:
m="novolog" 191:7 191:7
do="4 units" 191:8 191:9
mo="nm"
f="with breakfast" 191:10 192:0
du="nm"
r="nm"
ln="narrative"
57:
m="novolog" 191:7 191:7
do="4 units" 192:2 192:3
mo="nm"
f="with lunch" 192:4 192:5
du="nm"
r="nm"
ln="narrative"
58:
m="novolog" 191:7 191:7
do="5 units" 192:7 192:8
mo="nm"
f="with dinner" 192:9 192:10
du="nm"
r="nm"
ln="narrative"
59:
m="insulin" 193:2 193:2
do="sliding scale" 193:0 193:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="ppi." 195:3 195:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="teds/coumadin" 195:1 195:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
62:
m="norvasc" 210:1 210:1
do="5 mg" 210:2 210:3
mo="p.o." 210:4 210:4
f="q.a.m." 210:5 210:5
du="nm"
r="nm"
ln="list"
63:
m="norvasc" 211:1 211:1
do="2.5 mg" 211:2 211:3
mo="nm"
f="q.p.m" 211:4 211:4
du="nm"
r="nm"
ln="list"
64:
m="azithromycin" 212:1 212:1
do="250 mg" 212:2 212:3
mo="p.o." 212:4 212:4
f="daily" 212:5 212:5
du="x6 doses" 212:6 212:7
r="nm"
ln="list"
65:
m="caltrate 600 plus d" 213:1 213:4
do="one tablet" 213:5 213:6
mo="p.o." 213:7 213:7
f="twice daily" 213:8 213:9
du="nm"
r="nm"
ln="list"
66:
m="cefpodoxime" 214:1 214:1
do="200 mg" 214:2 214:3
mo="p.o." 214:4 214:4
f="daily" 214:5 214:5
du="x6 doses" 214:6 214:7
r="nm"
ln="list"
67:
m="colace" 215:1 215:1
do="100 mg" 215:2 215:3
mo="p.o." 215:4 215:4
f="twice daily as needed" 215:5 215:8
du="nm"
r="constipation" 215:10 215:10
ln="list"
68:
m="procrit" 216:1 216:1
do="5000 units" 216:2 216:3
mo="subcutaneous" 216:4 216:4
f="q. week" 216:5 216:6
du="nm"
r="nm"
ln="list"
69:
m="nexium" 217:1 217:1
do="40 mg" 217:2 217:3
mo="p.o." 217:4 217:4
f="daily" 217:5 217:5
du="nm"
r="nm"
ln="list"
70:
m="ferrous sulfate" 218:1 218:2
do="325 mg" 218:3 218:4
mo="p.o." 218:5 218:5
f="b.i.d." 218:6 218:6
du="nm"
r="nm"
ln="list"
71:
m="lasix" 219:1 219:1
do="80 mg" 219:2 219:3
mo="nm"
f="twice daily." 219:4 219:5
du="nm"
r="nm"
ln="list"
72:
m="novolog" 220:1 220:1
do="sliding scale" 220:2 220:3
mo="subcutaneous" 220:4 220:4
f="with meals." 220:5 220:6
du="nm"
r="nm"
ln="list"
73:
m="novolog" 221:1 221:1
do="4 units" 221:2 221:3
mo="subcutaneous" 221:4 221:4
f="with breakfast...with lunch" 221:5 221:6,221:8 221:9
du="nm"
r="nm"
ln="list"
74:
m="novolog" 221:1 221:1
do="5 units" 222:0 222:1
mo="subcutaneous" 221:4 221:4
f="with dinner" 222:2 222:3
du="nm"
r="nm"
ln="list"
75:
m="glargine" 223:3 223:3
do="8 units" 223:4 223:5
mo="subcutaneous" 223:6 223:6
f="daily." 223:7 223:7
du="nm"
r="nm"
ln="list"
76:
m="insulin" 223:1 223:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
77:
m="isosorbide mononitrate" 224:1 224:2
do="30 mg" 224:3 224:4
mo="p.o." 224:5 224:5
f="twice daily." 224:6 224:7
du="nm"
r="nm"
ln="list"
78:
m="lactobacillus" 225:1 225:1
do="two tablets" 225:2 225:3
mo="p.o." 225:4 225:4
f="three times daily" 225:5 225:7
du="x25 doses." 225:8 225:9
r="nm"
ln="list"
79:
m="flagyl" 226:1 226:1
do="500 mg" 226:2 226:3
mo="p.o." 226:4 226:4
f="q.8 h." 226:5 226:6
du="x19 doses." 226:7 226:8
r="nm"
ln="list"
80:
m="senna tablets" 227:1 227:2
do="one tablet" 227:3 227:4
mo="p.o." 227:5 227:5
f="twice daily as needed" 227:6 227:9
du="nm"
r="constipation" 228:0 228:0
ln="list"
81:
m="sevelamer" 229:1 229:1
do="400 mg" 229:2 229:3
mo="p.o." 229:4 229:4
f="q.p.m." 229:5 229:5
du="nm"
r="nm"
ln="list"
82:
m="diovan" 230:1 230:1
do="120 mg" 230:2 230:3
mo="p.o." 230:4 230:4
f="daily" 230:5 230:5
du="nm"
r="nm"
ln="list"
83:
m="coumadin" 231:1 231:1
do="1 mg" 231:2 231:3
mo="p.o." 231:4 231:4
f="q.p.m." 231:5 231:5
du="nm"
r="nm"
ln="list"
