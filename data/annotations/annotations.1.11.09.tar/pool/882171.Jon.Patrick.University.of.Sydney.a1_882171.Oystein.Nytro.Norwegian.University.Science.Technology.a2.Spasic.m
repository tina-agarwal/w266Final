1:
m="nitroglycerins." 23:7 23:7
do="two" 23:5 23:5
mo="sublingual" 23:6 23:6
f="nm"
du="nm"
r="substernal chest pain" 23:0 23:2
ln="narrative"
2:
m="aspirin" 34:5 34:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="beta blockers" 34:7 34:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="nitroglycerin." 35:0 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="nitroglycerins" 48:10 48:10
do="two" 48:8 48:8
mo="sublingual" 48:9 48:9
f="nm"
du="nm"
r="symptoms" 49:3 49:3
ln="narrative"
6:
m="benadryl" 51:9 51:9
do="50 mg" 51:10 51:11
mo="nm"
f="t.i.d." 52:0 52:0
du="nm"
r="nm"
ln="list"
7:
m="cardizem cd" 51:6 51:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="glucotrol" 51:1 51:1
do="20 mg" 51:2 51:3
mo="nm"
f="q.d." 51:4 51:4
du="nm"
r="nm"
ln="list"
9:
m="hydrochlorothiazide" 52:7 52:7
do="12.5 mg" 53:0 53:1
mo="nm"
f="q.d." 53:2 53:2
du="nm"
r="nm"
ln="list"
10:
m="provastatin" 52:2 52:2
do="20 mg" 52:3 52:4
mo="nm"
f="q.d." 52:5 52:5
du="nm"
r="nm"
ln="list"
11:
m="aspirin" 53:9 53:9
do="1" 53:10 53:10
mo="nm"
f="q.d." 53:11 53:11
du="nm"
r="nm"
ln="list"
12:
m="lopressor" 53:13 53:13
do="75 mg" 53:14 54:0
mo="nm"
f="q.d." 54:1 54:1
du="nm"
r="nm"
ln="list"
13:
m="trazadone" 53:4 53:4
do="50 mg" 53:5 53:6
mo="nm"
f="q.h.s." 53:7 53:7
du="nm"
r="nm"
ln="list"
14:
m="ambien" 54:7 54:7
do="5 mg" 54:8 54:9
mo="nm"
f="q.h.s." 54:10 54:10
du="nm"
r="nm"
ln="list"
15:
m="nitroglycerin" 54:3 54:3
do="nm"
mo="sublingual" 54:4 54:4
f="p.r.n." 54:5 54:5
du="nm"
r="nm"
ln="list"
16:
m="oxygen" 60:0 60:0
do="one liter" 59:7 59:8
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="axid" 83:6 83:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="gastroesophageal reflux disease" 84:2 84:4
ln="narrative"
18:
m="maalox" 85:1 85:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="gastroesophageal reflux disease" 84:2 84:4
ln="narrative"
19:
m="glucotrol" 86:2 86:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="diabetes mellitus" 86:4 86:5
ln="narrative"
20:
m="dobutamine" 94:7 94:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
21:
m="dobutamine" 95:5 95:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="atenolol" 103:3 103:3
do="100 mg" 103:4 103:5
mo="p.o." 103:6 103:6
f="q.d." 103:7 103:7
du="nm"
r="nm"
ln="list"
23:
m="ecasa" 104:0 104:0
do="325 mg" 104:1 104:2
mo="nm"
f="q.d." 104:3 104:3
du="nm"
r="nm"
ln="list"
24:
m="glucotrol" 104:5 104:5
do="20 mg" 104:6 104:7
mo="nm"
f="b.i.d." 104:8 104:8
du="nm"
r="nm"
ln="list"
25:
m="hydrochlorothiazide" 105:0 105:0
do="12.5 mg" 105:1 105:2
mo="p.o." 105:3 105:3
f="q.d." 105:4 105:4
du="nm"
r="nm"
ln="list"
26:
m="trazadone" 105:6 105:6
do="50 mg" 105:7 105:8
mo="p.o." 105:9 105:9
f="q.h.s." 105:10 105:10
du="nm"
r="nm"
ln="list"
27:
m="axid" 106:0 106:0
do="150 mg" 106:1 106:2
mo="p.o." 106:3 106:3
f="q.d." 106:4 106:4
du="nm"
r="nm"
ln="list"
28:
m="provastatin" 106:6 106:6
do="20 mg" 106:7 106:8
mo="p.o." 106:9 106:9
f="q.d." 106:10 106:10
du="nm"
r="nm"
ln="list"
