1:
m="procardia xl" 23:6 23:7
do="20 mg" 23:8 23:9
mo="p.o." 23:10 23:10
f="nm"
du="x 1" 23:11 23:12
r="a systolic blood pressure" 24:1 24:4
ln="narrative"
2:
m="aspirin" 24:9 24:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nitropaste" 24:11 24:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
4:
m="lasix" 25:11 25:11
do="nm"
mo="iv" 25:10 25:10
f="nm"
du="nm"
r="her shortness of breath" 26:4 26:7
ln="narrative"
5:
m="lasix" 25:2 25:2
do="nm"
mo="iv" 25:1 25:1
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="cardura" 32:3 32:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="metoprolol" 32:7 32:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="vasotec" 32:5 32:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="blood pressure medications" 55:2 55:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="lopressor" 56:9 56:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="lopressor" 57:4 57:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="blood pressure medications" 61:9 62:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
13:
m="beta blockers" 62:6 62:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="her heart rate" 61:2 61:4
ln="narrative"
14:
m="keflex" 69:3 69:3
do="250 mg" 69:4 69:5
mo="p.o." 69:6 69:6
f="q.i.d." 69:7 69:7
du="for 5 days" 69:8 69:10
r="nm"
ln="list"
15:
m="hydrochlorothiazide" 70:5 70:5
do="25 mg" 70:6 70:7
mo="p.o." 70:8 70:8
f="qd" 70:9 70:9
du="nm"
r="nm"
ln="list"
16:
m="norvasc" 70:0 70:0
do="5 mg" 70:1 70:2
mo="p.o." 70:3 70:3
f="qd" 70:4 70:4
du="nm"
r="nm"
ln="list"
17:
m="vasotec" 70:11 70:11
do="20 mg" 71:0 71:1
mo="p.o." 71:2 71:2
f="b.i.d." 71:3 71:3
du="nm"
r="nm"
ln="list"
18:
m="blood pressure medications" 73:1 73:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
