1:
m="digoxin" 37:2 37:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="IPF" 36:4 36:4
ln="narrative"
2:
m="prednisone" 37:4 37:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="ipf" 36:4 36:4
ln="narrative"
3:
m="captopril" 42:3 42:3
do="50 mg" 42:4 42:5
mo="nm"
f="b.i.d." 42:6 42:6
du="nm"
r="nm"
ln="list"
4:
m="lasix" 42:7 42:7
do="40 mg" 42:8 42:9
mo="nm"
f="q.d." 43:0 43:0
du="nm"
r="nm"
ln="list"
5:
m="axid" 43:5 43:5
do="150 mg" 43:6 43:7
mo="nm"
f="b.i.d." 44:0 44:0
du="nm"
r="nm"
ln="list"
6:
m="lopid" 43:1 43:1
do="600 mg" 43:2 43:3
mo="nm"
f="b.i.d." 43:4 43:4
du="nm"
r="nm"
ln="list"
7:
m="atenolol" 44:10 44:10
do="50 mg" 44:11 44:12
mo="nm"
f="q.d." 45:0 45:0
du="nm"
r="nm"
ln="list"
8:
m="insulin 70/30" 44:1 44:2
do="40" 44:7 44:7
mo="nm"
f="q. p.m" 44:8 44:9
du="nm"
r="nm"
ln="list"
9:
m="insulin 70/30" 44:1 44:2
do="90" 44:3 44:3
mo="nm"
f="q. a.m" 44:4 44:5
du="nm"
r="nm"
ln="list"
10:
m="aspirin" 84:8 84:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="heparin" 85:4 85:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
12:
m="lopressor" 85:0 85:0
do="37.5" 85:1 85:1
mo="nm"
f="t.i.d." 85:2 85:2
du="nm"
r="nm"
ln="narrative"
13:
m="oxygen" 85:6 85:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
14:
m="levofloxacin" 109:5 109:5
do="500 mg" 109:6 109:7
mo="nm"
f="q.d." 109:8 109:8
du="for fourteen days" 109:9 110:0
r="a retrocardiac infiltrate" 108:4 108:6
ln="narrative"
15:
m="aspirin" 111:4 111:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
16:
m="nexium" 111:9 111:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
17:
m="insulin" 113:10 113:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
18:
m="calcium" 114:0 114:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
19:
m="kayexalate" 114:4 114:4
do="nm"
mo="nm"
f="nm"
du="x 3" 114:5 114:6
r="hypokalemic" 112:3 112:3
ln="narrative"
20:
m="prednisone" 118:3 118:3
do="nm"
mo="nm"
f="nm"
du="overnight" 118:4 118:4
r="hypoglycemia" 117:9 117:9
ln="narrative"
21:
m="captopril" 119:5 119:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
22:
m="asa" 121:2 121:2
do="325 mg" 121:3 121:4
mo="p.o.q.d.;" 121:5 121:5
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="atenolol" 121:6 121:6
do="75 mg" 121:7 121:8
mo="p.o." 121:9 121:9
f="b.i.d." 122:0 122:0
du="nm"
r="nm"
ln="list"
24:
m="lasix" 122:1 122:1
do="40 mg" 122:2 122:3
mo="p.o.q.d.;" 122:4 122:4
f="nm"
du="nm"
r="nm"
ln="list"
25:
m="lopid" 122:5 122:5
do="600 mg" 122:6 122:7
mo="p.o." 123:0 123:0
f="b.i.d." 123:1 123:1
du="nm"
r="nm"
ln="list"
26:
m="nitroglycerin 1/150" 123:2 123:3
do="one tab" 123:4 123:5
mo="nm"
f="q. 5 minutes...p.r.n." 123:6 123:8,123:11 123:11
du="x 3" 123:9 123:10
r="chest pain" 124:0 124:1
ln="list"
27:
m="norvasc" 124:7 124:7
do="5 mg" 124:8 124:9
mo="p.o.q.d.;" 124:10 124:10
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="xalatan" 124:11 124:11
do="one drop" 125:0 125:1
mo="ou" 125:2 125:2
f="q.h.s." 125:3 125:3
du="nm"
r="nm"
ln="list"
29:
m="zocor" 124:2 124:2
do="10 mg" 124:3 124:4
mo="p.o." 124:5 124:5
f="q.h.s." 124:6 124:6
du="nm"
r="nm"
ln="list"
30:
m="alphagan" 125:4 125:4
do="one drop" 125:5 125:6
mo="ou" 125:7 125:7
f="b.i.d." 125:8 125:8
du="nm"
r="nm"
ln="list"
31:
m="levofloxacin" 125:9 125:9
do="500 mg" 125:10 126:0
mo="p.o.q.d.;" 126:1 126:1
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="clopidogrel" 126:2 126:2
do="75 mg" 126:3 126:4
mo="p.o.q.d.;" 126:5 126:5
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="insulin 70/30" 126:6 126:7
do="40 units" 127:2 127:3
mo="subcu" 127:6 127:6
f="q. p.m." 127:4 127:5
du="nm"
r="nm"
ln="list"
34:
m="insulin 70/30" 126:6 126:7
do="90 units" 126:8 126:9
mo="nm"
f="q. a.m." 126:10 127:0
du="nm"
r="nm"
ln="list"
35:
m="axid" 127:7 127:7
do="150 mg" 127:8 127:9
mo="p.o." 127:10 127:10
f="b.i.d." 127:11 127:11
du="nm"
r="nm"
ln="list"
