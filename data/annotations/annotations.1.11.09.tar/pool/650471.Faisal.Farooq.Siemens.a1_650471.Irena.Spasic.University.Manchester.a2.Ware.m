1:
m="nitroglycerin" 13:4 13:4
do="one" 13:2 13:2
mo="sublingual" 13:3 13:3
f="nm"
du="nm"
r="shortness of breath" 12:0 12:2
ln="narrative"
2:
m="nitroglycerin" 14:5 14:5
do="nm"
mo="sublingual" 14:4 14:4
f="nm"
du="nm"
r="nm"
ln="narrative"
3:
m="nitroglycerin" 17:0 17:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="shortness of breath" 15:1 15:3
ln="narrative"
4:
m="lasix " 19:5 19:5
do="nm"
mo="intravenous" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="narrative"
5:
m="morphine" 19:7 19:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="her pain" 20:4 20:5
ln="narrative"
6:
m="nitroglycerin" 20:0 20:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="her pain" 20:4 20:5
ln="narrative"
7:
m="ace inhibition" 78:4 78:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="antihypertensives" 78:7 78:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
9:
m="beta blockade" 78:1 78:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
10:
m="ischemics" 79:0 78:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
11:
m="packed red blood cells" 85:2 85:5
do="one unit" 84:10 85:0
mo="nm"
f="nm"
du="nm"
r="hematocrit" 84:0 84:0
ln="narrative"
12:
m="aspirin" 96:2 96:2
do="81 mg" 96:3 96:4
mo="nm"
f="daily" 96:5 96:5
du="nm"
r="nm"
ln="list"
13:
m="iron" 96:7 96:7
do="300 mg" 96:8 96:9
mo="nm"
f="three times a day" 96:10 97:2
du="nm"
r="nm"
ln="list"
14:
m="hydrochlorothiazide" 97:4 97:4
do="25 mg" 97:5 97:6
mo="nm"
f="daily" 98:0 98:0
du="nm"
r="nm"
ln="list"
15:
m="lisinopril" 98:2 98:2
do="5 mg" 98:3 98:4
mo="nm"
f="daily" 98:5 98:5
du="nm"
r="nm"
ln="list"
16:
m="multivitamin" 98:7 98:7
do="one" 98:8 98:8
mo="nm"
f="daily" 98:9 98:9
du="nm"
r="nm"
ln="list"
17:
m="relafen" 98:11 98:11
do="500 mg" 98:12 99:0
mo="orally" 99:1 99:1
f="a day" 99:2 99:3
du="nm"
r="nm"
ln="list"
18:
m="imdur" 99:5 99:5
do="60 mg" 99:6 99:7
mo="orally" 99:8 99:8
f="a day" 99:9 99:10
du="nm"
r="nm"
ln="list"
19:
m="plavix" 99:12 99:12
do="75 mg" 99:13 99:14
mo="nm"
f="daily" 99:15 99:15
du="for 29 days" 99:16 100:1
r="nm"
ln="list"
20:
m="atenolol" 100:8 100:8
do="25 mg" 100:9 100:10
mo="orally" 100:11 100:11
f="a day" 100:12 100:13
du="nm"
r="nm"
ln="list"
21:
m="lipitor" 100:3 100:3
do="40 mg" 100:4 100:5
mo="nm"
f="daily" 100:6 100:6
du="nm"
r="nm"
ln="list"
22:
m="magnesium oxide" 101:0 101:1
do="420 mg" 101:2 101:3
mo="nm"
f="daily" 101:4 101:4
du="nm"
r="nm"
ln="list"
