1:
m="acetylsalicylic acid" 19:0 19:1
do="81 mg" 19:2 19:3
mo="po" 19:4 19:4
f="qd" 19:5 19:5
du="nm"
r="nm"
ln="list"
2:
m="aspirin" 22:5 22:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="warfarin" 22:3 22:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="amiodarone" 24:0 24:0
do="200 mg" 24:1 24:2
mo="po" 24:3 24:3
f="qd" 24:4 24:4
du="nm"
r="nm"
ln="list"
5:
m="amiodarone hcl" 27:5 27:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="warfarin" 27:3 27:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="amiodarone hcl" 28:4 28:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 28:2 28:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="digoxin" 30:0 30:0
do="0.125 mg" 30:1 30:2
mo="po" 30:3 30:3
f="qd" 30:4 30:4
du="nm"
r="nm"
ln="list"
10:
m="amiodarone" 33:3 33:3
do="nm"
mo="po" 33:4 33:4
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="amiodarone hcl" 34:4 34:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="digoxin" 34:2 34:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="colace ( docusate sodium )" 36:0 36:4
do="100 mg" 36:5 36:6
mo="po" 36:7 36:7
f="bid" 36:8 36:8
du="nm"
r="nm"
ln="list"
14:
m="lasix ( furosemide )" 37:0 37:3
do="120 mg" 37:4 37:5
mo="po" 37:6 37:6
f="bid" 37:7 37:7
du="nm"
r="nm"
ln="list"
15:
m="nph humulin insulin ( insulin nph human )" 38:0 38:7
do="47 units" 38:8 38:9
mo="sc" 38:10 38:10
f="qam" 38:11 38:11
du="nm"
r="nm"
ln="list"
16:
m="insulin regular human" 39:0 39:2
do="0 units" 41:9 41:10
mo="subcutaneously" 41:11 41:11
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="insulin regular human" 39:0 39:2
do="10 units" 47:7 47:8
mo="subcutaneously" 47:9 47:9
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="insulin regular human" 39:0 39:2
do="2 units" 42:7 42:8
mo="subcutaneously" 42:9 42:9
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="insulin regular human" 39:0 39:2
do="3 units" 43:7 43:8
mo="subcutaneously" 43:9 43:9
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="insulin regular human" 39:0 39:2
do="4 units" 44:7 44:8
mo="subcutaneously" 44:9 44:9
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="insulin regular human" 39:0 39:2
do="6 units" 45:7 45:8
mo="subcutaneously" 45:9 45:9
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="insulin regular human" 39:0 39:2
do="8 units" 46:7 46:8
mo="subcutaneously" 46:9 46:9
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="insulin regular human" 39:0 39:2
do="sliding scale" 40:0 40:1
mo="( subcutaneously ) sc" 40:2 40:5
f="ac+hs" 40:6 40:6
du="nm"
r="nm"
ln="list"
24:
m="milk of magnesia ( magnesium hydroxide )" 49:0 49:6
do="30 milliliters" 50:0 50:1
mo="po" 50:2 50:2
f="qd prn" 50:3 50:4
du="nm"
r="constipation" 50:5 50:5
ln="list"
25:
m="coumadin ( warfarin sodium )" 51:0 51:4
do="2 mg" 51:5 51:6
mo="po" 51:7 51:7
f="qpm" 51:8 51:8
du="nm"
r="nm"
ln="list"
26:
m="acetylsalicylic acid" 57:3 57:4
do="nm"
mo="po" 57:5 57:5
f="nm"
du="nm"
r="nm"
ln="list"
27:
m="aspirin" 58:5 58:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="warfarin" 58:3 58:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="amiodarone" 62:3 62:3
do="nm"
mo="po" 62:4 62:4
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="amiodarone hcl" 63:5 63:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 63:3 63:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="simvastatin" 67:3 67:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="warfarin" 67:5 67:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="simvastatin" 69:0 69:0
do="80 mg" 69:1 69:2
mo="po" 69:3 69:3
f="qhs" 69:4 69:4
du="nm"
r="nm"
ln="list"
35:
m="coumadin" 74:3 74:3
do="nm"
mo="po" 74:4 74:4
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="simvastatin" 75:3 75:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 75:5 75:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="norvasc ( amlodipine )" 77:0 77:3
do="10 mg" 77:4 77:5
mo="po" 77:6 77:6
f="qd" 77:7 77:7
du="nm"
r="nm"
ln="list"
39:
m="imdur ( isosorbide mononit.( sr ) )" 80:0 80:6
do="60 mg" 80:7 80:8
mo="po" 80:9 80:9
f="qd" 80:10 80:10
du="nm"
r="nm"
ln="list"
40:
m="kcl immediate release" 84:0 84:2
do="40 meq" 84:3 84:4
mo="po" 84:5 84:5
f="bid" 84:6 84:6
du="nm"
r="nm"
ln="list"
41:
m="cozaar ( losartan )" 88:0 88:3
do="100 mg" 88:4 88:5
mo="po" 88:6 88:6
f="qhs" 88:7 88:7
du="number of doses required ( approximate ): 3" 89:5 89:12
r="nm"
ln="list"
42:
m="plavix ( clopidogrel )" 90:0 90:3
do="75 mg" 90:4 90:5
mo="po" 90:6 90:6
f="qd" 90:7 90:7
du="nm"
r="nm"
ln="list"
43:
m="nexium ( esomeprazole )" 91:0 91:3
do="20 mg" 91:4 91:5
mo="po" 91:6 91:6
f="qd" 91:7 91:7
du="nm"
r="nm"
ln="list"
44:
m="levothyroxine sodium" 92:0 92:1
do="50 mcg" 92:2 92:3
mo="po" 92:4 92:4
f="qd" 92:5 92:5
du="nm"
r="nm"
ln="list"
45:
m="digoxin" 94:3 94:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
46:
m="levothyroxine sodium" 94:5 95:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
47:
m="bb" 137:1 137:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="bradyarrhythmia" 138:0 138:0
ln="narrative"
48:
m="bb" 137:1 137:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypotension." 138:2 138:2
ln="narrative"
49:
m="antihypertensive" 138:4 138:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="cozaar" 139:3 139:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
51:
m="cozaar" 139:3 139:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
52:
m="digoxin" 139:11 139:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
53:
m="digoxin" 139:11 139:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
54:
m="isosorbide" 139:9 139:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
55:
m="isosorbide" 139:9 139:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
56:
m="lasix" 139:5 139:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
57:
m="lasix" 139:5 139:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
58:
m="norvasc" 139:7 139:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
59:
m="norvasc" 139:7 139:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
60:
m="amiodarone." 140:0 140:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="antihypertensive" 138:4 138:4
ln="narrative"
61:
m="amiodarone." 140:0 140:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="cad treatment" 138:6 139:0
ln="narrative"
62:
m="asa" 140:10 140:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
63:
m="coumadin" 140:5 140:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
64:
m="plavix" 140:7 140:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="coreg" 143:12 143:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="coreg" 145:10 145:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypertensive" 144:11 144:11
ln="narrative"
67:
m="insulin regimen" 155:7 155:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
68:
m="insulin" 156:0 156:0
do="sliding scale." 156:1 156:2
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
69:
m="synthroid" 159:9 159:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="asa" 161:8 161:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
71:
m="nexium;" 161:2 161:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
72:
m="plavix" 161:10 161:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="coumadin." 162:1 162:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
74:
m="levothyroxine" 169:2 169:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="hypothyroidism." 169:4 169:4
ln="narrative"
