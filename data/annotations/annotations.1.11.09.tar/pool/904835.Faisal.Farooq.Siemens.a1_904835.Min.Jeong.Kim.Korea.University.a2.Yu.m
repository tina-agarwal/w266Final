1:
m="tpa" 21:4 21:4
do="nm"
mo="intravenous" 21:3 21:3
f="nm"
du="nm"
r="nm"
ln="narrative"
2:
m="bolus" 22:1 22:1
do="81 mg" 22:7 22:8
mo="nm"
f="nm"
du="the following hour." 22:11 23:0
r="nm"
ln="narrative"
3:
m="bolus" 22:1 22:1
do="9 mg" 21:12 22:0
mo="nm"
f="nm"
du="over two minutes" 22:3 22:5
r="nm"
ln="narrative"
4:
m="bolus" 22:1 22:1
do="9 mg" 21:12 22:0
mo="nm"
f="nm"
du="two minutes" 22:4 22:5
r="nm"
ln="narrative"
5:
m="asacol" 31:7 31:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
6:
m="aspirin" 31:3 31:3
do="325 mg" 31:4 31:5
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="tpa" 52:4 52:4
do="nm"
mo="intravenous" 52:3 52:3
f="nm"
du="nm"
r="nm"
ln="narrative"
8:
m="oxygen" 63:3 63:3
do="nm"
mo="nasal" 63:2 63:2
f="nm"
du="for 24 hours." 64:3 64:5
r="nm"
ln="narrative"
9:
m="thrombolysis" 80:1 80:1
do="nm"
mo="intravenous" 80:0 80:0
f="nm"
du="over the next couple of days." 80:2 80:7
r="nm"
ln="narrative"
10:
m="coumadin" 84:3 84:3
do="nm"
mo="nm"
f="nm"
du="several days" 84:5 84:6
r="nm"
ln="narrative"
11:
m="coumadin." 87:7 87:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
