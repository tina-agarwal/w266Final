1:
m="allopurinol" 16:0 16:0
do="100 mg" 16:1 16:2
mo="po" 16:3 16:3
f="bid" 16:4 16:4
du="nm"
r="nm"
ln="list"
2:
m="ferrous sulfate" 17:0 17:1
do="325 mg" 17:2 17:3
mo="po" 17:4 17:4
f="qd" 17:5 17:5
du="nm"
r="nm"
ln="list"
3:
m="lasix (furosemide)" 19:0 19:3
do="60 mg" 19:4 19:5
mo="po" 19:6 19:6
f="bid" 19:7 19:7
du="nm"
r="nm"
ln="list"
4:
m="hydralazine hcl" 20:0 20:1
do="10 mg" 20:2 20:3
mo="po" 20:4 20:4
f="tid" 20:5 20:5
du="nm"
r="nm"
ln="list"
5:
m="isordil (isosorbide dinitrate)" 23:0 23:4
do="20 mg" 23:5 23:6
mo="po" 23:7 23:7
f="tid" 23:8 23:8
du="nm"
r="nm"
ln="list"
6:
m="lisinopril" 25:0 25:0
do="20 mg" 25:1 25:2
mo="po" 25:3 25:3
f="qd" 25:4 25:4
du="nm"
r="nm"
ln="list"
7:
m="kcl immediate release" 27:3 27:5
do="nm"
mo="po" 27:6 27:6
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="lisinopril" 28:3 28:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
9:
m="potassium chloride" 28:5 29:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="kcl immediate release" 32:3 32:5
do="nm"
mo="po" 32:6 32:6
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 33:3 33:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="potassium chloride" 33:5 34:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="kcl immediate release" 37:3 37:5
do="nm"
mo="po" 37:6 37:6
f="nm"
du="nm"
r="nm"
ln="list"
14:
m="lisinopril" 38:3 38:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
15:
m="potassium chloride" 38:5 39:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="kcl immediate release" 42:3 42:5
do="nm"
mo="po" 42:6 42:6
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="lisinopril" 43:3 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="potassium chloride" 43:5 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="kcl" 47:3 47:3
do="nm"
mo="iv" 47:4 47:4
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="lisinopril" 48:3 48:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="potassium chloride" 48:5 49:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="lipitor (atorvastatin)" 50:0 50:3
do="10 mg" 50:4 50:5
mo="po" 50:6 50:6
f="qd" 50:7 50:7
du="nm"
r="nm"
ln="list"
23:
m="protonix (pantoprazole)" 51:0 51:3
do="40 mg" 51:4 51:5
mo="po" 51:6 51:6
f="qd" 51:7 51:7
du="nm"
r="nm"
ln="list"
24:
m="toprol xl (metoprolol succinate extended release)" 52:0 52:7
do="75 mg" 53:0 53:1
mo="po" 53:2 53:2
f="qd" 53:3 53:3
du="nm"
r="nm"
ln="list"
25:
m="levaquin (levofloxacin)" 55:0 55:3
do="250 mg" 55:4 55:5
mo="po" 55:6 55:6
f="qd" 55:7 55:7
du="nm"
r="nm"
ln="list"
26:
m="iron" 57:1 57:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
27:
m="ciprofloxacin" 58:4 58:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
28:
m="levofloxacin" 58:2 58:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="acetylsalicylic acid" 61:0 61:1
do="325 mg" 61:2 61:3
mo="po" 61:4 61:4
f="qd" 61:5 61:5
du="nm"
r="nm"
ln="list"
30:
m="lasix" 104:5 104:5
do="100" 104:6 104:6
mo="nm"
f="bid" 104:7 104:7
du="nm"
r="nm"
ln="narrative"
31:
m="acei" 105:9 105:9
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
32:
m="bb" 105:7 105:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
33:
m="hydralazine/isordil" 105:11 105:11
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
34:
m="acei" 107:8 107:8
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperlipidemia:" 107:5 107:5
ln="narrative"
35:
m="asa" 107:12 107:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperlipidemia:" 107:5 107:5
ln="list"
36:
m="bb" 107:6 107:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperlipidemia:" 107:5 107:5
ln="narrative"
37:
m="statin" 107:10 107:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="hyperlipidemia:" 107:5 107:5
ln="narrative"
38:
m="mucomyst" 111:5 111:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="CRI w/ anemia" 111:1 111:3
ln="narrative"
39:
m="aranesp" 112:4 112:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="anemia" 112:1 112:1
ln="narrative"
40:
m="feso4" 112:6 112:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="anemia" 112:1 112:1
ln="narrative"
41:
m="acei." 113:3 113:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="bb" 113:1 113:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="keflex" 114:3 114:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
44:
m="levo" 114:10 114:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="allopurinol" 116:3 116:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="gout" 116:1 116:1
ln="narrative"
