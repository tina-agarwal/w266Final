1:
m="acetylsalicylic acid" 16:0 16:1
do="81 mg" 16:2 16:3
mo="po" 16:4 16:4
f="qd" 16:5 16:5
du="nm"
r="nm"
ln="list"
2:
m="coumadin" 19:3 19:3
do="nm"
mo="po" 19:4 19:4
f="nm"
du="nm"
r="nm"
ln="list"
3:
m="aspirin" 20:3 20:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="warfarin" 20:5 20:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="coumadin" 23:3 23:3
do="nm"
mo="po" 23:4 23:4
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="aspirin" 24:3 24:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="warfarin" 24:5 24:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="digoxin" 26:0 26:0
do="0.125 mg" 26:1 26:2
mo="po" 26:3 26:3
f="qd" 26:4 26:4
du="nm"
r="nm"
ln="list"
9:
m="levothyroxine sodium" 28:3 28:4
do="nm"
mo="po" 28:5 28:5
f="nm"
du="nm"
r="nm"
ln="list"
10:
m="digoxin" 29:3 29:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="levothyroxine sodium" 29:5 30:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="colace ( docusate sodium )" 31:0 31:4
do="100 mg" 31:5 31:6
mo="po" 31:7 31:7
f="bid" 31:8 31:8
du="nm"
r="nm"
ln="list"
13:
m="ferrous sulfate" 32:0 32:1
do="325 mg" 32:2 32:3
mo="po" 32:4 32:4
f="bid" 32:5 32:5
du="nm"
r="nm"
ln="list"
14:
m="motrin ( ibuprofen )" 34:0 34:3
do="600 mg" 34:4 34:5
mo="po" 34:6 34:6
f="q8h...prn" 34:7 34:7,35:0 35:0
du="nm"
r="pain" 35:1 35:1
ln="list"
15:
m="levothyroxine sodium" 36:0 36:1
do="75 mcg" 36:2 36:3
mo="po" 36:4 36:4
f="qd" 36:5 36:5
du="nm"
r="nm"
ln="list"
16:
m="coumadin" 39:3 39:3
do="nm"
mo="po" 39:4 39:4
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="levothyroxine sodium" 40:2 40:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="warfarin" 40:5 40:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="digoxin" 43:3 43:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="levothyroxine sodium" 43:5 44:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="levothyroxine sodium" 44:5 44:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
22:
m="warfarin" 44:3 44:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
23:
m="reglan ( metoclopramide hcl )" 46:0 46:4
do="5 mg" 46:5 46:6
mo="po" 46:7 46:7
f="ac" 46:8 46:8
du="nm"
r="nm"
ln="list"
24:
m="simethicone" 47:0 47:0
do="80 mg" 47:1 47:2
mo="po" 47:3 47:3
f="qid" 47:4 47:4
du="nm"
r="nm"
ln="list"
25:
m="vitamin b1 ( thiamine hcl )" 48:0 48:5
do="100 mg" 48:6 48:7
mo="po" 48:8 48:8
f="qd" 48:9 48:9
du="nm"
r="nm"
ln="list"
26:
m="trazodone" 49:0 49:0
do="50 mg" 49:1 49:2
mo="po" 49:3 49:3
f="hs" 49:4 49:4
du="nm"
r="nm"
ln="list"
27:
m="coumadin ( warfarin sodium )" 50:0 50:4
do="5 mg" 50:5 50:6
mo="po" 50:7 50:7
f="qpm" 50:8 50:8
du="nm"
r="nm"
ln="list"
28:
m="aspirin" 56:3 56:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
29:
m="warfarin" 56:5 56:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
30:
m="levothyroxine sodium" 57:2 57:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
31:
m="warfarin" 57:5 57:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
32:
m="simvastatin" 58:3 58:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
33:
m="warfarin" 58:5 58:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
34:
m="levofloxacin" 59:3 59:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="warfarin" 59:5 59:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="levofloxacin" 60:3 60:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
37:
m="warfarin" 60:5 60:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
38:
m="mvi therapeutic ( therapeutic multivitamins )" 62:0 62:5
do="1 tab" 62:6 62:7
mo="po" 62:8 62:8
f="qd" 62:9 62:9
du="nm"
r="nm"
ln="list"
39:
m="niacin" 65:5 65:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
40:
m="simvastatin" 65:3 65:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
41:
m="vit. b-3" 66:0 66:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
42:
m="toprol xl ( metoprolol succinate extended release )" 67:0 67:7
do="75 mg" 68:0 68:1
mo="po" 68:2 68:2
f="qd" 68:3 68:3
du="number of doses required ( approximate ): 10" 70:0 70:7
r="nm"
ln="list"
43:
m="gabapentin" 71:0 71:0
do="200 mg" 71:1 71:2
mo="po" 71:3 71:3
f="qd" 71:4 71:4
du="nm"
r="nm"
ln="list"
44:
m="torsemide" 72:0 72:0
do="100 mg" 72:1 72:2
mo="po" 72:3 72:3
f="bid" 72:4 72:4
du="nm"
r="nm"
ln="list"
45:
m="cozaar ( losartan )" 73:0 73:3
do="50 mg" 73:4 73:5
mo="po" 73:6 73:6
f="qd" 73:7 73:7
du="number of doses required ( approximate ): 10" 74:0 74:7
r="nm"
ln="list"
46:
m="levocarnitine" 75:0 75:0
do="1 gm" 75:1 75:2
mo="po" 75:3 75:3
f="qd" 75:4 75:4
du="number of doses required ( approximate ): 10" 77:0 77:7
r="nm"
ln="list"
47:
m="citalopram" 78:0 78:0
do="20 mg" 78:1 78:2
mo="po" 78:3 78:3
f="qd" 78:4 78:4
du="nm"
r="nm"
ln="list"
48:
m="advair diskus 250/50 ( fluticasone propionate/... )" 79:0 79:6
do="1 puff" 80:0 80:1
mo="inh" 80:2 80:2
f="bid" 80:3 80:3
du="nm"
r="nm"
ln="list"
49:
m="levofloxacin" 82:3 82:3
do="nm"
mo="po" 82:4 82:4
f="nm"
du="nm"
r="nm"
ln="list"
50:
m="salmeterol xinafoate" 83:3 83:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
51:
m="levofloxacin" 84:0 84:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
52:
m="nexium ( esomeprazole )" 85:0 85:3
do="20 mg" 85:4 85:5
mo="po" 85:6 85:6
f="qd" 85:7 85:7
du="nm"
r="nm"
ln="list"
53:
m="lantus ( insulin glargine )" 86:0 86:4
do="60 units" 86:5 86:6
mo="sc" 86:7 86:7
f="qhs" 86:8 86:8
du="nm"
r="nm"
ln="list"
54:
m="novolog ( insulin aspart )" 87:0 87:4
do="0 units" 89:9 89:10
mo="subcutaneously" 89:11 89:11
f="nm"
du="nm"
r="nm"
ln="list"
55:
m="novolog ( insulin aspart )" 87:0 87:4
do="10 units" 95:7 95:8
mo="subcutaneously" 95:9 95:9
f="nm"
du="nm"
r="nm"
ln="list"
56:
m="novolog ( insulin aspart )" 87:0 87:4
do="2 units" 90:7 90:8
mo="subcutaneously" 90:9 90:9
f="nm"
du="nm"
r="nm"
ln="list"
57:
m="novolog ( insulin aspart )" 87:0 87:4
do="3 units" 91:7 91:8
mo="subcutaneously" 91:9 91:9
f="nm"
du="nm"
r="nm"
ln="list"
58:
m="novolog ( insulin aspart )" 87:0 87:4
do="4 units" 92:7 92:8
mo="subcutaneously" 92:9 92:9
f="nm"
du="nm"
r="nm"
ln="list"
59:
m="novolog ( insulin aspart )" 87:0 87:4
do="6 units" 93:7 93:8
mo="subcutaneously" 93:9 93:9
f="nm"
du="nm"
r="nm"
ln="list"
60:
m="novolog ( insulin aspart )" 87:0 87:4
do="8 units" 94:7 94:8
mo="subcutaneously" 94:9 94:9
f="nm"
du="nm"
r="nm"
ln="list"
61:
m="novolog ( insulin aspart )" 87:0 87:4
do="sliding scale" 88:0 88:1
mo="( subcutaneously ) sc" 88:2 88:5
f="ac" 88:6 88:6
du="nm"
r="nm"
ln="list"
62:
m="lipitor ( atorvastatin )" 97:0 97:3
do="10 mg" 97:4 97:5
mo="po" 97:6 97:6
f="qpm" 97:7 97:7
du="nm"
r="nm"
ln="list"
63:
m="niacin" 99:3 99:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
64:
m="vit. b-3" 99:5 99:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
65:
m="atorvastatin calcium" 100:0 100:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
66:
m="atorvastatin calcium" 101:5 102:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
67:
m="warfarin" 101:3 101:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
68:
m="combivent ( ipratropium and albuterol sulfate )" 103:0 103:6
do="2 puff" 104:0 104:1
mo="inh" 104:2 104:2
f="qid" 104:3 104:3
du="nm"
r="nm"
ln="list"
69:
m="adriamycin" 119:0 119:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
70:
m="levofloxacin" 170:7 170:7
do="nm"
mo="po" 170:6 170:6
f="nm"
du="7 days course" 170:14 171:1
r="lll pneumonia." 170:9 170:10
ln="narrative"
71:
m="lasix" 173:9 173:9
do="200bid" 174:8 174:8
mo="nm"
f="nm"
du="x 2 doses" 174:9 174:11
r="nm"
ln="narrative"
72:
m="lasix" 173:9 173:9
do="nm"
mo="po" 173:8 173:8
f="nm"
du="nm"
r="nm"
ln="narrative"
73:
m="torsemide" 173:1 173:1
do="100mg" 173:2 173:2
mo="nm"
f="bid" 173:3 173:3
du="nm"
r="nm"
ln="narrative"
74:
m="torsemide" 174:0 174:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
75:
m="torsemide" 175:3 175:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
76:
m="zaroxyln" 175:5 175:5
do="5mg" 175:6 175:6
mo="po" 175:7 175:7
f="bid" 175:8 175:8
du="x 6 doses" 175:9 175:11
r="nm"
ln="narrative"
77:
m="motrin" 185:3 185:3
do="nm"
mo="nm"
f="tid." 185:4 185:4
du="nm"
r="gout-" 184:13 184:13
ln="narrative"
78:
m="insulin" 186:9 186:9
do="nm"
mo="nm"
f="nm"
du="during hospitalization" 186:6 186:7
r="bs" 186:3 186:3
ln="narrative"
79:
m="lantus" 187:1 187:1
do="60mg" 187:4 187:4
mo="nm"
f="qhs" 187:5 187:5
du="nm"
r="nm"
ln="narrative"
80:
m="lantus" 187:1 187:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
81:
m="novolog" 187:7 187:7
do="8u" 187:8 187:8
mo="nm"
f="qac" 187:9 187:9
du="nm"
r="nm"
ln="narrative"
82:
m="novolog" 187:7 187:7
do="sliding scale" 188:0 188:1
mo="nm"
f="qac" 187:9 187:9
du="nm"
r="nm"
ln="narrative"
83:
m="lantus" 188:8 188:8
do="60u" 188:9 188:9
mo="nm"
f="qhs" 188:10 188:10
du="nm"
r="nm"
ln="narrative"
84:
m="novolog" 188:12 188:12
do="sliding scale." 189:0 189:1
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
85:
m="coumadin" 190:7 190:7
do="5mg" 190:8 190:8
mo="po" 190:9 190:9
f="qd" 190:10 190:10
du="nm"
r="dvt" 190:12 190:12
ln="narrative"
86:
m="torsemide." 193:12 193:12
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
87:
m="coumadin" 194:10 194:10
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
88:
m="coumadin" 200:15 200:15
do="5mg" 200:16 200:16
mo="po" 200:17 200:17
f="qhs." 201:0 201:0
du="nm"
r="nm"
ln="narrative"
89:
m="coumadin" 201:7 201:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
90:
m="torsemide" 203:4 203:4
do="100mg" 203:5 203:5
mo="nm"
f="twice a day" 203:6 203:8
du="nm"
r="diuresis" 203:2 203:2
ln="narrative"
91:
m="motrin" 207:2 207:2
do="600mg" 207:3 207:3
mo="nm"
f="as needed" 207:4 207:5
du="nm"
r="your thumb pain." 207:7 207:9
ln="narrative"
92:
m="allopurinol" 208:3 208:3
do="100mg" 208:4 208:4
mo="nm"
f="daily" 208:5 208:5
du="nm"
r="gout prophylaxis." 208:7 208:8
ln="narrative"
93:
m="lantus insulin" 209:2 209:3
do="60units" 209:8 209:8
mo="nm"
f="at night." 209:9 209:10
du="nm"
r="nm"
ln="narrative"
