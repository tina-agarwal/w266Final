1:
m="ecasa ( aspirin enteric coated )" 16:0 16:5
do="325 mg" 16:6 16:7
mo="po" 16:8 16:8
f="qd" 16:9 16:9
du="nm"
r="nm"
ln="list"
2:
m="cardizem sr ( diltiazem sustained release )" 17:0 17:6
do="120 mg" 17:7 17:8
mo="po" 17:9 17:9
f="qd" 17:10 17:10
du="nm"
r="nm"
ln="list"
3:
m="lopressor" 20:16 20:16
do="nm"
mo="po" 20:17 20:17
f="nm"
du="nm"
r="nm"
ln="list"
4:
m="diltiazem hcl" 21:3 21:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
5:
m="metoprolol tartrate" 22:0 22:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
6:
m="metoprolol tartrate" 25:3 25:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
7:
m="diltiazem hcl" 26:0 26:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
8:
m="hydrochlorothiazide" 28:0 28:0
do="25 mg" 28:1 28:2
mo="po" 28:3 28:3
f="qd" 28:4 28:4
du="nm"
r="nm"
ln="list"
9:
m="lisinopril" 29:0 29:0
do="30 mg" 29:1 29:2
mo="po" 29:3 29:3
f="qd" 29:4 29:4
du="nm"
r="nm"
ln="list"
10:
m="potassium chloride immed. rel." 32:3 32:6
do="nm"
mo="po" 32:7 32:7
f="nm"
du="nm"
r="nm"
ln="list"
11:
m="lisinopril" 34:3 34:3
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
12:
m="potassium chloride" 34:5 35:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
13:
m="lorazepam" 36:0 36:0
do="0.5 mg" 36:1 36:2
mo="po" 36:3 36:3
f="bid prn" 36:4 36:5
du="nm"
r="anxiety" 36:6 36:6
ln="list"
14:
m="lopressor ( metoprolol tartrate )" 37:0 37:4
do="12.5 mg" 37:5 37:6
mo="po" 37:7 37:7
f="bid" 37:8 37:8
du="nm"
r="nm"
ln="list"
15:
m="cardizem sr" 43:3 43:4
do="nm"
mo="po" 43:5 43:5
f="nm"
du="nm"
r="nm"
ln="list"
16:
m="metoprolol tartrate" 44:3 44:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
17:
m="diltiazem hcl" 45:0 45:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
18:
m="cardizem" 48:3 48:3
do="nm"
mo="po" 48:4 48:4
f="nm"
du="nm"
r="nm"
ln="list"
19:
m="metoprolol tartrate" 49:3 49:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
20:
m="diltiazem hcl" 50:0 50:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
21:
m="prednisone" 51:0 51:0
do="20mg" 54:11 54:11
mo="nm"
f="nm"
du="indefinitely." 55:0 55:0
r="nm"
ln="list"
22:
m="prednisone" 51:0 51:0
do="25mg" 54:6 54:6
mo="nm"
f="nm"
du="for 2days" 54:7 54:8
r="nm"
ln="list"
23:
m="prednisone" 51:0 51:0
do="30mg" 54:1 54:1
mo="nm"
f="nm"
du="for 2days" 54:2 54:3
r="nm"
ln="list"
24:
m="prednisone" 51:0 51:0
do="35mg" 53:8 53:8
mo="nm"
f="nm"
du="for 2days" 53:9 53:10
r="nm"
ln="list"
25:
m="prednisone" 51:0 51:0
do="40 mg" 51:1 51:2
mo="po" 51:3 51:3
f="qam" 51:4 51:4
du="x 10 doses" 51:5 51:7
r="nm"
ln="list"
26:
m="prednisone" 51:0 51:0
do="40mg" 53:2 53:2
mo="nm"
f="nm"
du="2 days" 53:4 53:5
r="nm"
ln="list"
27:
m="prednisone" 51:0 51:0
do="40mg" 53:2 53:2
mo="nm"
f="nm"
du="for 2 days" 53:3 53:5
r="nm"
ln="list"
28:
m="zocor ( simvastatin )" 56:0 56:3
do="40 mg" 56:4 56:5
mo="po" 56:6 56:6
f="qhs" 56:7 56:7
du="nm"
r="nm"
ln="list"
29:
m="clopidogrel" 59:0 59:0
do="75 mg" 59:1 59:2
mo="po" 59:3 59:3
f="qd" 59:4 59:4
du="nm"
r="nm"
ln="list"
30:
m="calcium carb + d ( 600mg elem ca + vit d/200 iu )" 60:0 60:12
do="1 tab" 61:0 61:1
mo="po" 61:2 61:2
f="qd" 61:3 61:3
du="nm"
r="nm"
ln="list"
31:
m="combivent ( ipratropium and albuterol sulfate )" 62:0 62:6
do="2 puff" 63:0 63:1
mo="inh" 63:2 63:2
f="qid" 63:3 63:3
du="nm"
r="nm"
ln="list"
32:
m="atovaquone" 64:0 64:0
do="750 mg" 64:1 64:2
mo="po" 64:3 64:3
f="bid" 64:4 64:4
du="nm"
r="nm"
ln="list"
33:
m="naprosyn ( naproxen )" 66:0 66:3
do="250-500 mg" 66:4 66:5
mo="po" 66:6 66:6
f="bid prn" 66:7 66:8
du="nm"
r="pain" 66:9 66:9
ln="list"
34:
m="clopidogrel bisulfate" 69:3 69:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
35:
m="naproxen" 70:0 70:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="list"
36:
m="advair diskus 500/50 ( fluticasone propionate/... )" 71:0 71:6
do="1 puff" 72:0 72:1
mo="inh" 72:2 72:2
f="bid" 72:3 72:3
du="nm"
r="nm"
ln="list"
37:
m="steroid" 84:4 84:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
38:
m="prednisone" 91:1 91:1
do="nm"
mo="nm"
f="nm"
du="nm"
r="asthma" 90:10 90:10
ln="narrative"
39:
m="prednisone" 110:0 110:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="asthma" 109:15 109:15
ln="narrative"
40:
m="prednisone" 111:5 111:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="asthma exacerbation" 111:2 111:3
ln="narrative"
41:
m="clopidogrel" 122:4 122:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
42:
m="ecasa." 122:6 122:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
43:
m="nitrates" 122:7 122:7
do="nm"
mo="nm"
f="as needed." 122:8 122:9
du="nm"
r="nm"
ln="narrative"
44:
m="zocor" 122:2 122:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
45:
m="cardizem." 123:6 123:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
46:
m="hctz" 123:4 123:4
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
47:
m="lisinopril" 123:2 123:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
48:
m="lopressor" 123:7 123:7
do="12.5mg" 123:8 123:8
mo="po" 123:9 123:9
f="bid." 123:10 123:10
du="nm"
r="nm"
ln="narrative"
49:
m="prednisone therapy." 126:5 126:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
50:
m="pred" 127:2 127:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
51:
m="advair" 130:2 130:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
52:
m="-combivent" 130:0 130:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
53:
m="pcp ppx" 130:15 130:16
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
54:
m="steroid" 130:4 130:4
do="20mg" 130:9 130:9
mo="nm"
f="nm"
du="over 8 days" 130:10 130:12
r="nm"
ln="narrative"
55:
m="steroid" 130:4 130:4
do="40mg" 130:7 130:7
mo="nm"
f="nm"
du="over 8 days" 130:10 130:12
r="nm"
ln="narrative"
56:
m="atovaquone" 131:2 131:2
do="nm"
mo="nm"
f="bid" 131:1 131:1
du="nm"
r="nm"
ln="narrative"
57:
m="prednisone." 131:7 131:7
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
58:
m="-calcium/vit d supplement." 132:8 133:0
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
59:
m="insulin" 132:5 132:5
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
60:
m="steroid" 132:2 132:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
61:
m="naprosyn" 135:1 135:1
do="nm"
mo="nm"
f="prn" 135:2 135:2
du="nm"
r="pain." 135:3 135:3
ln="narrative"
62:
m="lorazepam" 136:6 136:6
do="nm"
mo="nm"
f="nm"
du="nm"
r="anxiety." 136:8 136:8
ln="narrative"
63:
m="zoloft" 136:2 136:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="depression" 136:4 136:4
ln="narrative"
64:
m="prednisone" 145:2 145:2
do="20mg" 145:3 145:3
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
65:
m="beta-blocker." 146:7 146:7
do="low dose" 146:5 146:6
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
66:
m="nsaids." 147:4 147:4
do="nm"
mo="nm"
f="prn" 147:3 147:3
du="nm"
r="nm"
ln="narrative"
67:
m="atovaquone" 148:2 148:2
do="nm"
mo="nm"
f="nm"
du="nm"
r="nm"
ln="narrative"
